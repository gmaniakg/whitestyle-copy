// 화타펫 (HwataPet) 3D 백그라운드 서비스 워커 — 데스크톱 화타펫(127.0.0.1:47821) 연동 및 알림 관리
const DESKTOP_HOOK_URL = 'http://127.0.0.1:47821/hook/web';
const AI_SITES = ['claude.ai', 'chatgpt.com', 'gemini'];

chrome.runtime.onMessage.addListener((msg, sender) => {
  if (!sender.tab || !msg || !AI_SITES.includes(msg.site)) return;
  if (msg.kind !== 'prompt' && msg.kind !== 'reply') return;
  const payload = {
    hook_event_name: msg.kind === 'prompt' ? 'UserPromptSubmit' : 'Stop',
    session_id: msg.site + ':' + (msg.conv || 'default'),
    site: msg.site,
    conv: msg.conv || 'default',
    kind: msg.kind,
    chars: msg.chars || 0,
    ms: msg.ms || 0,
    model: msg.model || '',
  };
  fetch(DESKTOP_HOOK_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  }).catch(() => {});
});
