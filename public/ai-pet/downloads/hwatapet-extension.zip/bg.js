// 화타펫 (HwataPet / 하야니) 백그라운드 서비스 워커 v3.0.0
// 50분 집중 후 어금니 이완 스트레칭 알람 및 양치 타이머 백그라운드 스케줄러

const DEFAULT_INTERVAL_MIN = 50;

function setupJawAlarm(intervalMinutes = DEFAULT_INTERVAL_MIN) {
  chrome.alarms.clear('hwataJawRelaxAlarm', () => {
    chrome.alarms.create('hwataJawRelaxAlarm', {
      delayInMinutes: intervalMinutes,
      periodInMinutes: intervalMinutes,
    });
  });
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(['hwata_alarm_interval'], (res) => {
    const interval = res && res.hwata_alarm_interval ? Number(res.hwata_alarm_interval) : DEFAULT_INTERVAL_MIN;
    setupJawAlarm(interval);
  });
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'hwataJawRelaxAlarm') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs && tabs[0] && tabs[0].id) {
        chrome.tabs.sendMessage(tabs[0].id, {
          type: 'HWATA_JAW_RELAX_ALERT',
          title: '화타의 어금니 이완 알림 멍!',
          message: '어금니를 꽉 깨물고 계시지 않나요? 윗니와 아랫니 사이에 2~3mm 살짝 틈을 두고 턱의 긴장을 풀어주세요!',
        }).catch(() => {
          // 활성 탭이 주입 불가능한 페이지(e.g. chrome://)인 경우 조용히 무시
        });
      }
    });
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === 'UPDATE_ALARM_INTERVAL') {
    const mins = Number(msg.interval) || DEFAULT_INTERVAL_MIN;
    setupJawAlarm(mins);
    chrome.storage.local.set({ hwata_alarm_interval: mins });
    sendResponse({ ok: true, interval: mins });
    return true;
  }
});
