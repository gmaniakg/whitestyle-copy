// 화타펫 (HwataPet) 브리지 스크립트
window.addEventListener('message', (ev) => {
  if (ev.source !== window || !ev.data || !ev.data.__hwatapet) return;
  try {
    chrome.runtime.sendMessage(ev.data);
  } catch {}
});
