// 화타펫 (HwataPet / 하야니) 3D v3.0.0 플래그십 마스터피스 에디션
// 3D 웰니스 구강 케어 도우미 (2분 바스법 양치 타이머, 50분 어금니 이완 스트레칭, 습관 스트릭, 3개국어)
(() => {
  // DOM 참조
  const cv = document.getElementById('hwata3dCanvas');
  const ctx = cv.getContext('2d');
  const chatArea = document.getElementById('chatArea');
  const scorePill = document.getElementById('scorePill');
  const scoreFill = document.getElementById('scoreFill');
  const vipHint = document.getElementById('vipHint');
  const soundToggleBtn = document.getElementById('soundToggleBtn');
  const langSelect = document.getElementById('langSelect');
  const streakBadge = document.getElementById('streakBadge');
  const petMoodBadge = document.getElementById('petMoodBadge');

  // 상태 관리
  let score = Number(localStorage.getItem('hwata_score') || 0);
  let vipCode = localStorage.getItem('hwata_pass_code') || '';
  let quizIdx = Number(localStorage.getItem('hwata_quiz_idx') || 0);
  let currentMode = 'idle'; // idle | wave | brush | type | happy
  let soundEnabled = localStorage.getItem('hwata_sound') !== 'false';
  let currentLang = localStorage.getItem('hwata_lang') || 'ko';

  // 통계 및 스트릭 상태
  let todayBrushCount = Number(localStorage.getItem('hwata_today_brush') || 0);
  let todayRelaxCount = Number(localStorage.getItem('hwata_today_relax') || 0);
  let quizCorrectCount = Number(localStorage.getItem('hwata_quiz_correct') || 0);
  let streakDays = Number(localStorage.getItem('hwata_streak_days') || 1);
  const lastActiveDate = localStorage.getItem('hwata_last_active_date') || '';
  const todayDateStr = new Date().toISOString().slice(0, 10);

  if (lastActiveDate !== todayDateStr) {
    if (lastActiveDate) {
      const last = new Date(lastActiveDate);
      const curr = new Date(todayDateStr);
      const diffDays = Math.round((curr - last) / (1000 * 60 * 60 * 24));
      if (diffDays === 1) streakDays += 1;
      else if (diffDays > 1) streakDays = 1;
    }
    localStorage.setItem('hwata_last_active_date', todayDateStr);
    localStorage.setItem('hwata_streak_days', String(streakDays));
    todayBrushCount = 0;
    todayRelaxCount = 0;
    localStorage.setItem('hwata_today_brush', '0');
    localStorage.setItem('hwata_today_relax', '0');
  }

  // Web Audio API 신디사이저 효과음 엔진
  let audioCtx = null;
  function getAudioContext() {
    if (!audioCtx && typeof window.AudioContext !== 'undefined') {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
    if (audioCtx && audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
    return audioCtx;
  }

  function playTone(freq, type = 'sine', duration = 0.15, gainVal = 0.08) {
    if (!soundEnabled) return;
    try {
      const actx = getAudioContext();
      if (!actx) return;
      const osc = actx.createOscillator();
      const gain = actx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, actx.currentTime);
      gain.gain.setValueAtTime(gainVal, actx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, actx.currentTime + duration);
      osc.connect(gain);
      gain.connect(actx.destination);
      osc.start();
      osc.stop(actx.currentTime + duration);
    } catch {}
  }

  function playChime() {
    if (!soundEnabled) return;
    playTone(523.25, 'sine', 0.2, 0.09); // C5
    setTimeout(() => playTone(659.25, 'sine', 0.25, 0.09), 100); // E5
    setTimeout(() => playTone(783.99, 'sine', 0.35, 0.09), 200); // G5
  }

  function playTick() {
    if (!soundEnabled) return;
    playTone(800, 'triangle', 0.04, 0.03);
  }

  function playFanfare() {
    if (!soundEnabled) return;
    const notes = [523.25, 659.25, 783.99, 1046.50];
    notes.forEach((freq, idx) => {
      setTimeout(() => playTone(freq, 'sine', 0.3, 0.1), idx * 120);
    });
  }

  function playRelaxTone() {
    if (!soundEnabled) return;
    playTone(432, 'sine', 0.8, 0.06); // 432Hz 힐링 톤
  }

  // 사운드 토글 UI
  function updateSoundUI() {
    soundToggleBtn.textContent = soundEnabled ? '🔊' : '🔇';
    soundToggleBtn.title = soundEnabled ? '효과음 켜짐 (클릭 시 음소거)' : '효과음 꺼짐 (클릭 시 켜기)';
  }
  soundToggleBtn.addEventListener('click', () => {
    soundEnabled = !soundEnabled;
    localStorage.setItem('hwata_sound', String(soundEnabled));
    updateSoundUI();
    if (soundEnabled) playChime();
  });
  updateSoundUI();

  // 언어 선택 UI
  langSelect.value = currentLang;
  langSelect.addEventListener('change', (e) => {
    currentLang = e.target.value;
    localStorage.setItem('hwata_lang', currentLang);
    applyLanguage();
  });

  function applyLanguage() {
    if (currentLang === 'ja') {
      document.getElementById('tabCareBtn').textContent = '⏱️ ケアタイマー';
      document.getElementById('tabPetBtn').textContent = '🐾 3Dペット';
      document.getElementById('tabStatsBtn').textContent = '📊 習慣レポート';
      document.getElementById('tabChatBtn').textContent = '💬 チェック＆クイズ';
      streakBadge.textContent = `🔥 ${streakDays}日連続ケア`;
      petMoodBadge.textContent = '✨ 気分最高!';
    } else if (currentLang === 'en') {
      document.getElementById('tabCareBtn').textContent = '⏱️ Care Timer';
      document.getElementById('tabPetBtn').textContent = '🐾 3D Pet';
      document.getElementById('tabStatsBtn').textContent = '📊 Habit Stats';
      document.getElementById('tabChatBtn').textContent = '💬 Check & Quiz';
      streakBadge.textContent = `🔥 ${streakDays}-Day Streak`;
      petMoodBadge.textContent = '✨ Super Happy!';
    } else {
      document.getElementById('tabCareBtn').textContent = '⏱️ 케어 타이머';
      document.getElementById('tabPetBtn').textContent = '🐾 3D 펫';
      document.getElementById('tabStatsBtn').textContent = '📊 습관 리포트';
      document.getElementById('tabChatBtn').textContent = '💬 자가점검 & 퀴즈';
      streakBadge.textContent = `🔥 ${streakDays}일 연속 케어`;
      petMoodBadge.textContent = '✨ 기분 최고!';
    }
    if (typeof updatePetHeaderTitle === 'function' && typeof EXT_SPECIES_META !== 'undefined') {
      updatePetHeaderTitle();
    }
    if (typeof renderSpeciesGrid === 'function' && typeof speciesGrid !== 'undefined') {
      renderSpeciesGrid();
    }
  }

  // VIP 코드 확인 및 생성
  function ensurePassCode(force = false) {
    if ((!vipCode && score >= 10) || (!vipCode && force)) {
      vipCode = 'HWATA-PASS-' + (1000 + Math.floor(Math.random() * 9000));
      localStorage.setItem('hwata_pass_code', vipCode);
    }
    return vipCode;
  }

  // 3D 이미지 에셋 로딩
  const POSES = {};
  ['idle', 'blink', 'type1', 'type2', 'wave', 'brush',
    'sit', 'sit_blink', 'sit_hold', 'stand4', 'stand4_blink', 'stand4_a', 'stand4_b', 'stand4_hold_a', 'stand4_hold_b'].forEach((k) => {
    const img = new Image();
    img.src = 'assets3d/hwata_3d_' + k + '.png';
    POSES[k] = img;
  });

  const EXT_SPECIES_META = {
    dog: { name: '강아지 하야니', nameEn: 'Hayani the Pup', nameJa: 'ハヤニ (子犬)', icon: '🐕', greet: '멍멍! 식후 30분 올바른 양치질은 제게 맡기세요!' },
    elephant: { name: '아기 코끼리 코코', nameEn: 'Coco the Elephant', nameJa: 'ココ (子象)', icon: '🐘', greet: '뿌우~! 긴 코로 시원하게 물 가글을 챙겨드려요!' },
    dino: { name: '아기 공룡 디노', nameEn: 'Dino the Baby T-Rex', nameJa: 'ディノ (恐竜)', icon: '🦖', greet: '크앙! 튼튼하고 가지런한 치아 건강을 지켜드릴게요!' },
    python: { name: '황금 파이톤 파이', nameEn: 'Py the Python', nameJa: 'パイ (パイソン)', icon: '🐍', greet: '슈우~ 집중해서 작업할 때 턱에 힘 빼는 걸 잊지 마세요!' },
    parrot: { name: '오색 앵무새 코코아', nameEn: 'Cocoa the Parrot', nameJa: 'ココア (オウム)', icon: '🦜', greet: '짹짹! 오늘 거울 보고 입꼬리를 올려 미소 체크 해볼까요?' },
    cat: { name: '고양이 치즈', nameEn: 'Cheese the Cat', nameJa: 'チーズ (子猫)', icon: '🐱', greet: '야옹~ 부드러운 칫솔질로 잇몸을 편안하게 마사지해요!' }
  };
  const EXT_SPECIES_LIST = ['dog', 'elephant', 'dino', 'python', 'parrot', 'cat'];
  let currentSpecies = localStorage.getItem('hwata_ext_species') || 'dog';
  const SPECIES_POSES = {};
  EXT_SPECIES_LIST.forEach((sp) => {
    const im = new Image();
    im.src = 'assets3d/hwata_3d_species_' + sp + '.png';
    SPECIES_POSES[sp] = im;
  });

  function updatePetHeaderTitle() {
    const headerTitle = document.getElementById('petHeaderTitle');
    if (headerTitle && EXT_SPECIES_META[currentSpecies]) {
      const meta = EXT_SPECIES_META[currentSpecies];
      const name = currentLang === 'ja' ? meta.nameJa : currentLang === 'en' ? meta.nameEn : meta.name;
      headerTitle.textContent = '화타펫 — ' + name + ' 3D';
    }
  }
  updatePetHeaderTitle();
  applyLanguage();
  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.get(['hwata_ext_species', 'hwata_score'], (res) => {
        if (res && res.hwata_ext_species && EXT_SPECIES_META[res.hwata_ext_species]) {
          currentSpecies = res.hwata_ext_species;
          localStorage.setItem('hwata_ext_species', currentSpecies);
          updatePetHeaderTitle();
          if (typeof renderSpeciesGrid === 'function') renderSpeciesGrid();
        }
        if (res && typeof res.hwata_score === 'number' && res.hwata_score > score) {
          score = res.hwata_score;
          localStorage.setItem('hwata_score', String(score));
          updateScoreUI();
        }
      });
    }
  } catch {}

  // 3D 렌더링 앵커
  const ANCHOR = {
    upright: { hip: [-38, -60], mouth: [0, -82], faceLeft: false },
    sit: { hip: [-38.6, -30.3], mouth: [0, -82.7], faceLeft: false },
    stand4: { hip: [52.3, -50.9], mouth: [-36.6, -66.2], faceLeft: true },
  };
  let dogPose = localStorage.getItem('hwata_dog_pose') === 'stand4' ? 'stand4' : 'sit';
  let fetchRun = null;
  let present = null;
  const FETCH_OUT = 1.1, FETCH_AWAY = 1.6, FETCH_IN = 1.1;

  function drawTail(t, kind, mode) {
    let tailFreq = 4.0, tailAmp = 0.28, tailBase = -0.52, tailHarmonic = 0;
    if (mode === 'wave' || mode === 'happy') {
      tailFreq = 15.0; tailAmp = 0.60; tailBase = -0.76; tailHarmonic = Math.sin(t * 30.0) * 0.12;
    } else if (mode === 'brush') {
      tailFreq = 8.5; tailAmp = 0.38; tailBase = -0.36;
    } else if (mode === 'type') {
      tailFreq = 2.4; tailAmp = 0.18; tailBase = -0.45;
    } else if (mode === 'walk') {
      tailFreq = 10.5; tailAmp = 0.42; tailBase = -0.5;
    }
    const tailAngle = tailBase + Math.sin(t * tailFreq) * tailAmp + tailHarmonic;
    const tailLen = kind === 'stand4' ? 36 : 42;
    const a = ANCHOR[kind];
    ctx.save();
    ctx.translate(a.hip[0], a.hip[1]);
    if (kind === 'stand4') ctx.rotate(Math.PI);
    ctx.rotate(tailAngle);
    if (tailFreq > 10) {
      for (const s of [-1, 1]) {
        ctx.save();
        ctx.rotate(s * tailAmp * 0.35);
        ctx.beginPath();
        ctx.ellipse(-tailLen * 0.5, 0, tailLen * 0.5, 6, 0, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255, 255, 255, 0.22)';
        ctx.fill();
        ctx.restore();
      }
    }
    ctx.beginPath();
    ctx.moveTo(0, -5);
    ctx.bezierCurveTo(-tailLen * 0.35, -9, -tailLen * 0.7, -13, -tailLen, -3);
    ctx.arc(-tailLen, 0, 7, -Math.PI / 2, Math.PI / 2, false);
    ctx.bezierCurveTo(-tailLen * 0.7, 9, -tailLen * 0.35, 7, 0, 5);
    ctx.closePath();
    const tGrad = ctx.createLinearGradient(0, 0, -tailLen, 0);
    tGrad.addColorStop(0, '#f2ede4');
    tGrad.addColorStop(0.5, '#ffffff');
    tGrad.addColorStop(1, '#fffaf2');
    ctx.fillStyle = tGrad;
    ctx.shadowColor = 'rgba(40, 20, 10, 0.18)';
    ctx.shadowBlur = 6;
    ctx.shadowOffsetX = -2;
    ctx.shadowOffsetY = 3;
    ctx.fill();
    ctx.strokeStyle = 'rgba(215, 205, 190, 0.85)';
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(-tailLen + 1, -1, 4, 0, Math.PI * 2);
    ctx.fillStyle = '#ffffff';
    ctx.fill();
    ctx.restore();
  }

  function render3DLoop() {
    const t = performance.now() / 1000;
    ctx.clearRect(0, 0, cv.width, cv.height);
    const blink = (t % 4.2) < 0.14;
    if (present && t > present.until) present = null;

    let walkX = 0, walking = false, flip = false, carry = null, hidden = false;
    if (fetchRun) {
      const e = t - fetchRun.t0;
      if (e < FETCH_OUT) { walking = true; walkX = (e / FETCH_OUT) * 140; flip = true; }
      else if (e < FETCH_OUT + FETCH_AWAY) hidden = true;
      else if (e < FETCH_OUT + FETCH_AWAY + FETCH_IN) { walking = true; walkX = 140 * (1 - (e - FETCH_OUT - FETCH_AWAY) / FETCH_IN); carry = fetchRun.emoji; }
      else {
        present = { emoji: fetchRun.emoji, until: t + 6 };
        fetchRun = null;
        dogPose = 'sit';
        currentMode = 'happy';
        setTimeout(() => { if (currentMode === 'happy') currentMode = 'idle'; }, 1600);
      }
    }
    const held = carry || (present && present.emoji) || null;

    let key = 'idle';
    let kind = 'upright';
    if (walking) {
      kind = 'stand4';
      const b = Math.floor(t * 7) % 2 === 1;
      key = held ? (b ? 'stand4_hold_b' : 'stand4_hold_a') : (b ? 'stand4_b' : 'stand4_a');
    } else if (currentMode === 'wave') key = 'wave';
    else if (currentMode === 'brush') key = 'brush';
    else if (currentMode === 'type') key = Math.floor(t * 8) % 2 ? 'type1' : 'type2';
    else if (dogPose === 'stand4') { kind = 'stand4'; key = held ? 'stand4_hold_a' : blink ? 'stand4_blink' : 'stand4'; }
    else { kind = 'sit'; key = held ? 'sit_hold' : blink ? 'sit_blink' : 'sit'; }

    const isDog = currentSpecies === 'dog';
    let img = null;
    if (!isDog && SPECIES_POSES[currentSpecies] && SPECIES_POSES[currentSpecies].complete) {
      img = SPECIES_POSES[currentSpecies];
    } else {
      img = (POSES[key] && POSES[key].complete && POSES[key].naturalWidth) ? POSES[key] : POSES.idle;
    }
    if (!hidden && img && img.complete) {
      const breathe = Math.sin(t * 3.0);
      let sx = 1 - breathe * 0.018;
      let sy = 1 + breathe * 0.032;
      let dy = currentMode === 'wave' || currentMode === 'happy' ? -Math.abs(Math.sin(t * 7)) * (kind === 'upright' ? 10 : 5) : 0;
      let rot = currentMode === 'brush' ? Math.sin(t * 14) * 0.05 : Math.sin(t * 2) * 0.02;
      if (walking) { dy = -Math.abs(Math.sin(t * 14)) * 3; rot = Math.sin(t * 14) * 0.02; }
      const faceFlip = ANCHOR[kind].faceLeft ? flip : false;
      ctx.save();
      ctx.translate(90 + walkX, 162 + dy);
      if (faceFlip) ctx.scale(-1, 1);
      ctx.rotate(rot);
      ctx.scale(sx, sy);
      if (isDog) drawTail(t, kind, walking ? 'walk' : currentMode);
      ctx.drawImage(img, -78, -150, 156, 156);
      ctx.restore();
      if (held) {
        const m = ANCHOR[kind].mouth;
        ctx.save();
        ctx.translate(90 + walkX + m[0] * (faceFlip ? -1 : 1) * sx, 162 + dy + m[1] * sy + 7);
        ctx.rotate((faceFlip ? 1 : -1) * 0.18 + Math.sin(t * 5) * 0.06);
        ctx.font = '40px "Segoe UI Emoji", "Apple Color Emoji", "Noto Color Emoji", sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(held, 0, 0);
        ctx.restore();
      }
    }
    requestAnimationFrame(render3DLoop);
  }
  requestAnimationFrame(render3DLoop);

  // 스테이지 펫 클릭 인터랙션
  document.getElementById('petStageBtn').addEventListener('click', () => {
    currentMode = 'wave';
    playChime();
    petMoodBadge.textContent = '💖 최고 좋아!';
    setTimeout(() => {
      currentMode = 'idle';
      petMoodBadge.textContent = '✨ 기분 최고!';
    }, 1800);
  });

  // 점수 및 마스터 배지 관리
  function addScore(pts) {
    score += pts;
    localStorage.setItem('hwata_score', String(score));
    try {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.set({ hwata_score: score });
      }
    } catch {}
    ensurePassCode(false);
    updateScoreUI();
    updateStatsUI();
  }

  function updateScoreUI() {
    scorePill.textContent = `🦷 스탬프 ${score} / 10점`;
    scoreFill.style.width = Math.min(100, Math.round((score / 10) * 100)) + '%';
    const vipCardBox = document.getElementById('vipCodeBox');
    const vipCardStatus = document.getElementById('vipCardStatus');
    if (score >= 10) {
      const code = ensurePassCode(true);
      vipHint.innerHTML = `🎊 <b>10점 달성! [마스터 배지: ${code}] 획득 완료!</b>`;
      if (vipCardBox) vipCardBox.textContent = code;
      if (vipCardStatus) {
        vipCardStatus.textContent = '★ 스마일 마스터 활성화됨';
        vipCardStatus.style.color = '#34d399';
      }
    } else {
      if (vipCardBox) vipCardBox.textContent = vipCode || 'HWATA-PASS-????';
      if (vipCardStatus) vipCardStatus.textContent = `스탬프 적립 중 (${score}/10)`;
    }
  }
  updateScoreUI();

  // 메인 탭 전환 로직
  const tabBtns = document.querySelectorAll('.tab-btn');
  const tabPanes = document.querySelectorAll('.tab-pane');
  tabBtns.forEach((btn) => {
    btn.addEventListener('click', () => {
      tabBtns.forEach((b) => b.classList.remove('active'));
      tabPanes.forEach((p) => p.classList.remove('active'));
      btn.classList.add('active');
      const targetPane = document.getElementById(btn.dataset.tab);
      if (targetPane) targetPane.classList.add('active');
      playTone(400, 'sine', 0.05, 0.03);
    });
  });

  // ----------------------------------------------------
  // 🪥 2분 바스법 양치 타이머 로직 (원형 프로그레스 링 & 인터랙티브 코칭)
  // ----------------------------------------------------
  const BRUSH_TOTAL_SEC = 120;
  let brushTimerInterval = null;
  let brushRemainSec = BRUSH_TOTAL_SEC;
  let isBrushPaused = false;

  const brushRing = document.getElementById('brushRing');
  const brushTimerTime = document.getElementById('brushTimerTime');
  const brushStepLabel = document.getElementById('brushStepLabel');
  const startBrushBtn = document.getElementById('startBrushBtn');
  const pauseBrushBtn = document.getElementById('pauseBrushBtn');
  const resetBrushBtn = document.getElementById('resetBrushBtn');
  const stepDots = document.querySelectorAll('.step-dot');

  const circumference = 2 * Math.PI * 50; // 314.159
  brushRing.style.strokeDasharray = `${circumference} ${circumference}`;
  brushRing.style.strokeDashoffset = '0';

  function setBrushProgress(remain) {
    const frac = remain / BRUSH_TOTAL_SEC;
    const offset = circumference - frac * circumference;
    brushRing.style.strokeDashoffset = String(offset);

    const m = Math.floor(remain / 60);
    const s = remain % 60;
    brushTimerTime.textContent = `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;

    // 4단계 분기 (0~30s: 1단계, 31~60s: 2단계, 61~90s: 3단계, 91~120s: 4단계)
    const elapsed = BRUSH_TOTAL_SEC - remain;
    let stepNum = 1;
    let stepText = '1. 상악 우측 어금니';
    if (elapsed > 90) {
      stepNum = 4;
      stepText = '4. 하악 우측 및 혀 닦기';
    } else if (elapsed > 60) {
      stepNum = 3;
      stepText = '3. 하악 좌측 & 전치부 안쪽';
    } else if (elapsed > 30) {
      stepNum = 2;
      stepText = '2. 상악 전치부 & 좌측 어금니';
    }

    stepDots.forEach((dot) => {
      dot.classList.toggle('active', Number(dot.dataset.step) === stepNum);
    });
    brushStepLabel.textContent = stepText;
  }

  startBrushBtn.addEventListener('click', () => {
    if (brushTimerInterval) return;
    currentMode = 'brush';
    startBrushBtn.style.display = 'none';
    pauseBrushBtn.style.display = 'inline-block';
    playChime();

    brushTimerInterval = setInterval(() => {
      if (brushRemainSec > 0) {
        brushRemainSec--;
        setBrushProgress(brushRemainSec);
        playTick();

        // 30초마다 단계 변경 차임벨
        if ([90, 60, 30].includes(brushRemainSec)) {
          playChime();
        }
      } else {
        // 타이머 완료!
        clearInterval(brushTimerInterval);
        brushTimerInterval = null;
        startBrushBtn.style.display = 'inline-block';
        pauseBrushBtn.style.display = 'none';
        currentMode = 'happy';
        playFanfare();

        todayBrushCount++;
        localStorage.setItem('hwata_today_brush', String(todayBrushCount));
        addScore(3);
        updateStatsUI();

        alert('🎉 참 잘했어요! 2분 바스법 양치를 완벽하게 마쳤습니다! (+3점 스탬프)');
        setTimeout(() => { if (currentMode === 'happy') currentMode = 'idle'; }, 2500);
      }
    }, 1000);
  });

  pauseBrushBtn.addEventListener('click', () => {
    if (brushTimerInterval) {
      clearInterval(brushTimerInterval);
      brushTimerInterval = null;
      pauseBrushBtn.textContent = '▶ 계속하기';
      currentMode = 'idle';
    } else {
      pauseBrushBtn.textContent = '⏸ 일시정지';
      currentMode = 'brush';
      brushTimerInterval = setInterval(() => {
        if (brushRemainSec > 0) {
          brushRemainSec--;
          setBrushProgress(brushRemainSec);
          playTick();
        } else {
          clearInterval(brushTimerInterval);
          brushTimerInterval = null;
          startBrushBtn.style.display = 'inline-block';
          pauseBrushBtn.style.display = 'none';
          currentMode = 'idle';
          playFanfare();
        }
      }, 1000);
    }
  });

  resetBrushBtn.addEventListener('click', () => {
    if (brushTimerInterval) {
      clearInterval(brushTimerInterval);
      brushTimerInterval = null;
    }
    brushRemainSec = BRUSH_TOTAL_SEC;
    setBrushProgress(BRUSH_TOTAL_SEC);
    startBrushBtn.style.display = 'inline-block';
    pauseBrushBtn.style.display = 'none';
    pauseBrushBtn.textContent = '⏸ 일시정지';
    brushStepLabel.textContent = '준비 단계';
    currentMode = 'idle';
    stepDots.forEach((dot, idx) => dot.classList.toggle('active', idx === 0));
  });

  // ----------------------------------------------------
  // 😬 15초 어금니 이완 인터랙티브 호흡 코치
  // ----------------------------------------------------
  const startRelaxBtn = document.getElementById('startRelaxBtn');
  const breatheCircle = document.getElementById('breatheCircle');
  const breatheText = document.getElementById('breatheText');
  const breatheSub = document.getElementById('breatheSub');
  const alarmIntervalSelect = document.getElementById('alarmIntervalSelect');
  const jawIntervalBadge = document.getElementById('jawIntervalBadge');

  let isRelaxing = false;
  startRelaxBtn.addEventListener('click', () => {
    if (isRelaxing) return;
    isRelaxing = true;
    startRelaxBtn.disabled = true;
    currentMode = 'happy';

    // 1단계: 숨 들이마시기 (4초)
    playRelaxTone();
    breatheCircle.className = 'breathe-circle breathing-in';
    breatheText.textContent = '숨 들이마시기...';
    breatheSub.textContent = '코로 천천히 숨을 깊게 들이마십니다 (4초)';

    setTimeout(() => {
      // 2단계: 어금니 2~3mm 떼고 턱 힘빼기 (7초)
      playTone(528, 'sine', 0.6, 0.07);
      breatheCircle.className = 'breathe-circle holding';
      breatheText.textContent = '어금니 2~3mm 떼기';
      breatheSub.textContent = '윗니-아랫니 사이 틈을 유지하고 어깨 긴장을 툭 푸세요 (7초)';

      setTimeout(() => {
        // 3단계: 천천히 내쉬기 (4초)
        playRelaxTone();
        breatheCircle.className = 'breathe-circle breathing-out';
        breatheText.textContent = '후- 내쉬기...';
        breatheSub.textContent = '입으로 편안하게 숨을 비워냅니다 (4초)';

        setTimeout(() => {
          breatheCircle.className = 'breathe-circle';
          breatheText.textContent = '이완 완료 ✨';
          breatheSub.textContent = '턱관절이 훨씬 가벼워졌어요! 꼬리 살랑살랑 (+2점)';
          playFanfare();
          todayRelaxCount++;
          localStorage.setItem('hwata_today_relax', String(todayRelaxCount));
          addScore(2);
          updateStatsUI();
          isRelaxing = false;
          startRelaxBtn.disabled = false;
          setTimeout(() => {
            currentMode = 'idle';
            breatheText.textContent = '어금니 살짝 떼기';
            breatheSub.textContent = '윗니와 아랫니 사이에 2~3mm 틈을 두고 어깨에 힘을 빼세요.';
          }, 3500);
        }, 4000);
      }, 7000);
    }, 4000);
  });

  // 알림 주기 설정
  alarmIntervalSelect.addEventListener('change', (e) => {
    const val = Number(e.target.value);
    jawIntervalBadge.textContent = `${val}분 주기`;
    try {
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
        chrome.runtime.sendMessage({ type: 'UPDATE_ALARM_INTERVAL', interval: val });
      }
    } catch {}
    playTone(500, 'sine', 0.1, 0.05);
  });

  // ----------------------------------------------------
  // 🐾 3D 펫 동물 변신 그리드 & 인터랙션
  // ----------------------------------------------------
  const speciesGrid = document.getElementById('speciesGrid');
  function renderSpeciesGrid() {
    speciesGrid.innerHTML = '';
    EXT_SPECIES_LIST.forEach((sp) => {
      const meta = EXT_SPECIES_META[sp];
      const card = document.createElement('div');
      card.className = 'species-card' + (currentSpecies === sp ? ' active' : '');
      const spName = currentLang === 'ja' ? meta.nameJa : currentLang === 'en' ? meta.nameEn : meta.name;
      card.innerHTML = `
        <span class="species-icon">${meta.icon}</span>
        <span class="species-name">${spName}</span>
      `;
      card.addEventListener('click', () => {
        currentSpecies = sp;
        localStorage.setItem('hwata_ext_species', currentSpecies);
        try {
          if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
            chrome.storage.local.set({ hwata_ext_species: currentSpecies });
          }
        } catch {}
        renderSpeciesGrid();
        updatePetHeaderTitle();
        currentMode = 'wave';
        playChime();
        setTimeout(() => { if (currentMode === 'wave') currentMode = 'idle'; }, 1600);
      });
      speciesGrid.appendChild(card);
    });
  }
  renderSpeciesGrid();

  // 펫 액션 버튼 이벤트들
  document.querySelectorAll('.action-btn-grid .opt-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      const act = btn.dataset.act;
      if (act === 'dog-sit') {
        dogPose = 'sit';
        localStorage.setItem('hwata_dog_pose', 'sit');
        currentMode = 'happy';
        playChime();
        setTimeout(() => (currentMode = 'idle'), 1000);
      } else if (act === 'dog-stand') {
        dogPose = 'stand4';
        localStorage.setItem('hwata_dog_pose', 'stand4');
        currentMode = 'happy';
        playChime();
        setTimeout(() => (currentMode = 'idle'), 1000);
      } else if (act === 'dog-fetch') {
        fetchRun = { emoji: '🪥', t0: performance.now() / 1000 };
        currentMode = 'happy';
        playChime();
      } else if (act === 'pet-pat') {
        currentMode = 'happy';
        playTone(600, 'sine', 0.25, 0.08);
        petMoodBadge.textContent = '💖 골골송~!';
        setTimeout(() => {
          currentMode = 'idle';
          petMoodBadge.textContent = '✨ 기분 최고!';
        }, 1800);
      } else if (act === 'pet-dance') {
        currentMode = 'wave';
        playFanfare();
        setTimeout(() => (currentMode = 'idle'), 2000);
      } else if (act === 'pet-brush-motion') {
        currentMode = 'brush';
        playTick();
        setTimeout(() => (currentMode = 'idle'), 2500);
      }
    });
  });

  // ----------------------------------------------------
  // 📊 습관 리포트 & 스트릭 UI 업데이트
  // ----------------------------------------------------
  function updateStatsUI() {
    document.getElementById('todayBrushCount').textContent = `${todayBrushCount}회`;
    document.getElementById('todayRelaxCount').textContent = `${todayRelaxCount}회`;
    document.getElementById('quizCorrectCount').textContent = `${quizCorrectCount}개`;
    document.getElementById('streakLabel').textContent = `연속 ${streakDays}일 달성`;

    const weeklyRow = document.getElementById('weeklyStreakRow');
    weeklyRow.innerHTML = '';
    const dayNames = ['월', '화', '수', '목', '금', '토', '일'];
    const currentDayIdx = (new Date().getDay() + 6) % 7; // 월:0 ~ 일:6

    dayNames.forEach((dName, idx) => {
      const isDone = idx <= currentDayIdx && (todayBrushCount > 0 || todayRelaxCount > 0 || streakDays > 1);
      const isToday = idx === currentDayIdx;
      const dayEl = document.createElement('div');
      dayEl.className = 'streak-day-item';
      dayEl.innerHTML = `
        <div class="streak-dot${isDone ? ' checked' : ''}${isToday ? ' today' : ''}">
          ${isDone ? '✓' : ''}
        </div>
        <span class="streak-day-name">${dName}</span>
      `;
      weeklyRow.appendChild(dayEl);
    });
  }
  updateStatsUI();

  document.getElementById('claimVipBtn').addEventListener('click', () => {
    // 탭 4(상담 & 혜택)로 전환하여 퀴즈 실행
    document.getElementById('tabChatBtn').click();
    runQuiz();
  });

  // ----------------------------------------------------
  // 💬 실시간 대화 & 혜택 & 예약 시스템 (기존 로직 계승)
  // ----------------------------------------------------
  function addMsg(role, html) {
    const div = document.createElement('div');
    div.className = 'msg ' + role;
    div.innerHTML = html;
    chatArea.appendChild(div);
    chatArea.scrollTop = chatArea.scrollHeight;
    return div;
  }

  // 초기 환영 메시지
  addMsg('pet', `
    🐾 <b>안녕하세요! 당신의 치아 건강 지킴이 화타펫이에요 멍!</b><br>
    • 상단 <b>[⏱️ 케어 타이머]</b>에서 2분 바스법 양치와 턱관절 스트레칭을 실천해 보세요.<br>
    • <b>[🐾 3D 펫]</b>에서 6종 동물 친구로 변신하거나 칫솔을 물어오게 해보세요.<br>
    • 궁금한 점이나 치아 고민은 아래 메뉴를 누르거나 언제든 편하게 말씀해 주세요! 🪥✨
  `);

  // 숏컷 버튼 핸들러
  document.querySelectorAll('.chip-nav .nav-chip').forEach((btn) => {
    btn.addEventListener('click', () => {
      const act = btn.dataset.act;
      if (act === 'selfcheck') runSelfCheck();
      else if (act === 'scaling') runScalingCheck();
      else if (act === 'mission') runDailyMission();
      else if (act === 'quiz') runQuiz();
      else if (act === 'myth') runMyth();
      else if (act === 'drama') runRadioDrama();
    });
  });

  // 치아상식 퀴즈
  const QUIZZES = [
    {
      q: '콜라·에너지드링크·커피 등 산성 음료를 마신 직후 가장 올바른 치아 관리법은?',
      opts: ['① 마시자마자 10초 안에 강하게 칫솔질하기', '② 물로 먼저 입안을 가볍게 헹구고 20~30분 뒤 양치하기', '③ 양치 없이 껌만 씹기'],
      ans: 1,
      exp: '산성 음료 직후엔 치아 에나멜(법랑질)이 일시적으로 연화돼요! 물로 먼저 가볍게 헹군 뒤 20~30분 후 양치해야 치아 마모를 예방할 수 있습니다.'
    },
    {
      q: '컴퓨터 몰입 중 무의식적으로 턱에 힘을 주고 어금니를 꽉 깨물 때 생길 수 있는 증상은?',
      opts: ['① 턱관절 통증과 치아 미세 균열(크랙)', '② 치아 미백 효과', '③ 턱뼈 축소'],
      ans: 0,
      exp: '평소 윗니와 아랫니는 2~3mm 떨어져 있는 것이 정상입니다. 모니터 작업 시 턱 긴장을 푸는 50분 이완 스트레칭을 꼭 실천하세요!'
    },
    {
      q: '만 19세 이상 대한민국 국민이라면 매년 건강보험 혜택을 받을 수 있는 구강 예방 관리는?',
      opts: ['① 연 1회 건강보험 스케일링', '② 월 1회 미백', '③ 5년에 1회 검진'],
      ans: 0,
      exp: '건강보험 스케일링은 매년 1월 1일~12월 31일 연 1회 적용되며, 미사용 시 당해 연도 혜택이 소멸되므로 잊지 말고 챙기세요!'
    }
  ];

  function runQuiz() {
    const q = QUIZZES[quizIdx % QUIZZES.length];
    quizIdx++;
    localStorage.setItem('hwata_quiz_idx', String(quizIdx));

    const div = addMsg('pet', `
      <b>✨ 화타의 치아상식 퀴즈 (+2점)</b><br>
      <b>Q. ${q.q}</b>
      <div class="card-box">
        ${q.opts.map((opt, i) => `<button type="button" class="opt-btn" data-idx="${i}">${opt}</button>`).join('')}
      </div>
    `);

    div.querySelectorAll('.opt-btn').forEach((b) => {
      b.addEventListener('click', () => {
        const userChoice = Number(b.dataset.idx);
        if (userChoice === q.ans) {
          playFanfare();
          currentMode = 'happy';
          quizCorrectCount++;
          localStorage.setItem('hwata_quiz_correct', String(quizCorrectCount));
          addScore(2);
          addMsg('pet', `🎉 <b>정답입니다! (+2점 적립 · 현재 ${score}/10점)</b><br>${q.exp}`);
          setTimeout(() => (currentMode = 'idle'), 1800);
        } else {
          playTone(250, 'sawtooth', 0.2, 0.06);
          addMsg('pet', `아쉬워요! 정답은 <b>${q.opts[q.ans]}</b> 입니다.<br>${q.exp}`);
        }
      });
    });
  }

  // 오늘의 구강 웰니스 퀘스트
  function runDailyMission() {
    currentMode = 'wave';
    setTimeout(() => (currentMode = 'idle'), 1500);
    const div = addMsg('pet', `
      <b>🎯 오늘의 구강 건강 3대 퀘스트 (+2점)</b><br>
      오늘 실천한 구강 케어 루틴을 체크하고 스탬프를 모아보세요!
      <div class="card-box">
        <button type="button" class="opt-btn" data-ms="water">💧 커피·식사 후 물로 입안 가볍게 헹구기</button>
        <button type="button" class="opt-btn" data-ms="floss">🧵 자기 전 치실 또는 치간칫솔 1회 사용하기</button>
        <button type="button" class="opt-btn" data-ms="jaw">😬 업무 중 턱에 힘 빼고 어금니 2mm 띄우기</button>
      </div>
    `);
    div.querySelectorAll('.opt-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        playFanfare();
        currentMode = 'happy';
        addScore(2);
        addMsg('pet', `🌟 <b>데일리 미션 완료! (+2점 적립 · 현재 ${score}/10점)</b><br>작은 습관이 평생의 치아 건강을 지킵니다. 정말 잘하셨어요 멍! 🐾`);
        setTimeout(() => (currentMode = 'idle'), 1500);
      });
    });
  }

  // 건강보험 스케일링 주기 확인
  function runScalingCheck() {
    const yr = new Date().getFullYear();
    const endOfYear = new Date(yr, 11, 31);
    const remainDays = Math.max(0, Math.ceil((endOfYear - new Date()) / (1000 * 60 * 60 * 24)));
    const div = addMsg('pet', `
      <b>⏳ ${yr}년 건강보험 스케일링 주기 확인</b><br>
      만 19세 이상이라면 매년 1월 1일~12월 31일 연 1회 건강보험 스케일링 혜택이 적용됩니다. (올해 갱신까지 <b>${remainDays}일</b> 남았어요!)
      <div class="card-box">
        <button type="button" class="opt-btn" data-sc="todo">📝 아직 안 받았어요 (체크리스트에 기억하기 +1점)</button>
        <button type="button" class="opt-btn" data-sc="done">✅ 올해 이미 받았어요! (+3점 스탬프)</button>
      </div>
    `);

    div.querySelectorAll('.opt-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const sc = btn.dataset.sc;
        if (sc === 'done') {
          addScore(3);
          playFanfare();
          addMsg('pet', `🎉 <b>올해 스케일링 실천 인증! (+3점 적립 · 현재 ${score}/10점)</b><br>6개월마다 정기 구강검진을 병행하시면 잇몸 건강을 더욱 튼튼하게 유지할 수 있습니다.`);
        } else {
          addScore(1);
          playChime();
          addMsg('pet', `📌 <b>스케일링 일정 리마인드 저장 완료! (+1점 적립 · 현재 ${score}/10점)</b><br>${yr}년 12월 31일이 지나면 당해 혜택이 자동 소멸되니 여유 있을 때 꼭 챙기세요!`);
        }
      });
    });
  }

  // 30초 구강 건강 자가점검
  function runSelfCheck() {
    const SYM = {
      cold: {
        q: '찬물 마실 때 이가 시려요',
        guide: '너무 세게 가로 방향으로 양치하면 잇몸 경계부가 마모(치경부 마모증)될 수 있어요. 부드러운 미세모 칫솔과 시린이 전용 치약을 사용해 잇몸에서 치아 방향으로 쓸어내리는 바스법 양치를 권장합니다.'
      },
      gum: {
        q: '양치할 때 잇몸에서 피가 나요',
        guide: '잇몸 경계부에 치태(플라그)가 쌓여 가벼운 염증이 생겼을 수 있어요. 칫솔모를 잇몸선 45도 각도로 대고 부드럽게 진동시킨 뒤 쓸어내리며, 하루 1회 치실 사용을 병행해 보세요.'
      },
      jaw: {
        q: '작업 중 턱이 뻐근하고 어금니에 힘이 들어가요',
        guide: '집중할 때 무의식적으로 윗니-아랫니가 닿는 이악물기 습관 때문일 수 있어요. 화타의 [⏱️ 케어 타이머] 탭에서 15초 어금니 이완 호흡 가이드를 지금 바로 실천해 보세요!'
      },
      brush: {
        q: '올바른 양치 순서를 잘 모르겠어요',
        guide: '상악 우측 ➔ 상악 전치·좌측 ➔ 하악 좌측·전치 ➔ 하악 우측 및 혀 순서로 각 구역당 30초씩 총 2분간 꼼꼼히 닦아주세요. 상단 [⏱️ 케어 타이머]의 2분 바스법 타이머가 도와드릴게요!'
      },
    };

    const div = addMsg('pet', `
      <b>🔍 30초 구강 건강 자가점검</b><br>현재 가장 신경 쓰이는 구강 관리 고민을 선택해 주세요!
      <div class="card-box">
        <button type="button" class="opt-btn" data-k="cold">① 찬물 마실 때 이가 시려요</button>
        <button type="button" class="opt-btn" data-k="gum">② 양치할 때 잇몸이 붓거나 피가 나요</button>
        <button type="button" class="opt-btn" data-k="jaw">③ 모니터 집중 후 턱이 뻐근해요</button>
        <button type="button" class="opt-btn" data-k="brush">④ 올바른 양치 방법을 알고 싶어요</button>
      </div>
    `);

    div.querySelectorAll('.opt-btn').forEach((b1) => {
      b1.addEventListener('click', () => {
        const s = SYM[b1.dataset.k] || SYM.cold;
        addScore(2);
        playFanfare();
        addMsg('pet', `🎯 <b>자가점검 가이드 (+2점 스탬프 적립 · 현재 ${score}/10점)</b><br>• <b>선택 증상:</b> ${s.q}<br>• <b>맞춤 관리 팁:</b> ${s.guide}<br><small style="color:#b8a396">※ 본 가이드는 일상 구강 위생 관리 참고용이며, 통증이 지속될 경우 가까운 치과 전문의의 진료를 권장합니다.</small>`);
      });
    });
  }

  // 치과 오해와 진실 (상식 팩트체크)
  function runMyth() {
    const myths = [
      '<b>Q. 스케일링을 받으면 치아가 깎여서 얇아지나요?</b><br>A. 전혀 아닙니다! 스케일러는 미세 초음파 진동으로 치아 표면에 달라붙은 단단한 치석만 떼어내는 원리입니다. 치아가 깎이지 않으니 안심하세요.',
      '<b>Q. 충치가 없는데도 찬물에 이가 시릴 수 있나요?</b><br>A. 네! 강한 칫솔질이나 이악물기 습관으로 잇몸 경계부 치아 표면이 파이는 치경부 마모증일 확률이 높습니다.',
      '<b>Q. 식사 직후 바로 양치하는 게 무조건 좋나요?</b><br>A. 탄산음료, 주스, 커피 등 산성 음료를 마셨을 때는 물로 먼저 헹구고 20~30분 뒤 양치하는 것이 치아 법랑질 보호에 훨씬 좋습니다.'
    ];
    const picked = myths[Math.floor(Math.random() * myths.length)];
    addMsg('pet', `👻 <b>치과 오해와 진실 팩트체크!</b><br>${picked}`);
  }

  // 힐링 라디오
  function runRadioDrama() {
    addMsg('pet', `📻 <b>화타의 치아 힐링 라디오</b><br>"오늘 하루도 수고 많으셨어요. 혹시 일하면서 어깨와 턱에 잔뜩 힘이 들어가진 않았나요? 지금 바로 윗니와 아랫니 사이를 2~3mm 살짝 떼어내고, 기분 좋은 미소를 지어보세요!" ✨🐕`);
  }

  // 채팅 폼 전송 핸들러
  const chatForm = document.getElementById('chatForm');
  const chatInput = document.getElementById('chatInput');
  chatForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const text = chatInput.value.trim();
    if (!text) return;
    addMsg('user', text);
    chatInput.value = '';

    // 강아지 명령 파싱 (앉아, 일어서, 칫솔 물어와 등)
    if (/앉아|sit|おすわり/i.test(text)) {
      dogPose = 'sit';
      localStorage.setItem('hwata_dog_pose', 'sit');
      currentMode = 'happy';
      playChime();
      addMsg('pet', '🐕 <b>착하게 얌전히 앉았어요 멍!</b> 꼬리 살랑살랑~');
      setTimeout(() => (currentMode = 'idle'), 1200);
      return;
    }
    if (/일어서|stand|立って/i.test(text)) {
      dogPose = 'stand4';
      localStorage.setItem('hwata_dog_pose', 'stand4');
      currentMode = 'happy';
      playChime();
      addMsg('pet', '🧍 <b>네 발로 씩씩하게 일어섰어요 멍!</b>');
      setTimeout(() => (currentMode = 'idle'), 1200);
      return;
    }
    if (/물어와|가져와|fetch/i.test(text)) {
      fetchRun = { emoji: '🪥', t0: performance.now() / 1000 };
      currentMode = 'happy';
      playChime();
      addMsg('pet', '🐕 <b>후다닥 칫솔을 물어올게요 멍! 🪥</b>');
      return;
    }

    // 구강 웰니스 키워드 응답
    if (/시리|시림|잇몸|피|치석|스케일링|턱|어금니/i.test(text)) {
      runSelfCheck();
      return;
    }
    if (/양치|타이머|칫솔/i.test(text)) {
      document.getElementById('tabCareBtn').click();
      return;
    }
    if (/퀴즈|미션|퀘스트/i.test(text)) {
      runQuiz();
      return;
    }

    // 기본 응답
    currentMode = 'wave';
    playTone(550, 'sine', 0.15, 0.05);
    setTimeout(() => {
      addMsg('pet', `멍멍! <b>"${text}"</b> — 치아 건강 체크가 필요하시면 상단의 [🔍 30초 자가체크], [✨ 치아상식 퀴즈], [⏱️ 케어 타이머]를 이용해 보세요! "앉아", "일어서", "칫솔 물어와"도 할 줄 알아요 🐾`);
      currentMode = 'idle';
    }, 500);
  });

})();
