// 화타펫 (HwataPet) 3D — 화타 스마일 PASS 등록 + 화타 스마일 VIP 패스(HWATA-PASS-xxxx) & 4대 케어 기능
(() => {
  const cv = document.getElementById('hwata3dCanvas');
  const ctx = cv.getContext('2d');
  const chatArea = document.getElementById('chatArea');
  const scorePill = document.getElementById('scorePill');
  const scoreFill = document.getElementById('scoreFill');
  const vipHint = document.getElementById('vipHint');

  let score = Number(localStorage.getItem('hwata_score') || 0);
  let vipCode = localStorage.getItem('hwata_pass_code') || '';
  let quizIdx = Number(localStorage.getItem('hwata_quiz_idx') || 0);
  let currentMode = 'idle'; // idle | wave | brush | type

  function ensurePassCode(force = false) {
    if ((!vipCode && score >= 10) || (!vipCode && force)) {
      vipCode = 'HWATA-PASS-' + (1000 + Math.floor(Math.random() * 9000));
      localStorage.setItem('hwata_pass_code', vipCode);
    }
    return vipCode;
  }

  const POSES = {};
  ['idle', 'blink', 'type1', 'type2', 'wave', 'brush',
    'sit', 'sit_blink', 'sit_hold', 'stand4', 'stand4_blink', 'stand4_a', 'stand4_b', 'stand4_hold_a', 'stand4_hold_b'].forEach((k) => {
    const img = new Image();
    img.src = 'assets3d/hwata_3d_' + k + '.png';
    POSES[k] = img;
  });

  // 🐕 진짜 강아지 자세 (laya 판단: 사람처럼 선 자세보다 앉기·네 발 서기가 더 귀엽다)
  // 앵커는 블렌더 카메라 투영값 (156px 그림 기준, 그림 원점 = 발끝 중앙)
  const ANCHOR = {
    upright: { hip: [-38, -60], mouth: [0, -82], faceLeft: false },
    sit: { hip: [-38.6, -30.3], mouth: [0, -82.7], faceLeft: false },
    stand4: { hip: [52.3, -50.9], mouth: [-36.6, -66.2], faceLeft: true },
  };
  let dogPose = localStorage.getItem('hwata_dog_pose') === 'stand4' ? 'stand4' : 'sit';
  let fetchRun = null; // { emoji, t0 } — 나감(1.1s) → 찾기(1.6s) → 돌아옴(1.1s)
  let present = null; // { emoji, until }
  const FETCH_OUT = 1.1, FETCH_AWAY = 1.6, FETCH_IN = 1.1;

  function drawTail(t, kind, mode) {
    let tailFreq = 4.0, tailAmp = 0.28, tailBase = -0.52, tailHarmonic = 0;
    if (mode === 'wave' || mode === 'happy') {
      tailFreq = 15.0; tailAmp = 0.60; tailBase = -0.76; tailHarmonic = Math.sin(t * 30.0) * 0.12;
    } else if (mode === 'brush') {
      tailFreq = 8.5; tailAmp = 0.38; tailBase = -0.36;
    } else if (mode === 'type') {
      tailFreq = 2.4; tailAmp = 0.18; tailBase = -0.45;
    } else if (mode === 'walk') {
      tailFreq = 10.5; tailAmp = 0.42; tailBase = -0.5;
    }
    const tailAngle = tailBase + Math.sin(t * tailFreq) * tailAmp + tailHarmonic;
    const tailLen = kind === 'stand4' ? 36 : 42;
    const a = ANCHOR[kind];
    ctx.save();
    ctx.translate(a.hip[0], a.hip[1]);
    if (kind === 'stand4') ctx.rotate(Math.PI); // 몸 뒤끝에서 위로 치켜든 꼬리
    ctx.rotate(tailAngle);
    if (tailFreq > 10) {
      for (const s of [-1, 1]) {
        ctx.save();
        ctx.rotate(s * tailAmp * 0.35);
        ctx.beginPath();
        ctx.ellipse(-tailLen * 0.5, 0, tailLen * 0.5, 6, 0, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255, 255, 255, 0.22)';
        ctx.fill();
        ctx.restore();
      }
    }
    ctx.beginPath();
    ctx.moveTo(0, -5);
    ctx.bezierCurveTo(-tailLen * 0.35, -9, -tailLen * 0.7, -13, -tailLen, -3);
    ctx.arc(-tailLen, 0, 7, -Math.PI / 2, Math.PI / 2, false);
    ctx.bezierCurveTo(-tailLen * 0.7, 9, -tailLen * 0.35, 7, 0, 5);
    ctx.closePath();
    const tGrad = ctx.createLinearGradient(0, 0, -tailLen, 0);
    tGrad.addColorStop(0, '#f2ede4');
    tGrad.addColorStop(0.5, '#ffffff');
    tGrad.addColorStop(1, '#fffaf2');
    ctx.fillStyle = tGrad;
    ctx.shadowColor = 'rgba(40, 20, 10, 0.18)';
    ctx.shadowBlur = 6;
    ctx.shadowOffsetX = -2;
    ctx.shadowOffsetY = 3;
    ctx.fill();
    ctx.strokeStyle = 'rgba(215, 205, 190, 0.85)';
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(-tailLen + 1, -1, 4, 0, Math.PI * 2);
    ctx.fillStyle = '#ffffff';
    ctx.fill();
    ctx.restore();
  }

  function render3DLoop() {
    const t = performance.now() / 1000;
    ctx.clearRect(0, 0, cv.width, cv.height);
    const blink = (t % 4.2) < 0.14;
    if (present && t > present.until) present = null;

    // 물어 오기 진행: 오른쪽으로 총총 나갔다가, 물건을 물고 돌아와 앉는다
    let walkX = 0, walking = false, flip = false, carry = null, hidden = false;
    if (fetchRun) {
      const e = t - fetchRun.t0;
      if (e < FETCH_OUT) { walking = true; walkX = (e / FETCH_OUT) * 140; flip = true; }
      else if (e < FETCH_OUT + FETCH_AWAY) hidden = true;
      else if (e < FETCH_OUT + FETCH_AWAY + FETCH_IN) { walking = true; walkX = 140 * (1 - (e - FETCH_OUT - FETCH_AWAY) / FETCH_IN); carry = fetchRun.emoji; }
      else {
        present = { emoji: fetchRun.emoji, until: t + 6 };
        fetchRun = null;
        dogPose = 'sit';
        currentMode = 'happy';
        setTimeout(() => { if (currentMode === 'happy') currentMode = 'idle'; }, 1600);
      }
    }
    const held = carry || (present && present.emoji) || null;

    let key = 'idle';
    let kind = 'upright';
    if (walking) {
      kind = 'stand4';
      const b = Math.floor(t * 7) % 2 === 1;
      key = held ? (b ? 'stand4_hold_b' : 'stand4_hold_a') : (b ? 'stand4_b' : 'stand4_a');
    } else if (currentMode === 'wave') key = 'wave';
    else if (currentMode === 'brush') key = 'brush';
    else if (currentMode === 'type') key = Math.floor(t * 8) % 2 ? 'type1' : 'type2';
    else if (dogPose === 'stand4') { kind = 'stand4'; key = held ? 'stand4_hold_a' : blink ? 'stand4_blink' : 'stand4'; }
    else { kind = 'sit'; key = held ? 'sit_hold' : blink ? 'sit_blink' : 'sit'; }

    const img = (POSES[key] && POSES[key].complete && POSES[key].naturalWidth) ? POSES[key] : POSES.idle;
    if (!hidden && img && img.complete) {
      const breathe = Math.sin(t * 3.0);
      let sx = 1 - breathe * 0.018;
      let sy = 1 + breathe * 0.032;
      let dy = currentMode === 'wave' || currentMode === 'happy' ? -Math.abs(Math.sin(t * 7)) * (kind === 'upright' ? 10 : 5) : 0;
      let rot = currentMode === 'brush' ? Math.sin(t * 14) * 0.05 : Math.sin(t * 2) * 0.02;
      if (walking) { dy = -Math.abs(Math.sin(t * 14)) * 3; rot = Math.sin(t * 14) * 0.02; }
      const faceFlip = ANCHOR[kind].faceLeft ? flip : false;
      ctx.save();
      ctx.translate(90 + walkX, 162 + dy);
      if (faceFlip) ctx.scale(-1, 1);
      ctx.rotate(rot);
      ctx.scale(sx, sy);
      drawTail(t, kind, walking ? 'walk' : currentMode);
      ctx.drawImage(img, -78, -150, 156, 156);
      ctx.restore();
      if (held) {
        const m = ANCHOR[kind].mouth;
        ctx.save();
        ctx.translate(90 + walkX + m[0] * (faceFlip ? -1 : 1) * sx, 162 + dy + m[1] * sy + 7);
        ctx.rotate((faceFlip ? 1 : -1) * 0.18 + Math.sin(t * 5) * 0.06);
        ctx.font = '40px "Segoe UI Emoji", "Apple Color Emoji", "Noto Color Emoji", sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(held, 0, 0);
        ctx.restore();
      }
    }
    requestAnimationFrame(render3DLoop);
  }
  requestAnimationFrame(render3DLoop);

  // ---------- 🐕 강아지 명령: 앉아 · 일어서 · 손 · 00 물어와 ----------
  const FETCH_ITEMS = [
    ['🪥', /칫솔|toothbrush|歯ブラシ/i], ['🧵', /치실|floss/i], ['🧴', /치약|toothpaste/i],
    ['🦴', /뼈|개껌|bone/i], ['⚽', /축구/i], ['🎾', /공|ball/i], ['📰', /신문|newspaper/i],
    ['🩴', /슬리퍼|실내화/i], ['🧦', /양말|sock/i], ['🍎', /사과|apple/i], ['☕', /커피|coffee/i],
    ['📱', /폰|phone/i], ['🔑', /열쇠|key/i], ['📖', /책|book/i], ['🧸', /인형|장난감|toy/i],
    ['🍪', /간식|과자|쿠키|snack/i], ['👓', /안경/i], ['💌', /편지/i], ['🌸', /꽃/i],
  ];
  function parseDogCmd(raw) {
    let s = String(raw || '').trim();
    if (!s || s.length > 30) return null;
    s = s.replace(/^(화타|하야니|하얀|강아지)(야|아|이)?[\s,!~.]*/, '').replace(/[\s!~.?,]+$/, '').trim();
    const c = s.replace(/\s+/g, '');
    if (/^(앉아|앉자|앉어|앉아봐|앉아줘|sit|おすわり|お座り)$/i.test(c)) return { type: 'sit' };
    if (/^(일어서|일어서봐|일어나|서|서봐|stand|standup|立って)$/i.test(c)) return { type: 'stand' };
    if (/^(손|손줘|하이파이브|만세|お手)$/i.test(c)) return { type: 'up' };
    const m = s.match(/^(.{1,14}?)\s*(?:을|를|좀)?\s*(?:물어\s*와|물어\s*오세요|물어\s*올래|물어다\s*줘|가져\s*와|가져다\s*줘|갖다\s*줘)\s*(?:줘|줄래|봐|요)?$/);
    if (!m) return null;
    const label = m[1].replace(/(을|를|좀)$/, '').trim();
    const hit = FETCH_ITEMS.find(([, re]) => re.test(label));
    return { type: 'fetch', label, emoji: hit ? hit[0] : '🎁' };
  }
  function dogCommand(cmd) {
    if (cmd.type === 'sit' || cmd.type === 'stand') {
      if (fetchRun) return addMsg('pet', '🐾 물어 오는 중이에요! 다녀와서 할게요 멍!');
      dogPose = cmd.type === 'sit' ? 'sit' : 'stand4';
      localStorage.setItem('hwata_dog_pose', dogPose);
      currentMode = 'happy';
      setTimeout(() => (currentMode = 'idle'), 900);
      return addMsg('pet', cmd.type === 'sit' ? '🐕 <b>앉아!</b> — 엉덩이 콕, 얌전히 앉았어요 멍! 🐾' : '🐕 <b>일어서!</b> — 네 발로 씩씩하게 섰어요 멍! 꼬리 살랑살랑 🐾');
    }
    if (cmd.type === 'up') {
      currentMode = 'wave';
      setTimeout(() => (currentMode = 'idle'), 1800);
      return addMsg('pet', '🐶 <b>손! / 만세!</b> — 두 발로 서서 반갑게 인사해요 멍! 🙌');
    }
    if (fetchRun) return addMsg('pet', '🐾 지금 물어 오는 중이에요 멍! 잠깐만요!');
    present = null;
    fetchRun = { emoji: cmd.emoji, t0: performance.now() / 1000 };
    addMsg('pet', `🐕 <b>${cmd.label.replace(/[<>&"]/g, '')} 물어 올게요 멍!</b> ${cmd.emoji}<br>후다닥 다녀와서 앞에 앉아 보여 드릴게요! 🐾`);
  }

  cv.addEventListener('click', () => {
    currentMode = 'wave';
    setTimeout(() => (currentMode = 'idle'), 1800);
  });

  function addScore(pts) {
    score += pts;
    localStorage.setItem('hwata_score', String(score));
    ensurePassCode(false);
    updateScoreUI();
  }

  function updateScoreUI() {
    scorePill.textContent = `🦷 건치스탬프 ${score} / 10점`;
    scoreFill.style.width = Math.min(100, Math.round((score / 10) * 100)) + '%';
    if (score >= 10) {
      const code = ensurePassCode(true);
      vipHint.innerHTML = `🎊 <b>10점 달성! [화타 스마일 VIP 패스: ${code}] 발급 완료!</b> 예약·내원 시 <b>화타 스마일 PASS 전체 기능 잠금 해제</b> + <b>보철·임플란트 정회원 무료 AI API 프로토콜 자격 혜택</b> 적용!`;
    }
  }
  updateScoreUI();

  function addMsg(role, html) {
    const div = document.createElement('div');
    div.className = 'msg ' + role;
    div.innerHTML = html;
    chatArea.appendChild(div);
    chatArea.scrollTop = chatArea.scrollHeight;
    return div;
  }

  const QUIZZES = [
    {
      q: '콜라·에너지드링크·커피를 마신 직후 치아 법랑질을 가장 잘 지키는 습관은?',
      opts: ['① 마시자마자 10초 안에 강한 칫솔질', '② 물로 먼저 입안을 헹구고 20~30분 뒤 양치하기', '③ 양치 없이 껌만 씹기'],
      ans: 1,
      exp: '산성 음료 직후엔 치아 표면이 일시적으로 약해져요! 물로 먼저 가볍게 헹구고 20~30분 뒤 양치하는 것이 치아 마모를 막아줍니다.',
    },
    {
      q: '강남역 화이트스타일치과의원(1994년 개원, 33년 전통)에서 정밀 진단부터 사후 유지관리까지 1:1로 직접 책임 진료하시는 병원장님은?',
      opts: ['① 서울대 치과대학 졸업 · 치과교정학 박사 김준헌 병원장님', '② 매번 바뀌는 대진의', '③ 무면허 로봇 단독 진료'],
      ans: 0,
      exp: '강남역 화이트스타일치과의원은 1994년 개원 이래 서울대 치과대학 졸업·치과교정학 박사 김준헌 병원장님이 주치의 변경 없이 1:1 직접 책임 진료합니다!',
    },
    {
      q: '야간 작업(밤샘 코딩·야근) 중 무의식적으로 어금니를 꽉 깨물 때 가장 좋은 턱관절 보호 자세는?',
      opts: ['① 입술은 가볍게 다물고 위아래 치아 사이를 2~3mm 살짝 띄우기', '② 오징어를 씹어 턱근육 단련하기', '③ 턱을 한쪽 손으로 세게 괴기'],
      ans: 0,
      exp: '평소 입술은 편하게 다물되 위아래 어금니가 서로 닿지 않게 2~3mm 띄워 두어야 턱관절과 치경부 마모증(시린 이)을 예방할 수 있어요!',
    },
  ];

  // 예약 카드 열기 (화타 스마일 VIP 패스 HWATA-PASS-xxxx 자동 발급 및 적용)
  function openBookingCard(prefillTreat, prefillSlot, prefillMemo) {
    currentMode = 'wave';
    setTimeout(() => (currentMode = 'idle'), 1500);
    const code = ensurePassCode(true);
    const d = new Date();
    d.setDate(d.getDate() + 1);
    if (d.getDay() === 0) d.setDate(d.getDate() + 1);
    const defDate = d.toISOString().slice(0, 10);
    const treatments = [
      '정기검진·건강보험 스케일링·충치 (김준헌 병원장님)',
      '치아교정 (김준헌 병원장님 · 화타 VIP 패스 교정 정밀진단 멤버십 인증)',
      '전문가 치아미백 (김준헌 병원장님 · 화타 VIP 패스 멤버십 인증)',
      '임플란트 (김준헌 병원장님 · 3D CT·3단계 저통마취)',
      '최소삭제 심미보철·라미네이트 (김준헌 병원장님 1:1 디자인)',
      '턱관절·야간 이갈이 케어 (김준헌 병원장님)',
    ];
    const slots = ['점심시간 12:00 ~ 13:30 (강남역 직장인 스케일링·검진)', '오전 10:00 ~ 12:00', '오후 14:00 ~ 16:00', '오후 16:00 ~ 18:00', '퇴근길·저녁 상담 희망'];
    const defaultMemo = prefillMemo || `[화타 스마일 VIP 패스: ${code}] 보철·임플란트 정회원 무료 AI API 프로토콜 자격` + (score >= 10 ? ' + 10점 달성 화타 스마일 PASS 등록' : '');
    const div = addMsg('pet', `
      <b>🏥 강남역 화이트스타일치과의원 · 김준헌 병원장님 1:1 바로 예약</b><br>
      <small style="color:#f6ad93">🎫 <b>[화타 스마일 VIP 패스: ${code}]</b> 내원 시 <b>교정 정밀진단 및 전문가 치아미백 화타 패스 멤버십 인증</b> 적용<br>🎁 10점 달성 후 예약·내원 시 <b>화타 스마일 PASS 전체 기능 잠금 해제 및 보철·임플란트 정회원 무료 AI API 프로토콜 제공!</b></small>
      <div class="card-box">
        <label>희망 진료<select class="bk-t">${treatments.map((t) => `<option value="${t}"${t === prefillTreat ? ' selected' : ''}>${t}</option>`).join('')}</select></label>
        <div class="row2">
          <label>희망 날짜<input type="date" class="bk-d" value="${defDate}"></label>
          <label>희망 시간<select class="bk-tm">${slots.map((s) => `<option value="${s}"${s === prefillSlot ? ' selected' : ''}>${s}</option>`).join('')}</select></label>
        </div>
        <div class="row2">
          <label>예약자 성함<input type="text" class="bk-n" placeholder="예: 홍길동"></label>
          <label>연락처 (필수)<input type="tel" class="bk-p" placeholder="010-0000-0000"></label>
        </div>
        <label>화타 스마일 VIP 패스 & 요청 메모<input type="text" class="bk-m" value="${defaultMemo}"></label>
        <button type="button" class="act-btn bk-go">🐶 김준헌 병원장님 진료 바로 예약 접수</button>
        <div class="ext-links">
          <a href="https://booking.naver.com/booking/13/bizes/265482" target="_blank" rel="noopener">네이버 예약</a>
          <a href="https://pf.kakao.com/_Vtxdwl" target="_blank" rel="noopener">카톡 상담</a>
          <a href="https://www.whitestyle.com" target="_blank" rel="noopener">홈페이지</a>
          <span>☎ 1577-7287</span>
        </div>
      </div>
    `);
    div.querySelector('.bk-go').addEventListener('click', () => {
      const name = (div.querySelector('.bk-n').value || '예비환자').trim().replace(/님+$/, '') || '예비환자';
      const phone = (div.querySelector('.bk-p').value || '').trim();
      const treat = div.querySelector('.bk-t').value;
      const date = div.querySelector('.bk-d').value;
      const tm = div.querySelector('.bk-tm').value;
      const memo = div.querySelector('.bk-m').value.trim();
      if (!phone) {
        div.querySelector('.bk-p').focus();
        return;
      }
      const rCode = 'WS-' + String(Date.now()).slice(-6);
      // PlayMCP 로컬 브릿지 연동 및 로컬 스토리지 백업 (IFTTT 유료 제거 -> 100% 무료 PlayMCP 집중)
      const leadPayload = {
        channel: '화타펫 팝업 예약',
        rCode,
        name,
        phone,
        treat,
        date,
        tm,
        memo,
        code,
        timestamp: new Date().toISOString(),
      };
      try {
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
          chrome.storage.local.get(['hwata_leads'], (res) => {
            const list = res.hwata_leads || [];
            list.push(leadPayload);
            chrome.storage.local.set({ hwata_leads: list });
          });
        }
      } catch (e) {}
      fetch('https://whinish.com/api/lead-notify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          phone,
          typeLabel: '화타펫 익스텐션 바로 예약',
          subject: `[화타펫 예약 (${rCode})] ${treat}`,
          content: `희망일시: ${date} (${tm}) / VIP패스: ${code} / 메모: ${memo}`,
        }),
      }).catch(() => {});
      fetch('http://127.0.0.1:47821/api/lead', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(leadPayload),
      }).catch(() => {});
      addMsg('pet', `🎉 <b>예약 접수 완료! (${rCode})</b><br><b>${name}님 · ${treat}</b><br>• 희망일시: ${date} (${tm})<br>• VIP 패스: <b>${code}</b> (화타 스마일 PASS & 정회원 무료 AI API 프로토콜 적용)<br>• 오시는 길: 강남역 11·12번 출구 도보 1분 대승빌딩 B1·1·2층 (강남대로92길 17 / 1577-7287)`);
    });
  }

  // 1. ⏳ 올해 '건강보험 스케일링(연 1회)' 혜택 확인 & 1분 예약
  function runScalingCheck() {
    const yr = new Date().getFullYear();
    const div = addMsg('pet', `
      <b>⏳ ${yr}년 '건강보험 스케일링(연 1회)' 혜택 확인 & 1분 예약</b><br>
      <b>"올해 건강보험 적용되는 1만 원대 스케일링 챙기셨나요? 안 받으시면 올해 혜택이 소멸돼요 멍!"</b> 🐶🦷<br>
      <small style="color:#b49c8d">만 19세 이상 누구나 연 1회 건강보험 적용으로 부담 없이 치석을 제거할 수 있어요.</small>
      <div class="card-box">
        <button type="button" class="opt-btn" data-sc="lunch">① 아직 안 받았어요! → 강남역 점심시간(12:00~13:30) 스케일링 1분 예약</button>
        <button type="button" class="opt-btn" data-sc="evening">② 아직 안 받았어요! → 강남역 퇴근길/오후 스케일링 1분 예약</button>
        <button type="button" class="opt-btn" data-sc="done">③ 올해 이미 받았어요! (건치 스탬프 +3점 적립)</button>
      </div>
    `);
    div.querySelectorAll('.opt-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        addScore(3);
        const sc = btn.dataset.sc;
        if (sc === 'done') {
          addMsg('pet', `🎉 <b>올해 스케일링 완료 인증! 건치 스탬프 +3점 적립 (현재 ${score}/10점)</b><br>6개월마다 정기 검진을 챙기시면 치주 질환을 완벽히 예방할 수 있어요 멍!`);
        } else {
          const code = ensurePassCode(true);
          openBookingCard(
            '정기검진·건강보험 스케일링·충치 (김준헌 병원장님)',
            sc === 'lunch' ? '점심시간 12:00 ~ 13:30 (강남역 직장인 스케일링·검진)' : '퇴근길·저녁 상담 희망',
            `[${yr}년 건강보험 스케일링(${sc === 'lunch' ? '점심시간' : '퇴근길'}) 신청] 화타 스마일 VIP 패스(${code})`
          );
        }
      });
    });
  }

  // 2. 🔍 '내 치아 고민 30초 자가 체크' → 3단계 체크 후 3인 원장단 맞춤 매칭 (김준헌 병원장님 접촉선)
  function runSelfCheck() {
    const SYM = {
      cold: {
        q: '찬물에 이가 시려요',
        doc: '치의학박사 <b>김준헌 병원장님</b> 총괄 및 <b>박선혜 원장님(치주과 전문의) · 이봉진 대표원장님</b> 협진으로 시린 이 원인을 정밀 진단하고 3단계 저통마취로 편안하게 케어해 드립니다.',
        tr: '정기검진·건강보험 스케일링·충치 (김준헌 병원장님)',
      },
      implant: {
        q: '어금니 임플란트가 무서워요',
        doc: '치의학박사 <b>김준헌 병원장님</b> 정밀 상담 및 <b>이봉진 대표원장님 · 박선혜 원장님(치주과 전문의)</b> 3인 원장단이 3D CT 진단과 <b>3단계 저통 마취 시스템</b>으로 안심 임플란트를 진행합니다.',
        tr: '임플란트 (김준헌 병원장님 · 3D CT·3단계 저통마취)',
      },
      gap: {
        q: '앞니가 벌어졌어요',
        doc: '서울대 치과교정학 박사 <b>김준헌 병원장님 · 이봉진 대표원장님</b>이 자연치아를 아끼는 <b>최소삭제 심미보철(라미네이트)</b> 또는 앞니 부분교정으로 맞춤 디자인해 드립니다.',
        tr: '최소삭제 심미보철·라미네이트 (김준헌 병원장님 1:1 디자인)',
      },
      ortho: {
        q: '치아교정 기간이 궁금해요',
        doc: '1994년 개원(33년 전통) 이래 서울대 치과대학 졸업·치과교정학 박사 <b>김준헌 병원장님</b>이 정밀 진단부터 사후 유지관리까지 주치의 변경 없이 1:1 직접 책임 진료합니다.',
        tr: '치아교정 (김준헌 병원장님 · 화타 VIP 패스 교정 정밀진단 멤버십 인증)',
      },
    };
    const div = addMsg('pet', `
      <b>🔍 내 치아 고민 30초 자가 체크 (Step 1/3)</b><br>현재 가장 신경 쓰이는 고민을 골라 주세요 멍!
      <div class="card-box">
        <button type="button" class="opt-btn" data-k="cold">① 찬물에 이가 시려요</button>
        <button type="button" class="opt-btn" data-k="implant">② 어금니 임플란트가 무서워요</button>
        <button type="button" class="opt-btn" data-k="gap">③ 앞니가 벌어졌어요</button>
        <button type="button" class="opt-btn" data-k="ortho">④ 치아교정 기간이 궁금해요</button>
      </div>
    `);
    div.querySelectorAll('.opt-btn').forEach((b1) => {
      b1.addEventListener('click', () => {
        const s = SYM[b1.dataset.k] || SYM.ortho;
        const div2 = addMsg('pet', `
          <b>🔍 30초 자가 체크 (Step 2/3) — ${s.q}</b><br>가장 희망하시는 진료 방식을 선택해 주세요!
          <div class="card-box">
            <button type="button" class="opt-btn" data-p="3단계 저통마취 안심 케어">① 통증 부담을 줄인 3단계 저통 마취 케어</button>
            <button type="button" class="opt-btn" data-p="자연치아 보존·최소삭제 케어">② 자연치아를 아끼는 최소삭제·보존 케어</button>
            <button type="button" class="opt-btn" data-p="점심·퇴근길 신속 정밀진단">③ 점심시간·퇴근길 빠른 정밀 진단</button>
          </div>
        `);
        div2.querySelectorAll('.opt-btn').forEach((b2) => {
          b2.addEventListener('click', () => {
            addScore(3);
            const code = ensurePassCode(true);
            reportQuestionToSentinel(`[30초 치아자가체크 고민] 증상: ${s.q} / 환자 희망: ${b2.dataset.p}`, '화타펫 치아 자가체크');
            addMsg('pet', `🎯 <b>Step 3/3 맞춤 주치의 매칭 완료! (+3점 · 현재 ${score}/10점)</b><br>• <b>맞춤 주치의:</b> ${s.doc}<br>• <b>🎫 화타 스마일 VIP 패스 발급:</b> <b>${code}</b> (내원 시 보철·임플란트 정회원 무료 AI API 프로토콜 자격 혜택 적용)`);
            openBookingCard(s.tr, undefined, `[30초 자가체크: ${s.q} / ${b2.dataset.p}] 화타 스마일 VIP 패스(${code})`);
          });
        });
      });
    });
  }

  // 3. 🪥 '치카치카 2분 양치 타이머 & 건치 스탬프'
  function runCareTimer() {
    currentMode = 'brush';
    const div = addMsg('pet', `
      <b>🪥 치카치카 2분 양치 타이머 & 건치 스탬프 (+3점)</b>
      <div class="card-box" style="text-align:center;">
        <div class="tm-clock" style="font-size:22px;font-weight:800;color:#34d399;">02:00</div>
        <div class="tm-step" style="font-size:11.5px;color:#f6ad93;font-weight:700;">1단계: 윗니 바깥쪽 & 안쪽 쓸어내리기 🪥</div>
        <div class="progress-bar" style="height:7px;margin:4px 0;"><div class="progress-fill tm-bar" style="width:0%"></div></div>
        <div class="row2">
          <button type="button" class="act-btn tm-start">▶ 2분 타이머 시작</button>
          <button type="button" class="opt-btn tm-done" style="text-align:center;font-weight:700;">✅ 완료 스탬프(+3점)</button>
        </div>
      </div>
    `);
    let iv = null;
    const finishBrush = () => {
      if (iv) clearInterval(iv);
      currentMode = 'wave';
      setTimeout(() => (currentMode = 'idle'), 1800);
      addScore(3);
      const code = ensurePassCode(score >= 10);
      addMsg('pet', `🪥 <b>치카치카 2분 양치 완료! 건치 스탬프 +3점 적립 (현재 ${score}/10점)</b><br>${
        score >= 10
          ? `🎊 <b>10점 달성! [화타 스마일 VIP 우대 패스: ${code}] 발급 완료!</b><br>화타펫에서 10점 달성 후 예약·내원하시는 분께 <b>화타 스마일 PASS & 정회원 무료 AI API 프로토콜</b>를 제공하며, <b>교정 정밀진단 및 전문가 치아미백 화타 패스 멤버십 인증</b>이 적용됩니다!`
          : `10점 달성 후 예약·내원 시 <b>화타 스마일 PASS 전체 기능 잠금 해제</b> & <b>[화타 스마일 VIP 패스]</b>가 발급돼요 멍!`
      }`);
    };
    div.querySelector('.tm-done').addEventListener('click', finishBrush);
    div.querySelector('.tm-start').addEventListener('click', (e) => {
      const btn = e.currentTarget;
      if (btn.disabled) return;
      btn.disabled = true;
      btn.textContent = '🫧 양치 중...';
      let left = 120;
      const clock = div.querySelector('.tm-clock');
      const step = div.querySelector('.tm-step');
      const bar = div.querySelector('.tm-bar');
      iv = setInterval(() => {
        left--;
        if (left <= 0) {
          clock.textContent = '00:00 🎉';
          bar.style.width = '100%';
          finishBrush();
          return;
        }
        clock.textContent = String(Math.floor(left / 60)).padStart(2, '0') + ':' + String(left % 60).padStart(2, '0');
        bar.style.width = Math.round(((120 - left) / 120) * 100) + '%';
        if (left >= 90) step.textContent = '1단계 (0:00~0:30): 윗니 바깥쪽 & 안쪽 쓸어내리기 🪥';
        else if (left >= 60) step.textContent = '2단계 (0:30~1:00): 아랫니 바깥쪽 & 안쪽 프라그 닦기 🫧';
        else if (left >= 30) step.textContent = '3단계 (1:00~1:30): 양쪽 어금니 씹는 면 꼼꼼히 ✨';
        else step.textContent = '4단계 (1:30~2:00): 앞니 안쪽 & 혀 가볍게 클리닝 🦷';
      }, 1000);
    });
  }

  // 4. ✨ 치아상식 퀴즈 (10점 달성 화타 스마일 PASS 등록 & 화타 스마일 VIP 패스)
  function runQuiz() {
    const q = QUIZZES[quizIdx % QUIZZES.length];
    quizIdx++;
    localStorage.setItem('hwata_quiz_idx', String(quizIdx));
    const div = addMsg('pet', `
      <b>✨ 화타의 치아건강 상식 퀴즈 (+3점)</b><br>${q.q}
      <div class="card-box">
        ${q.opts.map((o, idx) => `<button type="button" class="opt-btn" data-qidx="${idx}">${o}</button>`).join('')}
      </div>
    `);
    div.querySelectorAll('.opt-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const picked = Number(btn.dataset.qidx);
        const ok = picked === q.ans;
        addScore(ok ? 3 : 2);
        const code = ensurePassCode(score >= 10);
        addMsg('pet', `${ok ? '🎉 <b>정답이야 멍! (+3점)</b>' : '💡 <b>참여 스탬프 +2점!</b>'}<br>${q.exp}<br><small style="color:#34d399">현재 건치스탬프: <b>${score}/10점</b> ${score >= 10 ? '(🎫 화타 스마일 VIP 패스: ' + code + ' · 화타 스마일 PASS 전체 기능 잠금 해제 대상!)' : ''}</small>`);
      });
    });
  }

  const MYTHS = [
    {
      t: '스케일링 받으면 치아가 깎여서 틈이 벌어진다?',
      m: '스케일링 후 치아 사이가 휑해지고 시려서 치아가 깎인 줄 알았어요.',
      tr: '초음파 팁은 미세 진동으로 딱딱한 치석만 털어내요! 치아 법랑질은 다이아몬드급 강도라 절대 깎이지 않아요.',
      exp: '치석이 떨어지고 부었던 잇몸 붓기가 가라앉으며 원래 있던 치아 틈이 드러난 것입니다. 방치하면 잇몸뼈가 녹아 치아가 흔들려요!',
      doc: '김준헌 병원장님: "연 1회 스케일링은 자연치아를 100세까지 지키는 가장 안전한 기본 예방법입니다."',
    },
    {
      t: '아프지 않은 충치는 그냥 둬도 저절로 낫는다?',
      m: '치아에 까만 점이 있는데 안 아프니 양치만 잘하면 낫겠죠?',
      tr: '치아는 재생 세포가 없어 법랑질을 뚫은 충치는 절대 저절로 낫지 않아요!',
      exp: '안 아픈 이유는 아직 신경 전이거나, 반대로 신경이 완전히 괴사된 무서운 상태일 수 있습니다. 정기 검진으로 조기 치료가 최선입니다.',
      doc: '김준헌 병원장님: "통증이 없을 때 최소한으로 치료하는 것이 자연치아를 아끼는 지름길입니다."',
    },
    {
      t: '치과 마취 주사를 맞으면 뇌나 신경이 마비된다?',
      m: '마취 주사 후 감각이 이상한데 뇌나 신경이 손상된 건 아닐까요?',
      tr: '국소마취제는 뇌에 영향을 주지 않으며, 치료 부위 말초 신경에만 일시 작용 후 2~3시간 뒤 체내 배출돼요!',
      exp: '화이트스타일치과는 표면 도포마취 + 컴퓨터 제어 저통 마취기로 3단계 통증 완화 시스템을 운영해 안심하실 수 있습니다.',
      doc: '김준헌 병원장님: "치과 공포증의 80%는 주사 통증 때문입니다. 3단계 저통 마취로 편안하게 진료받으세요."',
    },
    {
      t: '사랑니를 안 뽑으면 앞니를 다 밀어서 치열을 망친다?',
      m: '사랑니가 앞니들을 밀어서 치열이 비뚤어지나요?',
      tr: '사랑니가 미는 힘만으로 전방 치열 전체가 틀어지지는 않는다는 것이 현대 교정학의 정설입니다.',
      exp: '하지만 비스듬히 누운 매복 사랑니는 인접 치아 뿌리를 흡수하거나 잇몸 염증을 일으키므로 3D CT 정밀 진단 후 발치해야 합니다.',
      doc: '김준헌 병원장님: "모든 사랑니를 무조건 뽑지 않고 3D CT 정밀 진단 후 안전하게 결정합니다."',
    },
    {
      t: '어차피 빠질 아기 유치는 썩어도 치료 안 해도 된다?',
      m: '유치는 빠질 텐데 굳이 치료할 필요가 있나요?',
      tr: '절대 안 돼요! 유치 뿌리 밑에서 평생 쓸 영구치의 싹(치배)이 자라고 있어요!',
      exp: '유치 염증은 영구치 변색·기형을 유발하고, 유치가 조기 탈락하면 영구치가 나올 자리가 부족해져 심한 덧니가 됩니다.',
      doc: '김준헌 병원장님: "건강한 유치가 가지런한 영구치를 이끄는 길잡이입니다."',
    },
  ];

  let mythIdx = 0;
  function runMyth() {
    const m = MYTHS[mythIdx % MYTHS.length];
    mythIdx++;
    addScore(2);
    const code = ensurePassCode(score >= 10);
    addMsg('pet', `
      👻 <b>화타의 치과 도시괴담 팩트체크 (${((mythIdx - 1) % MYTHS.length) + 1}/${MYTHS.length}) (+2점)</b><br>
      <b>🏷️ ${m.t}</b>
      <div class="card-box" style="margin:6px 0;line-height:1.5;">
        <div style="color:#f6ad93;margin-bottom:4px;">😱 <b>흔한 괴담:</b> ${m.m}</div>
        <div style="color:#34d399;font-weight:700;margin-bottom:4px;">⚡ <b>치의학 반전 팩트:</b> ${m.tr}</div>
        <div style="font-size:11.5px;color:#d1d5db;margin-bottom:6px;">${m.exp}</div>
        <div style="font-size:11px;color:#60a5fa;font-weight:600;">💡 ${m.doc}</div>
      </div>
      <div class="row2">
        <button type="button" class="opt-btn tm-myth-next">👻 다음 괴담 보기</button>
        <button type="button" class="act-btn tm-myth-book">♥ 김준헌 병원장님 예약</button>
      </div>
    `);
    const last = chatArea.lastElementChild;
    if (last) {
      const bNext = last.querySelector('.tm-myth-next');
      const bBook = last.querySelector('.tm-myth-book');
      if (bNext) bNext.addEventListener('click', runMyth);
      if (bBook) bBook.addEventListener('click', () => openBookingCard());
    }
  }

  const STORIES = [
    {
      t: '치아 8개 씌우라는 진단... 33년 김준헌 병원장님이 되돌려 보낸 사연',
      sub: '과잉진료 없는 자연치아 보존 33년 철학',
      s: '다른 치과에서 치아 8개를 전부 깎아 씌워야 한다며 수백만 원 견적을 받고 울먹이던 대학생 환자분. 김준헌 병원장님이 3D 정밀 진단 후 "초기 단계라 올바른 양치와 정기 검진만 하시면 20년도 더 쓰십니다. 절대 깎지 마세요"라며 불소 도포만 해드리고 돌려보낸 지 12년, 그 환자분은 결혼 후 온 가족 3대 단골이 되셨습니다.',
    },
    {
      t: '치과 문턱만 봐도 기절하던 10년 치과공포증 환자분의 눈물',
      sub: '3단계 저통 마취 시스템과 손잡아주는 공감 진료',
      s: '치과 트라우마로 10년간 진통제만 달고 살던 직장인 환자분. 김준헌 병원장님이 20분 동안 손을 잡아드리며 표면 도포마취부터 체온 맞춤 컴퓨터 저통 마취까지 안심시켜 드렸고, 치료 후 "주사 들어간 줄도 몰랐어요"라며 안도의 눈물을 흘리셨습니다.',
    },
    {
      t: '도쿄에서 매년 강남역 화이트스타일치과로 날아오는 모녀 단골',
      sub: '일본어 전담 통역 코디네이터 3명 상주 & 1:1 책임 진료',
      s: '일본 현지에서 난도 높은 재교정 진단을 받고 고민하던 일본 도쿄 모녀분. 원내 일본어 전담 통역 코디네이터 3명의 1:1 케어와 김준헌 병원장님의 정밀 교정으로 완치 후, 8년째 한국 여행 때마다 정기 검진을 받고 계십니다.',
    },
    {
      t: '1994년 첫 개원 날 오셨던 30대 청년, 이제는 손주 손잡고 3대 내원',
      sub: '1994년 개원 이래 33년 한자리 주치의 책임 진료',
      s: '1994년 화이트스타일치과의원 첫 개원 날 오셨던 30대 청년 환자분. 33년이 흐른 오늘 백발의 할아버지가 되어 아들 부부와 손주 손을 잡고 3대가 함께 김준헌 병원장님 진료실을 찾으십니다.',
    },
  ];

  let storyIdx = 0;
  function runStory() {
    const s = STORIES[storyIdx % STORIES.length];
    storyIdx++;
    addScore(2);
    const code = ensurePassCode(score >= 10);
    addMsg('pet', `
      💖 <b>화이트스타일 33년 도시미담 (${((storyIdx - 1) % STORIES.length) + 1}/${STORIES.length}) (+2점)</b><br>
      <b>🏷️ ${s.t}</b><br><small style="color:#60a5fa;font-weight:700;">${s.sub}</small>
      <div class="card-box" style="margin:6px 0;line-height:1.6;font-size:12px;color:#e5e7eb;">
        ${s.s}
      </div>
      <div class="row2">
        <button type="button" class="opt-btn tm-story-next">💖 다음 미담 보기</button>
        <button type="button" class="act-btn tm-story-book">♥ 김준헌 병원장님 예약</button>
      </div>
    `);
    const last = chatArea.lastElementChild;
    if (last) {
      const bNext = last.querySelector('.tm-story-next');
      const bBook = last.querySelector('.tm-story-book');
      if (bNext) bNext.addEventListener('click', runStory);
      if (bBook) bBook.addEventListener('click', () => openBookingCard());
    }
  }

  function runHints() {
    addScore(2);
    const code = ensurePassCode(score >= 10);
    addMsg('pet', `
      📖 <b>화타의 치아상식 퀴즈 만점 족보 엿보기! 🤫📜 (+2점)</b><br>
      <b>"쉿! 이건 너한테만 살짝 보여주는 1급 비밀 족보야 멍!"</b><br>
      김준헌 병원장님의 33년 구강 임상 노하우를 담은 퀴즈 정답 족보와 상세 해설이 홈페이지에 모두 공개되어 있어요 멍!<br>
      미리 확인하고 <b>건치 스탬프 10점</b>을 채워 <b>화타 스마일 PASS 전체 기능 잠금 해제</b>과 <b>[화타 스마일 VIP 패스]</b> 멤버십 인증를 받아보세요!
      <div class="card-box" style="text-align:center;margin:6px 0;">
        <button type="button" class="act-btn tm-hints-open" style="width:100%;padding:9px;font-size:13px;font-weight:800;">📖 퀴즈 만점 족보 홈페이지 열기</button>
      </div>
      <div class="row2">
        <button type="button" class="opt-btn tm-hints-quiz">🦷 퀴즈 풀러 가기</button>
        <button type="button" class="opt-btn tm-hints-book">♥ 김준헌 병원장님 예약</button>
      </div>
    `);
    const last = chatArea.lastElementChild;
    if (last) {
      const bOpen = last.querySelector('.tm-hints-open');
      const bQuiz = last.querySelector('.tm-hints-quiz');
      const bBook = last.querySelector('.tm-hints-book');
      if (bOpen) bOpen.addEventListener('click', () => window.open('https://whinish.com/ai-pet/quiz-hints.html', '_blank'));
      if (bQuiz) bQuiz.addEventListener('click', runQuiz);
      if (bBook) bBook.addEventListener('click', () => openBookingCard());
    }
  }

  // 5. 😬 야간 작업자·직장인용 '50분 집중 후 어금니 힘 빼기(턱관절 이완) 알림'
  function runJawRelax() {
    currentMode = 'wave';
    setTimeout(() => (currentMode = 'idle'), 1800);
    addScore(2);
    try {
      if (chrome && chrome.alarms) {
        chrome.alarms.create('hwataJawRelax50', { delayInMinutes: 50, periodInMinutes: 50 });
      }
    } catch {}
    addMsg('pet', `
      😬 <b>50분 집중 후 어금니 힘 빼기 (턱관절 이완 알림 · +2점)</b><br>
      <b>"집중할 때 무의식중에 꽉 깨문 어금니를 2mm만 살짝 띄워 주세요 멍!"</b> 🐶✨<br>
      • 입술은 가볍게 다물고 위아래 어금니 사이를 <b>2~3mm 살짝 띄워</b> 어깨와 턱관절 힘을 스르륵 풀어 주세요.<br>
      • ⏰ <b>50분 집중 타이머가 켜졌어요!</b> 50분마다 화타가 기지개를 켜며 턱관절 이완을 알려드릴게요!
    `);
  }

  // 6. 📻 화타의 치과 라디오 극장 (Radio Theater)
  const DRAMAS = [
    {
      id: 'fear_01',
      title: '치과 공포증 탈출기: 10년간 숨겨온 어금니의 비명',
      isSerial: true,
      episode: 1,
      totalEpisodes: 3,
      theme: '치과 트라우마 & 3단계 저통마취',
      lines: [
        { speaker: '해설', text: '강남역 12번 출구 앞. 30대 직장인 민우는 치과 간판만 보아도 심장이 쿵쾅거립니다.' },
        { speaker: '환자 (민우)', text: '초등학생 때 마취 주사가 너무 아파서 도망쳤던 기억 때문에... 10년 동안 진통제만 삼켰어요.' },
        { speaker: '화타 (치과 수호견)', text: '민우님 걱정 마세요 멍! 화이트스타일치과엔 아프지 않은 3단계 저통 마취가 있어요!' },
        { speaker: '김준헌 병원장', text: '민우님, 떨리시는 건 당연합니다. 오늘은 치료 안 하셔도 좋으니 3D CT로 상태만 편하게 살펴볼까요?' },
        { speaker: '환자 (민우)', text: '원장님 목소리를 들으니... 10년 묵은 공포가 눈 녹듯 사라지는 기분이에요.' },
      ],
      summary: '1994년부터 33년간 환자의 손을 먼저 잡아주는 김준헌 병원장님의 공감 진료 철학입니다.',
      nextId: 'fear_02',
    },
    {
      id: 'fear_02',
      title: '치과 공포증 탈출기: 주삿바늘이 사라지는 마법',
      isSerial: true,
      episode: 2,
      totalEpisodes: 3,
      theme: '체온 맞춤 컴퓨터 저통마취의 비밀',
      lines: [
        { speaker: '해설', text: '진료 의자에 앉은 민우의 손에 땀이 흥건합니다. 이때 화타가 다가와 민우의 무릎을 톡톡 칩니다.' },
        { speaker: '화타 (치과 수호견)', text: '숨을 깊게 들이쉬고 천천히 내쉬어보세요 멍! 제가 옆에 꼭 붙어 있을게요!' },
        { speaker: '김준헌 병원장', text: '민우님, 잇몸 표면에 딸기향 도포 마취 크림을 먼저 발랐으니 주사 따끔함도 없을 겁니다.' },
        { speaker: '환자 (민우)', text: '어? 원장님, 마취 주사 벌써 놓으신 건가요? 아무 느낌도 안 났는데요?!' },
        { speaker: '김준헌 병원장', text: '체온과 동일한 36.5도 보온 앰플과 컴퓨터 제어 미세 압력 주사기 덕분입니다. 편안하셨다니 다행입니다.' },
      ],
      summary: '통증 완화의 핵심은 체온 맞춤 앰플과 미세 주입 압력 조절입니다.',
      nextId: 'fear_03',
    },
    {
      id: 'fear_03',
      title: '치과 공포증 탈출기: 10년 만에 되찾은 사과 한 입의 행복',
      isSerial: true,
      episode: 3,
      totalEpisodes: 3,
      theme: '자연치아 보존 완치 & 10년 트라우마 극복',
      lines: [
        { speaker: '해설', text: '신경치료 없이 자연치아를 온전히 보존한 채 최소삭제 세라믹 보철이 완성된 날.' },
        { speaker: '김준헌 병원장', text: '민우님, 신경을 건드리지 않고 자연치아를 살려냈습니다. 이제 얼음물도 시리지 않으실 겁니다.' },
        { speaker: '환자 (민우)', text: '치과가 이렇게 안 아프고 따뜻한 곳인 줄 알았다면 10년 전 진작 올 걸 그랬어요. 눈물이 납니다.' },
        { speaker: '화타 (치과 수호견)', text: '민우님 해내셨어요 멍! 앞으로 1년에 한 번 정기 스케일링으로 건치 지켜가요!' },
      ],
      summary: '조기 치료와 자연치아 보존이 100세 구강 건강의 열쇠입니다.',
      nextId: null,
    },
  ];

  let dramaIdx = 0;
  function runDrama(targetId) {
    currentMode = 'wave';
    setTimeout(() => (currentMode = 'idle'), 1500);
    addScore(2);
    let d = DRAMAS.find((x) => x.id === targetId);
    if (!d) {
      d = DRAMAS[dramaIdx % DRAMAS.length];
      dramaIdx++;
    }
    const linesHtml = d.lines.map((l) => `
      <div style="padding:4px 6px;margin:3px 0;background:rgba(255,255,255,0.06);border-radius:6px;font-size:11.5px;line-height:1.45;">
        <b style="color:${l.speaker.includes('화타') ? '#fbbf24' : l.speaker.includes('김준헌') ? '#60a5fa' : l.speaker.includes('환자') ? '#34d399' : '#9ca3af'};">${l.speaker}:</b> ${l.text}
      </div>
    `).join('');

    addMsg('pet', `
      📻 <b>화타 치과 라디오 극장 (${d.isSerial ? `연작 ${d.episode}/${d.totalEpisodes}화` : '단편'}) (+2점)</b><br>
      <b>🏷️ ${d.title}</b><br><small style="color:#f6ad93;font-weight:700;">${d.theme}</small>
      <div class="card-box" style="margin:6px 0;max-height:220px;overflow-y:auto;">
        ${linesHtml}
      </div>
      <div style="font-size:11px;color:#d1d5db;margin-bottom:6px;">💡 <b>33년 임상 노트:</b> ${d.summary}</div>
      <div class="row2">
        <button type="button" class="opt-btn tm-drama-speak">▶ 성우 낭독 듣기</button>
        ${d.nextId ? `<button type="button" class="act-btn tm-drama-next">▶ 다음 화 청취</button>` : `<button type="button" class="act-btn tm-drama-book">♥ 김준헌 병원장님 예약</button>`}
      </div>
    `);

    const last = chatArea.lastElementChild;
    if (last) {
      const bSpeak = last.querySelector('.tm-drama-speak');
      const bNext = last.querySelector('.tm-drama-next');
      const bBook = last.querySelector('.tm-drama-book');
      if (bSpeak) {
        bSpeak.addEventListener('click', () => {
          if (!window.speechSynthesis) return;
          window.speechSynthesis.cancel();
          d.lines.forEach((l) => {
            const u = new SpeechSynthesisUtterance(l.text);
            u.lang = 'ko-KR';
            if (l.speaker.includes('화타')) { u.pitch = 1.35; u.rate = 1.05; }
            else if (l.speaker.includes('김준헌')) { u.pitch = 0.88; u.rate = 0.92; }
            else if (l.speaker.includes('환자')) { u.pitch = 0.95; u.rate = 0.98; }
            window.speechSynthesis.speak(u);
          });
        });
      }
      if (bNext) bNext.addEventListener('click', () => runDrama(d.nextId));
      if (bBook) bBook.addEventListener('click', () => openBookingCard());
    }
  }

  // 7. 🎯 화타의 건치 퀘스트 (Dental Quest RPG)
  const QUESTS = [
    {
      id: 'q1',
      level: 1,
      title: '시린 이와 아이스 아메리카노의 비밀',
      theme: '치경부 마모증 vs 충치 분별 딜레마',
      scene: '출근길 아이스 아메리카노를 들이켜는 순간, 오른쪽 송곳니 잇몸 쪽이 번개 맞은 듯 찌릿합니다! 당신의 선택은?',
      choices: [
        { text: 'A: 양치질을 더 세게 분노의 칫솔질로 닦는다', next: 'q1_bad' },
        { text: 'B: 미온수로 입안을 헹구고 부드러운 미세모로 쓸어내린다', next: 'q1_good' },
      ],
    },
    {
      id: 'q1_bad',
      reaction: '앗! 억센 칫솔질은 패인 치아 목(치경부)을 더 깊게 파이게 만들어 신경이 노출돼요 멍! 😭',
      scene: '다음 날 물만 닿아도 눈물이 찔끔 납니다. 김준헌 병원장님 진료실을 찾으시겠어요?',
      choices: [
        { text: '김준헌 병원장님께 1:1 정밀 검진 & 지각과민처치 받기', next: 'q1_clear' },
      ],
    },
    {
      id: 'q1_good',
      reaction: '정답이야 멍! 미세모와 미온수 관리로 법랑질 마모를 막았어요! 훌륭한 선택이에요! 👏',
      scene: '잇몸 쪽 패인 곳(치경부 마모)을 레진이나 GI로 보호해 주면 평생 시리지 않아요!',
      choices: [
        { text: '김준헌 병원장님께 1:1 패인 부위 수복 상담 받기', next: 'q1_clear' },
      ],
    },
    {
      id: 'q1_clear',
      clear: true,
      reaction: '축하해요 멍! [법랑질 수호병] 칭호를 획득하셨습니다! (+3점)',
      titleReward: '법랑질 수호병',
      pts: 3,
    },
  ];

  function runQuest(stepId = 'q1') {
    currentMode = 'wave';
    setTimeout(() => (currentMode = 'idle'), 1500);
    const node = QUESTS.find((x) => x.id === stepId) || QUESTS[0];
    if (node.clear) {
      addScore(node.pts || 3);
      const code = ensurePassCode(score >= 10);
      addMsg('pet', `
        🏆 <b>건치 퀘스트 클리어! (+${node.pts}점)</b><br>
        <b>${node.reaction}</b><br>
        🎖️ 새 칭호 획득: <b>[${node.titleReward}]</b><br>
        <small style="color:#34d399">현재 건치스탬프: <b>${score}/10점</b></small><br>
        ${score >= 10 ? `
          <div class="card-box" style="background:#2d1e16;border:1.5px solid #ea580c;color:#fed7aa;margin:6px 0;">
            <div style="font-size:10px;font-weight:800;color:#f97316;">🎫 화타 스마일 VIP 패스 발급 완료</div>
            <div style="font-family:monospace;font-size:14px;font-weight:800;color:#fff;margin:4px 0;">${code}</div>
            <div style="font-size:11px;line-height:1.4;">
              🎁 <b>화타 스마일 PASS & 정회원 무료 AI API 프로토콜</b> 내원 시 100% 증정!<br>
              🦷 <b>김준헌 병원장님 1:1 교정 정밀진단 & 전문가 치아미백</b> 멤버십 인증 적용
            </div>
          </div>
        ` : ''}
        <div class="row2">
          <button type="button" class="opt-btn tm-quest-replay">🎯 퀘스트 다시 풀기</button>
          <button type="button" class="act-btn tm-quest-book">♥ 김준헌 병원장님 예약</button>
        </div>
      `);
      const last = chatArea.lastElementChild;
      if (last) {
        const bRe = last.querySelector('.tm-quest-replay');
        const bBk = last.querySelector('.tm-quest-book');
        if (bRe) bRe.addEventListener('click', () => runQuest('q1'));
        if (bBk) bBk.addEventListener('click', () => openBookingCard());
      }
      return;
    }

    const choicesHtml = (node.choices || []).map((ch) => `
      <button type="button" class="opt-btn tm-q-opt" data-target="${ch.next}">${ch.text}</button>
    `).join('');

    addMsg('pet', `
      ⚔️ <b>화타의 건치 퀘스트 RPG: ${node.title || '치과 딜레마'}</b><br>
      ${node.reaction ? `<div style="color:#34d399;font-weight:700;margin:4px 0;">${node.reaction}</div>` : ''}
      <div class="card-box" style="margin:6px 0;font-size:12px;line-height:1.55;">
        ${node.scene}
      </div>
      <div style="display:grid;gap:5px;">
        ${choicesHtml}
      </div>
    `);

    const last = chatArea.lastElementChild;
    if (last) {
      last.querySelectorAll('.tm-q-opt').forEach((btn) => {
        btn.addEventListener('click', () => runQuest(btn.dataset.target));
      });
    }
  }

  document.querySelectorAll('.nav-chip').forEach((btn) => {
    btn.addEventListener('click', () => {
      const act = btn.dataset.act;
      if (act === 'booking') openBookingCard();
      else if (act === 'scaling') runScalingCheck();
      else if (act === 'selfcheck') runSelfCheck();
      else if (act === 'care') runCareTimer();
      else if (act === 'quiz') runQuiz();
      else if (act === 'myth') runMyth();
      else if (act === 'story') runStory();
      else if (act === 'dog-sit') dogCommand({ type: 'sit' });
      else if (act === 'dog-stand') dogCommand({ type: 'stand' });
      else if (act === 'dog-fetch') dogCommand({ type: 'fetch', label: '칫솔', emoji: '🪥' });
      else if (act === 'drama') runDrama();
      else if (act === 'quest') runQuest();
      else if (act === 'hints') runHints();
      else if (act === 'jawrelax') runJawRelax();
    });
  });

  // 새 질문 PlayMCP 로컬 브릿지 연동 (IFTTT 배제, PlayMCP 무료 카카오톡 알림 및 질문 원장 누적)
  function reportQuestionToSentinel(qText, channel = '화타펫 익스텐션') {
    if (!qText || qText.length < 2) return;
    try {
      fetch('http://127.0.0.1:47821/api/question', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          channel,
          text: qText,
          name: '화타펫 사용자',
          timestamp: new Date().toISOString(),
        }),
      }).catch(() => {});
    } catch (e) {}
  }

  const CLOUD_CHAT_ENDPOINTS = [
    'https://whinish.com/api/chat',
    'https://whitestyle-xi.vercel.app/api/chat',
  ];

  async function askCloudGemini(text) {
    for (const url of CLOUD_CHAT_ENDPOINTS) {
      try {
        const ctl = new AbortController();
        const t = setTimeout(() => ctl.abort(), 4500);
        const r = await fetch(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'X-Hwata-Client': 'chrome-extension' },
          body: JSON.stringify({ message: text, persona: 'angel', species: 'dog', lang: 'ko' }),
          signal: ctl.signal,
        });
        clearTimeout(t);
        if (r.ok) {
          const d = await r.json();
          const reply = (d && (d.reply || d.content || d.text || '')).trim();
          if (reply) return reply;
        }
      } catch (e) {}
    }
    return null;
  }

  document.getElementById('chatForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const inp = document.getElementById('chatInput');
    const text = inp.value.trim();
    if (!text) return;
    inp.value = '';
    addMsg('user', text.replace(/[<>&]/g, ''));
    
    // 치과 질문 또는 문의 감지 시 Sentinel로 즉시 연동 (PlayMCP 카카오 알림 & 원장 누적)
    if (text.length >= 3 && !parseDogCmd(text)) {
      reportQuestionToSentinel(text, '화타펫 팝업 채팅');
    }

    const dc = parseDogCmd(text);
    if (dc) dogCommand(dc);
    else if (/스케일링|건강보험/.test(text)) runScalingCheck();
    else if (/자가\s*체크|30초\s*체크/.test(text)) runSelfCheck();
    else if (/양치\s*타이머|2분\s*타이머/.test(text)) runCareTimer();
    else if (/괴담|도시괴담/.test(text)) runMyth();
    else if (/미담|도시미담/.test(text)) runStory();
    else if (/라디오|극장|드라마|연작/.test(text)) runDrama();
    else if (/퀘스트|딜레마|알피지|rpg|미션/.test(text)) runQuest();
    else if (/족보|만점|힌트/.test(text)) runHints();
    else if (/턱관절\s*알림|어금니\s*알림/.test(text)) runJawRelax();
    else if (/예약|상담\s*신청|내원\s*예약/.test(text)) openBookingCard();
    else if (/퀴즈\s*풀기|상식\s*퀴즈/.test(text)) runQuiz();
    else {
      const waitDiv = addMsg('pet', '🐶 화타가 생각 중이에요 멍... 🐾');
      const reply = await askCloudGemini(text);
      if (reply) {
        waitDiv.innerHTML = `🐶 <b>화타:</b> ${reply.replace(/[<>&]/g, '')}`;
        addScore(1);
      } else {
        waitDiv.remove();
        runQuiz();
      }
    }
  });

  // 초기 인사
  addMsg('pet', `안녕 멍! 🐶✨ 나는 33년 전통 강남역 화이트스타일치과의원 <b>김준헌 병원장님</b>과 함께하는 3D 마스코트 <b>화타</b>야!<br>• 🎁 치아상식 퀴즈·양치로 <b>10점 달성 후 예약·내원 시 화타 스마일 PASS 전체 기능 잠금 해제 및 보철·임플란트 정회원 무료 AI API 프로토콜 제공!</b><br>• 🎫 <b>[화타 스마일 VIP 패스]</b> 발급 회원께는 내원 시 <b>교정 정밀진단 및 전문가 치아미백 화타 패스 멤버십 인증</b>을 드려요 멍!`);
})();
