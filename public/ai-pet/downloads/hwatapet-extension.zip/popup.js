(() => {
  'use strict';

  const API_BASE = 'https://whitestyle.com/api/ai-pet';

  function escapeHtml(str) {
    return String(str == null ? '' : str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function assetUrl(file) {
    try {
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getURL) {
        return chrome.runtime.getURL('assets3d/' + file);
      }
    } catch {}
    return 'assets3d/' + file;
  }

  const SPECIES_LIST = [
    { key: 'dog', label: '하야니' },
    { key: 'cat', label: '치즈냥' },
    { key: 'elephant', label: '코코' },
    { key: 'dino', label: '디노' },
    { key: 'parrot', label: '코코아' },
    { key: 'python', label: '파이' },
  ];

  const EAR_LIST = [
    { key: 'perk', label: '쫑긋 귀' },
    { key: 'fold', label: '접힌 귀' },
    { key: 'round', label: '둥근 귀' },
    { key: 'pointy', label: '뾰족 귀' },
    { key: 'small', label: '아기 귀' },
    { key: 'fox', label: '여우 귀' },
    { key: 'lynx', label: '스라소니' },
    { key: 'mismatch', label: '짝짝이' },
    { key: 'outtilt', label: '옆뻗 귀' },
    { key: 'intilt', label: '안기울 귀' },
    { key: 'darktip', label: '초코끝' },
    { key: 'whitetip', label: '하얀끝' },
    { key: 'tnr', label: '컷팅 귀' },
  ];

  const COSTUME_LIST = [
    { key: 'none', label: '내 귀 유지' },
    { key: 'doctor', label: '의사 가운' },
    { key: 'crown', label: 'VIP 왕관' },
    { key: 'angel', label: '수호천사' },
    { key: 'beret', label: '베레모' },
    { key: 'coder', label: '개발자' },
    { key: 'hygiene', label: '위생사' },
  ];

  const BG_LIST = [
    { key: 'cream', label: '크림', hex: '#faf3e3' },
    { key: 'mint', label: '민트', hex: '#dff3ee' },
    { key: 'peach', label: '피치', hex: '#fce5dc' },
    { key: 'sky', label: '스카이', hex: '#e1f0fa' },
    { key: 'lavender', label: '라벤더', hex: '#ece6fa' },
    { key: 'gold', label: '골드', hex: '#f9e498' },
  ];

  function sanitizeAvatar(raw) {
    const obj = raw && typeof raw === 'object' ? raw : {};
    return {
      species: SPECIES_LIST.some((s) => s.key === obj.species) ? obj.species : 'dog',
      ear: EAR_LIST.some((e) => e.key === obj.ear) ? obj.ear : 'perk',
      costume: COSTUME_LIST.some((c) => c.key === obj.costume) ? obj.costume : 'none',
      bg: BG_LIST.some((b) => b.key === obj.bg) ? obj.bg : 'cream',
    };
  }

  function buildAvatarInnerHtml(cfg) {
    const a = sanitizeAvatar(cfg);
    if (a.species === 'dog' && a.costume === 'none') {
      return (
        `<img src="${assetUrl('hwata_3d_idle.png')}" class="hw-av-layer" alt="">` +
        `<img src="${assetUrl('hwata_3d_ear_' + a.ear + '.png')}" class="hw-av-layer" alt="">`
      );
    }
    if (a.species === 'dog' && a.costume !== 'none') {
      return `<img src="${assetUrl('hwata_3d_costume_' + a.costume + '.png')}" class="hw-av-layer" alt="">`;
    }
    return `<img src="${assetUrl('hwata_3d_species_' + a.species + '.png')}" class="hw-av-layer" alt="">`;
  }

  function createAvatarEl(cfg, sizeClass = '', isBot = false) {
    const a = sanitizeAvatar(cfg);
    const div = document.createElement('div');
    div.className = `hw-ext-avatar ${sizeClass} hw-bg-${a.bg}${isBot ? ' bot' : ''}`.trim().replace(/\s+/g, ' ');
    div.innerHTML = buildAvatarInnerHtml(a);
    return div;
  }

  function storageSet(obj) {
    try {
      Object.entries(obj).forEach(([k, v]) => {
        localStorage.setItem(k, typeof v === 'string' ? v : JSON.stringify(v));
      });
    } catch {}
    try {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.set(obj);
      }
    } catch {}
  }

  function storageLoad(keys) {
    return new Promise((resolve) => {
      const out = {};
      try {
        keys.forEach((k) => {
          const v = localStorage.getItem(k);
          if (v !== null) out[k] = v;
        });
      } catch {}
      try {
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
          chrome.storage.local.get(keys, (res) => {
            resolve({ ...out, ...(res || {}) });
          });
          return;
        }
      } catch {}
      resolve(out);
    });
  }

  async function initPopup() {
    const stored = await storageLoad([
      'hwata_user_nickname',
      'hwata_avatar_v1',
      'hwata_chart_no',
      'hwata_cracked',
      'hwata_current_room',
      'hwata_joined_rooms',
      'hwata_guest_id',
      'hwata_auth_token',
      'hwata_auth_user',
      'hwata_floating_enabled',
    ]);

    let floatingEnabled =
      stored.hwata_floating_enabled === true || stored.hwata_floating_enabled === 'true';

    let authToken = typeof stored.hwata_auth_token === 'string' ? stored.hwata_auth_token : '';
    let authUser = stored.hwata_auth_user || null;
    if (typeof authUser === 'string') {
      try { authUser = JSON.parse(authUser); } catch { authUser = null; }
    }
    let pollTimer = null;

    let nickname = stored.hwata_user_nickname || '화타_' + Math.floor(Math.random() * 900 + 100);
    if (authUser?.name && nickname.startsWith('화타_')) {
      nickname = String(authUser.name).slice(0, 20);
    }
    let myAvatar = { species: 'dog', ear: 'perk', costume: 'none', bg: 'cream' };
    try {
      const rawAv = stored.hwata_avatar_v1;
      if (rawAv) {
        myAvatar = sanitizeAvatar(typeof rawAv === 'string' ? JSON.parse(rawAv) : rawAv);
      }
    } catch {}

    let myChartNo = stored.hwata_chart_no || '';
    let isCracked = stored.hwata_cracked === true || stored.hwata_cracked === 'true';
    let currentRoomId = stored.hwata_current_room || 'room_jaw_stretch';
    let joinedRooms = [];
    try {
      const rawJr = stored.hwata_joined_rooms;
      if (rawJr) joinedRooms = typeof rawJr === 'string' ? JSON.parse(rawJr) : Array.isArray(rawJr) ? rawJr : [];
    } catch {}
    let guestId = stored.hwata_guest_id || 'ext_' + Date.now().toString(36);

    storageSet({
      hwata_user_nickname: nickname,
      hwata_avatar_v1: myAvatar,
      hwata_guest_id: guestId,
    });

    function getMyRefCode() {
      return myChartNo ? 'HWATA-' + myChartNo.toUpperCase() : 'HWATA-' + guestId.slice(-6).toUpperCase();
    }

    function rememberRoom(roomId) {
      if (!roomId) return;
      if (!joinedRooms.includes(roomId)) {
        joinedRooms.unshift(roomId);
        joinedRooms = joinedRooms.slice(0, 20);
        storageSet({ hwata_joined_rooms: joinedRooms });
      }
    }

    // DOM Elements
    const headerAvatarPreview = document.getElementById('headerAvatarPreview');
    const headerNicknameLabel = document.getElementById('headerNicknameLabel');
    const crackStatusBadge = document.getElementById('crackStatusBadge');
    const extChartCrackInput = document.getElementById('extChartCrackInput');
    const extChartCrackBtn = document.getElementById('extChartCrackBtn');
    const vipHint = document.getElementById('vipHint');

    const extRoomSelect = document.getElementById('extRoomSelect');
    const extNewRoomToggleBtn = document.getElementById('extNewRoomToggleBtn');
    const extNewRoomBox = document.getElementById('extNewRoomBox');
    const extNewRoomInput = document.getElementById('extNewRoomInput');
    const extNewRoomCreateBtn = document.getElementById('extNewRoomCreateBtn');
    const extInviteShareBtn = document.getElementById('extInviteShareBtn');
    const extChatMessages = document.getElementById('extChatMessages');
    const extChatMessageInput = document.getElementById('extChatMessageInput');
    const extSendChatBtn = document.getElementById('extSendChatBtn');
    const extRefSummaryText = document.getElementById('extRefSummaryText');
    const extCopyRefBtn = document.getElementById('extCopyRefBtn');

    const extNicknameInput = document.getElementById('extNicknameInput');
    const extSpeciesGrid = document.getElementById('extSpeciesGrid');
    const extEarSection = document.getElementById('extEarSection');
    const extEarGrid = document.getElementById('extEarGrid');
    const extCostumeSection = document.getElementById('extCostumeSection');
    const extCostumeGrid = document.getElementById('extCostumeGrid');
    const extBgRow = document.getElementById('extBgRow');

    const extBenefitRefCount = document.getElementById('extBenefitRefCount');
    const extVoucherArea = document.getElementById('extVoucherArea');
    const extLoginGate = document.getElementById('extLoginGate');
    const extRoomWorkspace = document.getElementById('extRoomWorkspace');
    const extFloatingToggle = document.getElementById('extFloatingToggle');
    const extFloatingStatusText = document.getElementById('extFloatingStatusText');

    function renderFloatingToggle() {
      if (extFloatingToggle) extFloatingToggle.checked = floatingEnabled;
      if (extFloatingStatusText) {
        extFloatingStatusText.textContent = floatingEnabled
          ? '켜짐 · 다른 웹사이트 우측 하단에 표시'
          : '꺼짐 · 툴바 클릭 시에만 열림';
      }
    }

    renderFloatingToggle();
    if (extFloatingToggle) {
      extFloatingToggle.addEventListener('change', () => {
        floatingEnabled = Boolean(extFloatingToggle.checked);
        storageSet({ hwata_floating_enabled: floatingEnabled });
        renderFloatingToggle();
      });
    }

    let lastMsgSig = '';

    function showExtLoginGate() {
      authToken = '';
      if (pollTimer) {
        clearInterval(pollTimer);
        pollTimer = null;
      }
      if (extLoginGate) extLoginGate.hidden = false;
      if (extRoomWorkspace) extRoomWorkspace.hidden = true;
      if (extChartCrackBtn) extChartCrackBtn.disabled = true;
      try {
        chrome.storage?.local?.remove(['hwata_auth_token', 'hwata_auth_user']);
      } catch {}
    }

    function showExtWorkspace() {
      if (extLoginGate) extLoginGate.hidden = true;
      if (extRoomWorkspace) extRoomWorkspace.hidden = false;
      if (extChartCrackBtn) extChartCrackBtn.disabled = false;
    }

    async function authFetch(url, options = {}) {
      const headers = Object.assign({ 'Content-Type': 'application/json' }, options.headers || {});
      if (authToken) {
        headers['Authorization'] = `Bearer ${authToken}`;
      }
      const res = await fetch(url, Object.assign({}, options, { headers }));
      if (res.status === 401) {
        showExtLoginGate();
      }
      return res;
    }

    // 탭 전환
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabPanes = document.querySelectorAll('.tab-pane');
    tabBtns.forEach((btn) => {
      btn.addEventListener('click', () => {
        const target = btn.getAttribute('data-tab');
        tabBtns.forEach((b) => b.classList.remove('active'));
        tabPanes.forEach((p) => p.classList.remove('active'));
        btn.classList.add('active');
        const pane = document.getElementById(target);
        if (pane) pane.classList.add('active');
      });
    });

    function renderHeaderAvatar() {
      if (headerAvatarPreview) {
        headerAvatarPreview.className = `hw-ext-avatar lg hw-bg-${myAvatar.bg}`;
        headerAvatarPreview.innerHTML = buildAvatarInnerHtml(myAvatar);
      }
      if (headerNicknameLabel) {
        headerNicknameLabel.textContent = nickname;
      }
      if (extEarSection) extEarSection.hidden = myAvatar.species !== 'dog';
      if (extCostumeSection) extCostumeSection.hidden = myAvatar.species !== 'dog';
    }

    function renderAvatarPickers() {
      if (extSpeciesGrid) {
        extSpeciesGrid.innerHTML = '';
        SPECIES_LIST.forEach((sp) => {
          const btn = document.createElement('button');
          btn.type = 'button';
          btn.className = 'picker-btn' + (myAvatar.species === sp.key ? ' active' : '');
          btn.appendChild(createAvatarEl({ species: sp.key, ear: myAvatar.ear, costume: 'none', bg: myAvatar.bg }, 'sm'));
          const lbl = document.createElement('span');
          lbl.textContent = sp.label;
          btn.appendChild(lbl);
          btn.addEventListener('click', () => {
            myAvatar.species = sp.key;
            storageSet({ hwata_avatar_v1: myAvatar });
            renderHeaderAvatar();
            renderAvatarPickers();
          });
          extSpeciesGrid.appendChild(btn);
        });
      }

      if (extEarGrid) {
        extEarGrid.innerHTML = '';
        EAR_LIST.forEach((er) => {
          const btn = document.createElement('button');
          btn.type = 'button';
          btn.className = 'picker-btn' + (myAvatar.costume === 'none' && myAvatar.ear === er.key ? ' active' : '');
          btn.appendChild(createAvatarEl({ species: 'dog', ear: er.key, costume: 'none', bg: myAvatar.bg }, 'sm'));
          const lbl = document.createElement('span');
          lbl.textContent = er.label;
          btn.appendChild(lbl);
          btn.addEventListener('click', () => {
            myAvatar.species = 'dog';
            myAvatar.costume = 'none';
            myAvatar.ear = er.key;
            storageSet({ hwata_avatar_v1: myAvatar });
            renderHeaderAvatar();
            renderAvatarPickers();
          });
          extEarGrid.appendChild(btn);
        });
      }

      if (extCostumeGrid) {
        extCostumeGrid.innerHTML = '';
        COSTUME_LIST.forEach((cs) => {
          const btn = document.createElement('button');
          btn.type = 'button';
          btn.className = 'picker-btn' + (myAvatar.costume === cs.key ? ' active' : '');
          btn.appendChild(createAvatarEl({ species: 'dog', ear: myAvatar.ear, costume: cs.key, bg: myAvatar.bg }, 'sm'));
          const lbl = document.createElement('span');
          lbl.textContent = cs.label;
          btn.appendChild(lbl);
          btn.addEventListener('click', () => {
            myAvatar.species = 'dog';
            myAvatar.costume = cs.key;
            storageSet({ hwata_avatar_v1: myAvatar });
            renderHeaderAvatar();
            renderAvatarPickers();
          });
          extCostumeGrid.appendChild(btn);
        });
      }

      if (extBgRow) {
        extBgRow.innerHTML = '';
        BG_LIST.forEach((bg) => {
          const btn = document.createElement('button');
          btn.type = 'button';
          btn.className = 'bg-swatch-btn' + (myAvatar.bg === bg.key ? ' active' : '');
          btn.style.backgroundColor = bg.hex;
          btn.title = bg.label;
          btn.textContent = myAvatar.bg === bg.key ? '✓' : '';
          btn.addEventListener('click', () => {
            myAvatar.bg = bg.key;
            storageSet({ hwata_avatar_v1: myAvatar });
            renderHeaderAvatar();
            renderAvatarPickers();
          });
          extBgRow.appendChild(btn);
        });
      }
    }

    if (extNicknameInput) {
      extNicknameInput.value = nickname;
      extNicknameInput.addEventListener('input', () => {
        const v = extNicknameInput.value.trim().slice(0, 20);
        if (v) {
          nickname = v;
          storageSet({ hwata_user_nickname: v });
          renderHeaderAvatar();
        }
      });
    }

    renderHeaderAvatar();
    renderAvatarPickers();

    function applyCrackUI(chartNo) {
      myChartNo = chartNo;
      isCracked = true;
      if (crackStatusBadge) {
        crackStatusBadge.textContent = '👑 VIP 정회원';
        crackStatusBadge.classList.add('cracked');
      }
      if (extChartCrackInput) extChartCrackInput.value = chartNo;
      if (vipHint) vipHint.textContent = `[${chartNo}] 정회원 인증 완료! 프라이빗 단톡방 개설 및 @화타 상담 해금.`;
    }

    if (isCracked && myChartNo) {
      applyCrackUI(myChartNo);
    }

    if (extChartCrackBtn && extChartCrackInput) {
      extChartCrackBtn.addEventListener('click', async () => {
        if (!authToken) {
          showExtLoginGate();
          alert('whitestyle.com 로그인 후 이용할 수 있습니다.');
          return;
        }
        const val = extChartCrackInput.value.trim();
        if (!val || val.length < 3) {
          alert('차트번호 3자리 이상을 입력해 주세요.');
          return;
        }
        extChartCrackBtn.disabled = true;
        extChartCrackBtn.textContent = '확인중';
        try {
          const res = await authFetch(`${API_BASE}/verify-member`, {
            method: 'POST',
            body: JSON.stringify({ chartNo: val, mode: 'crack' }),
          });
          if (res.status === 401) {
            alert('whitestyle.com 로그인 후 이용할 수 있습니다.');
            return;
          }
          const data = await res.json();
          if (data.ok && data.cracked) {
            storageSet({ hwata_chart_no: data.chartNo, hwata_cracked: 'true' });
            applyCrackUI(data.chartNo);
            refreshReferralStatus();
            alert('🎉 원내 정회원 인증이 완료되었습니다! 프라이빗 단톡방과 스페셜 아바타가 해금되었습니다.');
          } else {
            alert(data.message || '차트번호 확인에 실패했습니다.');
          }
        } catch {
          alert('서버 연결 중 오류가 발생했습니다.');
        } finally {
          extChartCrackBtn.disabled = false;
          extChartCrackBtn.textContent = '정회원 인증';
        }
      });
    }

    async function loadRooms() {
      if (!authToken) return;
      try {
        const ids = Array.from(new Set([currentRoomId, ...joinedRooms])).filter(Boolean);
        const res = await authFetch(`${API_BASE}/room?action=list&roomIds=${encodeURIComponent(ids.join(','))}`);
        if (res.status === 401) return;
        const data = await res.json();
        if (data.ok && Array.isArray(data.rooms) && extRoomSelect) {
          extRoomSelect.innerHTML = '';
          data.rooms.forEach((r) => {
            const opt = document.createElement('option');
            opt.value = r.roomId;
            opt.textContent = (r.isPublic === false ? '🔒 ' : '') + r.roomName;
            if (r.roomId === currentRoomId) opt.selected = true;
            extRoomSelect.appendChild(opt);
          });
        }
      } catch {}
    }

    async function loadMessages(forceScroll = false) {
      if (!extChatMessages || !authToken) return;
      try {
        const res = await authFetch(`${API_BASE}/room?action=messages&roomId=${encodeURIComponent(currentRoomId)}`);
        if (res.status === 401) return;
        const data = await res.json();
        if (data.ok && Array.isArray(data.messages)) {
          const lastId = data.messages.length ? data.messages[data.messages.length - 1].id : 'empty';
          const sig = `${currentRoomId}:${data.messages.length}:${lastId}`;
          if (sig === lastMsgSig && !forceScroll) return;
          lastMsgSig = sig;

          extChatMessages.innerHTML = '';
          data.messages.forEach((m) => {
            const isBot = Boolean(m.isBot);
            const isMe = !isBot && m.sender === nickname;

            const row = document.createElement('div');
            row.className = `ext-msg-row ${isBot ? 'bot' : isMe ? 'me' : 'other'}`;

            row.appendChild(
              createAvatarEl(
                m.avatar || { species: 'dog', ear: 'perk', costume: isBot ? 'doctor' : 'none', bg: isBot ? 'gold' : 'cream' },
                '',
                isBot
              )
            );

            const col = document.createElement('div');
            col.className = 'ext-msg-col';

            const sender = document.createElement('div');
            sender.className = 'ext-msg-sender';
            sender.textContent = (m.sender || '익명') + (m.isCracked && !isBot ? ' 👑' : '');

            const bubble = document.createElement('div');
            bubble.className = 'ext-msg-bubble';
            bubble.innerHTML = escapeHtml(m.text).replace(/\n/g, '<br>');

            col.appendChild(sender);
            col.appendChild(bubble);
            row.appendChild(col);
            extChatMessages.appendChild(row);
          });
          extChatMessages.scrollTop = extChatMessages.scrollHeight;
        }
      } catch {}
    }

    async function sendMessage() {
      if (!extChatMessageInput || !authToken) {
        showExtLoginGate();
        return;
      }
      const text = extChatMessageInput.value.trim();
      if (!text) return;
      extChatMessageInput.value = '';
      if (extSendChatBtn) extSendChatBtn.disabled = true;

      try {
        const res = await authFetch(`${API_BASE}/room`, {
          method: 'POST',
          body: JSON.stringify({
            action: 'send',
            roomId: currentRoomId,
            sender: nickname,
            text,
            chartNo: myChartNo || null,
            isCracked,
            avatar: myAvatar,
          }),
        });
        if (res.status === 401) return;
        const data = await res.json();
        if (data.ok) {
          lastMsgSig = '';
          await loadMessages(true);
        }
      } catch {
      } finally {
        if (extSendChatBtn) extSendChatBtn.disabled = false;
        extChatMessageInput.focus();
      }
    }

    if (extSendChatBtn) extSendChatBtn.addEventListener('click', sendMessage);
    if (extChatMessageInput) {
      extChatMessageInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          sendMessage();
        }
      });
    }

    if (extRoomSelect) {
      extRoomSelect.addEventListener('change', () => {
        currentRoomId = extRoomSelect.value;
        storageSet({ hwata_current_room: currentRoomId });
        rememberRoom(currentRoomId);
        lastMsgSig = '';
        loadMessages(true);
      });
    }

    if (extNewRoomToggleBtn && extNewRoomBox) {
      extNewRoomToggleBtn.addEventListener('click', () => {
        extNewRoomBox.hidden = !extNewRoomBox.hidden;
        if (!extNewRoomBox.hidden && extNewRoomInput) extNewRoomInput.focus();
      });
    }

    if (extNewRoomCreateBtn && extNewRoomInput) {
      extNewRoomCreateBtn.addEventListener('click', async () => {
        const name = extNewRoomInput.value.trim();
        if (!name) return;
        extNewRoomCreateBtn.disabled = true;
        try {
          const res = await authFetch(`${API_BASE}/room`, {
            method: 'POST',
            body: JSON.stringify({
              action: 'create',
              roomName: name,
              chartNo: myChartNo || null,
              hostNickname: nickname,
              isPublic: false,
              refCode: getMyRefCode(),
            }),
          });
          if (res.status === 401) return;
          const data = await res.json();
          if (data.ok && data.room) {
            extNewRoomInput.value = '';
            if (extNewRoomBox) extNewRoomBox.hidden = true;
            currentRoomId = data.room.roomId;
            storageSet({ hwata_current_room: currentRoomId });
            rememberRoom(currentRoomId);
            await loadRooms();
            lastMsgSig = '';
            await loadMessages(true);
            const url = data.inviteLink || `https://whitestyle.com/ai-pet?room=${encodeURIComponent(currentRoomId)}&ref=${encodeURIComponent(getMyRefCode())}#community`;
            navigator.clipboard?.writeText(url).catch(() => {});
            alert(`🎉 [${data.room.roomName}] 개설 및 초대 링크가 복사되었습니다!`);
          }
        } catch {
        } finally {
          extNewRoomCreateBtn.disabled = false;
        }
      });
    }

    function copyInviteLink() {
      const url = `https://whitestyle.com/ai-pet?room=${encodeURIComponent(currentRoomId)}&ref=${encodeURIComponent(getMyRefCode())}#community`;
      navigator.clipboard
        ?.writeText(url)
        .then(() => {
          alert('🔗 단톡방 지인 초대 링크가 복사되었습니다! 지인 5명 초대 시 VIP 스페셜 아바타 패스가 해금됩니다.');
        })
        .catch(() => {
          prompt('초대 링크:', url);
        });
    }

    if (extInviteShareBtn) extInviteShareBtn.addEventListener('click', copyInviteLink);
    if (extCopyRefBtn) extCopyRefBtn.addEventListener('click', copyInviteLink);

    async function refreshReferralStatus() {
      if (!authToken) return;
      try {
        const res = await authFetch(`${API_BASE}/room?action=referral_status&refCode=${encodeURIComponent(getMyRefCode())}`);
        if (res.status === 401) return;
        const data = await res.json();
        if (data.ok) {
          const c = Number(data.invitedCount || 0);
          if (extRefSummaryText) {
            extRefSummaryText.textContent =
              c >= 5
                ? `🎉 VIP 아바타 패스 달성! (${data.voucherCode || '발급완료'})`
                : `🎁 지인 5명 초대 시 VIP 스페셜 아바타 패스 (${c}/5명)`;
          }
          if (extBenefitRefCount) extBenefitRefCount.textContent = `${c} / 5명`;
          if (extVoucherArea) {
            if (data.voucherCode) {
              extVoucherArea.hidden = false;
              extVoucherArea.textContent = `VIP 패스 코드: ${data.voucherCode}`;
            } else {
              extVoucherArea.hidden = true;
            }
          }
        }
      } catch {}
    }

    try {
      chrome.storage?.onChanged?.addListener((changes, area) => {
        if (area !== 'local') return;
        if (changes.hwata_floating_enabled !== undefined) {
          floatingEnabled =
            changes.hwata_floating_enabled.newValue === true ||
            changes.hwata_floating_enabled.newValue === 'true';
          renderFloatingToggle();
        }
        if (!changes.hwata_auth_token) return;
        authToken = typeof changes.hwata_auth_token.newValue === 'string' ? changes.hwata_auth_token.newValue : '';
        if (authToken) {
          showExtWorkspace();
          loadRooms();
          loadMessages(true);
          refreshReferralStatus();
          if (!pollTimer) pollTimer = setInterval(() => loadMessages(false), 3500);
        } else {
          showExtLoginGate();
        }
      });
    } catch {}

    if (authToken) {
      showExtWorkspace();
      await loadRooms();
      await loadMessages(true);
      await refreshReferralStatus();
      pollTimer = setInterval(() => loadMessages(false), 3500);
    } else {
      showExtLoginGate();
    }
  }

  initPopup();
})();
