// 화타펫 (HwataPet) AI 작업 감지 스크립트 (대화 내용은 절대 수집하지 않으며 타이핑 상태만 연동)
(() => {
  if (window.__hwatapetHooked) return;
  window.__hwatapetHooked = true;
  const h = location.hostname;
  const site = /claude\.ai$/.test(h) ? 'claude.ai' : /chatgpt\.com$|chat\.openai\.com$/.test(h) ? 'chatgpt.com' : /gemini\.google\.com$/.test(h) ? 'gemini' : null;
  if (!site) return;
  const notify = (kind, chars = 0, ms = 0) => {
    try {
      window.postMessage({ __hwatapet: 1, site, kind, conv: 'session', chars, ms }, location.origin);
    } catch {}
  };
  const origFetch = window.fetch;
  window.fetch = function (input, init) {
    const url = typeof input === 'string' ? input : (input && input.url) || '';
    const method = String((init && init.method) || 'GET').toUpperCase();
    const isAiTurn = method === 'POST' && (/conversation|completion|StreamGenerate/i.test(url));
    const t0 = Date.now();
    if (isAiTurn) notify('prompt', 0, 0);
    const p = origFetch.apply(this, arguments);
    if (isAiTurn) {
      p.then((res) => {
        setTimeout(() => notify('reply', 180, Date.now() - t0), 1800);
        return res;
      }).catch(() => {});
    }
    return p;
  };
})();
