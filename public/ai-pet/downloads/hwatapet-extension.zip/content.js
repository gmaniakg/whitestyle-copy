// 화타펫 (HwataPet / 하야니) v3.0.0 — 브라우저 우측 하단 3D 구강 웰니스 반려 펫
(() => {
  if (window.__hwata3DFloatingLoaded || window.top !== window.self) return;
  window.__hwata3DFloatingLoaded = true;

  const host = document.createElement('div');
  host.id = 'hwatapet-3d-root';
  host.style.cssText = 'position:fixed;right:18px;bottom:18px;z-index:2147483646;pointer-events:none;font-family:Pretendard,"Malgun Gothic",system-ui,sans-serif;';
  const shadow = host.attachShadow({ mode: 'open' });

  const getAsset = (name) => {
    try {
      return chrome.runtime.getURL('assets3d/hwata_3d_' + name + '.png');
    } catch {
      return '';
    }
  };

  shadow.innerHTML = `
    <style>
      * { box-sizing: border-box; word-break: keep-all; overflow-wrap: break-word; }
      .wrap { position: relative; display: flex; flex-direction: column; align-items: flex-end; pointer-events: none; }
      .panel {
        pointer-events: auto; width: 356px; max-height: 520px; margin-bottom: 8px;
        background: #1e1814; color: #f4e9df; border: 1px solid #5a463a; border-radius: 16px;
        box-shadow: 0 14px 36px rgba(0,0,0,0.45); display: none; flex-direction: column; overflow: hidden;
        font-size: 12.5px; line-height: 1.5;
      }
      .panel.open { display: flex; }
      .p-head {
        padding: 10px 12px; background: linear-gradient(180deg, #33261e, #1e1814);
        border-bottom: 1px solid #5a463a; display: flex; justify-content: space-between; align-items: center;
      }
      .p-title b { font-size: 13px; color: #fffaf3; display: block; }
      .p-title span { display: block; font-size: 10.5px; color: #34d399; font-weight: 700; margin-top: 2px; }
      .p-close { background: none; border: 0; color: #b49c8d; font-size: 16px; cursor: pointer; padding: 2px 6px; }
      .p-chips {
        display: flex; flex-wrap: wrap; gap: 4px; padding: 7px 10px; border-bottom: 1px solid rgba(90,70,58,0.45);
        background: #201813;
      }
      .p-chip {
        flex: none; padding: 4px 8px; border-radius: 999px; border: 1px dashed #5a463a;
        background: #29211c; color: #f4e9df; font-size: 11px; font-weight: 600; cursor: pointer;
      }
      .p-chip:hover { border-color: #d97757; background: #362a23; }
      .p-body { padding: 10px 12px; overflow-y: auto; max-height: 360px; display: flex; flex-direction: column; gap: 8px; }
      .msg { padding: 10px 12px; border-radius: 10px; background: #29211c; border: 1px solid #5a463a; }
      .card-form { display: grid; gap: 6px; margin-top: 8px; }
      .card-form select {
        width: 100%; padding: 6px 8px; border-radius: 6px; border: 1px solid #5a463a;
        background: #1e1814; color: #f4e9df; font: inherit; font-size: 11.5px;
      }
      .act-btn {
        width: 100%; padding: 8px 10px; border-radius: 8px; border: 0;
        background: #d97757; color: #fffaf3; font-weight: 700; font-size: 12px; cursor: pointer;
      }
      .act-btn:hover { background: #e58768; }
      .opt-btn {
        text-align: left; padding: 7px 9px; border-radius: 7px; border: 1px solid #5a463a;
        background: #1e1814; color: #f4e9df; font-size: 11.5px; cursor: pointer;
      }
      .opt-btn:hover { border-color: #d97757; background: #2d221c; }
      .pet-btn-wrap { pointer-events: auto; position: relative; display: flex; align-items: center; gap: 6px; }
      .speech-pill {
        background: rgba(30, 24, 20, 0.94); color: #f4e9df; border: 1px solid #5a463a;
        padding: 6px 11px; border-radius: 999px; font-size: 11.5px; font-weight: 600;
        box-shadow: 0 6px 18px rgba(0,0,0,0.32); cursor: pointer; max-width: 310px;
        transition: opacity 0.35s ease, transform 0.35s ease;
      }
      .speech-pill.auto-hide { opacity: 0; pointer-events: none; transform: translateY(4px); }
      .pet-btn-wrap:hover .speech-pill.auto-hide { opacity: 1; pointer-events: auto; transform: translateY(0); }
      .speech-pill b { color: #f6ad93; }
      .pet-stage {
        width: 84px; height: 84px; cursor: pointer; position: relative;
        filter: drop-shadow(0 6px 14px rgba(0,0,0,0.35)); transition: transform 0.2s ease, width 0.2s ease, height 0.2s ease;
      }
      .pet-stage.mini { width: 46px; height: 46px; opacity: 0.85; }
      .pet-stage.mini canvas { width: 46px; height: 46px; }
      .pet-stage.mini:hover { opacity: 1; }
      .pet-stage:hover { transform: scale(1.06); }
      canvas { width: 84px; height: 84px; display: block; transition: width 0.2s ease, height 0.2s ease; }
      .min-btn {
        position: absolute; top: -2px; right: -2px; width: 20px; height: 20px;
        border-radius: 50%; border: 1px solid #5a463a; background: #29211c; color: #b49c8d;
        font-size: 11px; line-height: 1; cursor: pointer; display: flex; align-items: center; justify-content: center;
      }
      .timer-big { font-size: 24px; font-weight: 900; color: #34d399; text-align: center; margin: 6px 0; font-variant-numeric: tabular-nums; }
      .step-pill { background: rgba(52,211,153,0.15); color: #34d399; border: 1px solid rgba(52,211,153,0.35); border-radius: 8px; padding: 6px; font-size: 11.5px; font-weight: 700; text-align: center; }
      .breathe-pill { background: rgba(217,119,87,0.16); color: #f6ad93; border: 1px dashed #d97757; border-radius: 10px; padding: 12px; font-size: 13px; font-weight: 800; text-align: center; margin: 6px 0; }
    </style>
    <div class="wrap">
      <div class="panel" id="hwataPanel">
        <div class="p-head">
          <div class="p-title">
            <b id="hwPanelTitle">🐶 하야니 (화타펫 3D) — 구강 건강 & 턱관절 이완 도우미</b>
            <span id="hwScoreTxt">✨ 50분 어금니 이완 알림 활성 중 · 건치 스탬프 0 / 10점</span>
          </div>
          <button class="p-close" id="hwClosePanel" title="닫기">×</button>
        </div>
        <div class="p-chips">
          <button class="p-chip" data-act="relax">😬 15초 어금니 이완</button>
          <button class="p-chip" data-act="care">🪥 2분 양치 타이머</button>
          <button class="p-chip" data-act="species">🐾 6종 동물 변신</button>
          <button class="p-chip" data-act="selfcheck">🔍 30초 자가점검</button>
          <button class="p-chip" data-act="scaling">⏳ 건보 스케일링 체크</button>
          <button class="p-chip" data-act="quiz">✨ 치아상식 퀴즈</button>
          <button class="p-chip" data-act="display">⚙️ 노출 설정</button>
        </div>
        <div class="p-body" id="hwBody"></div>
      </div>
      <div class="pet-btn-wrap">
        <div class="speech-pill" id="hwBubble">🐾 집중할 때 무의식중에 깨문 <b>어금니를 2~3mm 살짝 띄워</b> 주세요!</div>
        <div class="pet-stage" id="hwStage" title="화타펫 3D 열기">
          <canvas id="hwCanvas" width="168" height="168"></canvas>
          <button class="min-btn" id="hwHideBtn" title="노출 설정 열기">×</button>
        </div>
      </div>
    </div>
  `;

  document.documentElement.appendChild(host);

  const cv = shadow.getElementById('hwCanvas');
  const ctx = cv.getContext('2d');
  const panel = shadow.getElementById('hwataPanel');
  const body = shadow.getElementById('hwBody');
  const bubble = shadow.getElementById('hwBubble');
  const scoreTxt = shadow.getElementById('hwScoreTxt');

  let score = Number(localStorage.getItem('hwata_score') || 0);
  let mode = 'idle';
  let brushTimer = null;

  const poses = {};
  ['idle', 'blink', 'type1', 'type2', 'wave', 'brush'].forEach((k) => {
    const im = new Image();
    im.src = getAsset(k);
    poses[k] = im;
  });

  const SPECIES_LIST = [
    { id: 'dog', name: '강아지 하야니', emoji: '🐶', desc: '치아 건강과 밝은 미소를 지켜주는 귀여운 3D 마스코트 강아지 하야니' },
    { id: 'elephant', name: '코끼리 코코', emoji: '🐘', desc: '든든한 어금니 건강 수호신 아기 코끼리 코코' },
    { id: 'dino', name: '공룡 디노', emoji: '🦖', desc: '튼튼한 건치 에너자이저 아기 공룡 디노' },
    { id: 'python', name: '파이톤 파이', emoji: '🐍', desc: '유연한 턱관절 이완 멘토 꼬마 파이톤 파이' },
    { id: 'parrot', name: '앵무새 코코아', emoji: '🦜', desc: '상쾌한 구강 케어 알리미 오색 앵무새 코코아' },
    { id: 'cat', name: '고양이 치즈', emoji: '🐱', desc: '깔끔한 그루밍과 양치 습관 요정 고양이 치즈' },
  ];
  const speciesImgs = {};
  SPECIES_LIST.forEach((sp) => {
    if (sp.id !== 'dog') {
      const im = new Image();
      im.src = getAsset('species_' + sp.id);
      speciesImgs[sp.id] = im;
    }
  });
  let currentSpeciesIdx = Math.max(0, SPECIES_LIST.findIndex((s) => s.id === (localStorage.getItem('hwata_ext_species') || 'dog')));

  function updatePanelHeader() {
    const sp = SPECIES_LIST[currentSpeciesIdx] || SPECIES_LIST[0];
    const titleEl = shadow.getElementById('hwPanelTitle');
    if (titleEl) {
      titleEl.textContent = `${sp.emoji} ${sp.name} (화타펫 3D) — 구강 건강 & 턱관절 이완 도우미`;
    }
  }

  function updateScore(add = 0) {
    if (add > 0) {
      score += add;
      localStorage.setItem('hwata_score', String(score));
      try {
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
          chrome.storage.local.set({ hwata_score: score });
        }
      } catch {}
    }
    scoreTxt.textContent = `✨ 50분 어금니 이완 알림 활성 중 · 건치 스탬프 ${score} / 10점`;
  }
  updatePanelHeader();
  updateScore(0);

  function loop() {
    const t = performance.now() / 1000;
    ctx.clearRect(0, 0, 168, 168);
    const blink = (t % 4.1) < 0.14;
    let k = 'idle';
    if (mode === 'wave') k = 'wave';
    else if (mode === 'brush') k = 'brush';
    else if (mode === 'type') k = Math.floor(t * 8) % 2 ? 'type1' : 'type2';
    else if (blink) k = 'blink';
    let im = poses[k] || poses.idle;
    const curSp = SPECIES_LIST[currentSpeciesIdx] || SPECIES_LIST[0];
    if (curSp.id !== 'dog' && speciesImgs[curSp.id] && speciesImgs[curSp.id].complete && speciesImgs[curSp.id].naturalWidth > 0) {
      im = speciesImgs[curSp.id];
    }
    if (im && im.complete && im.naturalWidth > 0) {
      const br = Math.sin(t * 2.9);
      const sx = 1 - br * 0.018;
      const sy = 1 + br * 0.03;
      const dy = mode === 'wave' ? -Math.abs(Math.sin(t * 7)) * 8 : 0;
      ctx.save();
      ctx.translate(84, 154 + dy);
      ctx.scale(sx, sy);
      ctx.drawImage(im, -74, -144, 148, 148);
      ctx.restore();
    }
    requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);

  function showJawRelax() {
    mode = 'wave';
    body.innerHTML = `
      <div class="msg">
        <b>😬 15초 어금니 이완 & 턱관절 스트레칭</b><br>
        <small style="color:#b49c8d">모니터에 집중할 때 윗니와 아랫니가 닿지 않도록 턱 긴장을 풀어주세요.</small>
        <div class="breathe-pill" id="hwBreatheBox">준비되셨나요? 시작 버튼을 눌러주세요</div>
        <button class="act-btn" id="hwStartRelax">✨ 15초 호흡 가이드 시작 (+2점)</button>
      </div>
    `;
    const box = body.querySelector('#hwBreatheBox');
    const btn = body.querySelector('#hwStartRelax');
    btn.addEventListener('click', () => {
      btn.disabled = true;
      box.textContent = '1단계: 코로 천천히 숨 들이마시기 (4초)';
      setTimeout(() => {
        box.textContent = '2단계: 윗니-아랫니 2~3mm 띄우고 턱 힘빼기 (7초)';
        setTimeout(() => {
          box.textContent = '3단계: 입으로 길게 후- 내쉬기 (4초)';
          setTimeout(() => {
            updateScore(2);
            mode = 'idle';
            box.textContent = '✨ 이완 완료! 건치 스탬프 +2점 적립!';
            btn.disabled = false;
            btn.textContent = '🔄 한 번 더 이완하기';
          }, 4000);
        }, 7000);
      }, 4000);
    });
  }

  function showBrushTimer() {
    if (brushTimer) {
      clearInterval(brushTimer);
      brushTimer = null;
    }
    let remain = 120;
    mode = 'brush';
    body.innerHTML = `
      <div class="msg">
        <b>🪥 2분 바스법(Bass) 양치 타이머</b>
        <div class="timer-big" id="hwBrushClock">02:00</div>
        <div class="step-pill" id="hwBrushStep">1단계: 상악 우측 어금니 (잇몸 45도 쓸어내리기)</div>
        <div class="card-form">
          <button class="act-btn" id="hwBrushStart">▶ 2분 양치 시작</button>
          <button class="opt-btn" id="hwBrushQuick" style="text-align:center;">✅ 양치 완료 체크 (+3점 적립)</button>
        </div>
      </div>
    `;
    const clockEl = body.querySelector('#hwBrushClock');
    const stepEl = body.querySelector('#hwBrushStep');
    const startBtn = body.querySelector('#hwBrushStart');
    const quickBtn = body.querySelector('#hwBrushQuick');

    const updateClock = () => {
      const m = Math.floor(remain / 60);
      const s = remain % 60;
      clockEl.textContent = `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
      const elapsed = 120 - remain;
      if (elapsed > 90) stepEl.textContent = '4단계: 하악 우측 어금니 및 혀 가볍게 닦기';
      else if (elapsed > 60) stepEl.textContent = '3단계: 하악 좌측 & 앞니 안쪽 쓸어올리기';
      else if (elapsed > 30) stepEl.textContent = '2단계: 상악 앞니 & 좌측 어금니 꼼꼼히';
      else stepEl.textContent = '1단계: 상악 우측 어금니 (잇몸 45도 쓸어내리기)';
    };

    startBtn.addEventListener('click', () => {
      if (brushTimer) return;
      startBtn.disabled = true;
      startBtn.textContent = '🪥 양치 진행 중...';
      brushTimer = setInterval(() => {
        if (remain > 0) {
          remain--;
          updateClock();
        } else {
          clearInterval(brushTimer);
          brushTimer = null;
          mode = 'idle';
          updateScore(3);
          stepEl.textContent = '🎉 2분 양치 완료! 건치 스탬프 +3점 적립!';
          startBtn.disabled = false;
          startBtn.textContent = '▶ 다시 시작';
        }
      }, 1000);
    });

    quickBtn.addEventListener('click', () => {
      if (brushTimer) {
        clearInterval(brushTimer);
        brushTimer = null;
      }
      mode = 'idle';
      updateScore(3);
      body.innerHTML = `<div class="msg">🎉 <b>2분 바스법 양치 완료! (+3점 적립 · 현재 ${score}/10점)</b><br>상쾌한 구강 관리를 멋지게 실천하셨어요 멍! 🐾</div>`;
    });
  }

  function showScaling() {
    const yr = new Date().getFullYear();
    const remainDays = Math.max(0, Math.ceil((new Date(yr, 11, 31) - new Date()) / (1000 * 60 * 60 * 24)));
    body.innerHTML = `
      <div class="msg">
        <b>⏳ ${yr}년 건강보험 스케일링 주기 확인</b><br>
        만 19세 이상이라면 매년 1월 1일~12월 31일 연 1회 건강보험 스케일링이 적용됩니다. (올해 갱신까지 <b>${remainDays}일</b> 남음)
        <div class="card-form">
          <button class="opt-btn" data-sc="todo">📝 아직 안 받았어요 (일정 기억하기 +2점)</button>
          <button class="opt-btn" data-sc="done">✅ 올해 이미 받았어요! (+2점 스탬프)</button>
        </div>
      </div>
    `;
    body.querySelectorAll('.opt-btn').forEach((b) => {
      b.addEventListener('click', () => {
        updateScore(2);
        if (b.dataset.sc === 'done') {
          body.innerHTML = `<div class="msg">🎉 <b>올해 스케일링 실천 인증! (+2점 · 현재 ${score}/10점)</b><br>6개월 주기로 정기 검진을 챙기면 잇몸 건강을 오래 지킬 수 있습니다.</div>`;
        } else {
          body.innerHTML = `<div class="msg">📌 <b>스케일링 일정 체크 완료! (+2점 · 현재 ${score}/10점)</b><br>${yr}년 12월 31일 소멸 전 정기 치석 제거를 잊지 마세요!</div>`;
        }
      });
    });
  }

  function showSelfCheck() {
    const TIPS = {
      cold: '미세모 칫솔과 시린이 전용 치약을 사용하고, 가로 방향 세게 닦기 대신 잇몸에서 치아 방향으로 부드럽게 쓸어내리는 양치법을 권장합니다.',
      gum: '칫솔모를 잇몸선 45도 각도로 대고 미세하게 진동시킨 뒤 쓸어내리는 바스법과 하루 1회 치실 사용으로 잇몸 경계부 플라그를 관리해 보세요.',
      jaw: '모니터 작업 시 입술은 편하게 다물고 윗니와 아랫니 사이를 2~3mm 살짝 띄우는 이완 습관이 턱관절 부담을 크게 줄여줍니다.',
      brush: '상악 우측 ➔ 상악 전치·좌측 ➔ 하악 좌측·전치 ➔ 하악 우측 및 혀 순서로 구역별 30초씩 총 2분간 꼼꼼히 닦아주세요.',
    };
    body.innerHTML = `
      <div class="msg">
        <b>🔍 30초 구강 건강 자가점검 (+2점)</b><br>가장 신경 쓰이는 증상을 선택하면 관리 가이드를 알려드려요!
        <div class="card-form">
          <button class="opt-btn" data-k="cold">① 찬물 마실 때 이가 시려요</button>
          <button class="opt-btn" data-k="gum">② 양치할 때 잇몸이 붓거나 피가 나요</button>
          <button class="opt-btn" data-k="jaw">③ 집중 후 턱이 뻐근하고 뻐적거려요</button>
          <button class="opt-btn" data-k="brush">④ 올바른 양치 순서를 알고 싶어요</button>
        </div>
      </div>
    `;
    body.querySelectorAll('.opt-btn').forEach((b) => {
      b.addEventListener('click', () => {
        updateScore(2);
        const tip = TIPS[b.dataset.k] || TIPS.cold;
        body.innerHTML = `<div class="msg">🎯 <b>자가점검 관리 팁 (+2점 · 현재 ${score}/10점)</b><br>${tip}<br><br><small style="color:#b49c8d">※ 일상 구강 위생 참고용이며 통증 지속 시 가까운 치과 검진을 권장합니다.</small></div>`;
      });
    });
  }

  function showQuiz() {
    body.innerHTML = `
      <div class="msg">
        <b>✨ 화타의 치아상식 퀴즈 (+2점)</b><br>
        탄산음료나 커피 같은 산성 음료를 마신 직후, 치아 법랑질 손상을 막기 위한 올바른 습관은?
        <div class="card-form">
          <button class="opt-btn" data-ans="1">① 물로 입안을 먼저 헹구고 20~30분 뒤 양치하기</button>
          <button class="opt-btn" data-ans="0">② 마시자마자 10초 안에 세게 칫솔질하기</button>
        </div>
      </div>
    `;
    body.querySelectorAll('.opt-btn').forEach((b) => {
      b.addEventListener('click', () => {
        if (b.dataset.ans === '1') {
          updateScore(2);
          mode = 'wave';
          setTimeout(() => (mode = 'idle'), 1500);
          body.innerHTML = `<div class="msg">🎉 <b>정답이야 멍! (+2점 · 현재 ${score}/10점)</b><br>산성 음료 직후엔 치아 표면이 일시적으로 약해지므로 물로 헹군 뒤 20~30분 후 양치하는 것이 좋아요!</div>`;
        } else {
          body.innerHTML = `<div class="msg">💡 아쉬워요! 산성 음료 직후 바로 양치하면 법랑질이 마모될 수 있으니 물로 먼저 헹구고 20~30분 후 양치해 주세요!</div>`;
        }
      });
    });
  }

  function togglePanel() {
    panel.classList.toggle('open');
    if (panel.classList.contains('open') && !body.innerHTML) {
      showJawRelax();
    }
  }

  // ---------- ⚙️ 화면 가림 방지 & 맞춤 노출 제어 시스템 ----------
  const curHost = (location.hostname || '').replace(/^www\./, '').toLowerCase();
  let displayPrefs = {
    enabled: true,
    miniMode: false,
    position: 'bottom-right',
    snoozeUntil: 0,
    excludedHosts: [],
    quietHours: 'none',
  };

  function isWithinQuietHours(qh) {
    if (!qh || qh === 'none') return false;
    const hr = new Date().getHours();
    if (qh === 'night') return hr >= 22 || hr < 8;
    if (qh === 'work') return hr >= 9 && hr < 18;
    return false;
  }

  function applyDisplayPrefs(prefs) {
    displayPrefs = Object.assign({}, displayPrefs, prefs || {});
    const stg = shadow.getElementById('hwStage');
    const wrapEl = shadow.querySelector('.wrap');
    if (stg) stg.classList.toggle('mini', !!displayPrefs.miniMode);
    if (displayPrefs.position === 'bottom-left') {
      host.style.right = 'auto';
      host.style.left = '18px';
      if (wrapEl) wrapEl.style.alignItems = 'flex-start';
    } else {
      host.style.left = 'auto';
      host.style.right = '18px';
      if (wrapEl) wrapEl.style.alignItems = 'flex-end';
    }
    const isExcluded = Array.isArray(displayPrefs.excludedHosts) && displayPrefs.excludedHosts.includes(curHost);
    const isSnoozed = Number(displayPrefs.snoozeUntil || 0) > Date.now();
    const isQuiet = isWithinQuietHours(displayPrefs.quietHours);
    if (!displayPrefs.enabled || isExcluded || isSnoozed || isQuiet) {
      host.style.display = 'none';
    } else {
      host.style.display = '';
    }
  }

  function saveDisplayPrefs(patch) {
    const next = Object.assign({}, displayPrefs, patch || {});
    applyDisplayPrefs(next);
    try { localStorage.setItem('hwata_display_prefs', JSON.stringify(next)); } catch {}
    try {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.set({ hwata_display_prefs: next });
      }
    } catch {}
  }

  try {
    const rawLocal = localStorage.getItem('hwata_display_prefs');
    if (rawLocal) applyDisplayPrefs(JSON.parse(rawLocal));
  } catch {}
  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.get(['hwata_display_prefs', 'hwata_ext_species', 'hwata_score'], (res) => {
        if (res && res.hwata_display_prefs) applyDisplayPrefs(res.hwata_display_prefs);
        if (res && res.hwata_ext_species) {
          const idx = SPECIES_LIST.findIndex((s) => s.id === res.hwata_ext_species);
          if (idx >= 0) {
            currentSpeciesIdx = idx;
            updatePanelHeader();
          }
        }
        if (res && typeof res.hwata_score === 'number' && res.hwata_score > score) {
          score = res.hwata_score;
          localStorage.setItem('hwata_score', String(score));
          updateScore(0);
        }
      });
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area === 'local' && changes.hwata_display_prefs && changes.hwata_display_prefs.newValue) {
          applyDisplayPrefs(changes.hwata_display_prefs.newValue);
        }
        if (area === 'local' && changes.hwata_ext_species && changes.hwata_ext_species.newValue) {
          const idx = SPECIES_LIST.findIndex((s) => s.id === changes.hwata_ext_species.newValue);
          if (idx >= 0) {
            currentSpeciesIdx = idx;
            updatePanelHeader();
          }
        }
        if (area === 'local' && changes.hwata_score && typeof changes.hwata_score.newValue === 'number') {
          score = changes.hwata_score.newValue;
          localStorage.setItem('hwata_score', String(score));
          updateScore(0);
        }
      });
    }
  } catch {}

  setTimeout(() => {
    if (bubble) bubble.classList.add('auto-hide');
  }, 5000);

  function showDisplaySettings() {
    const isMini = !!displayPrefs.miniMode;
    const isLeft = displayPrefs.position === 'bottom-left';
    const qh = displayPrefs.quietHours || 'none';
    const curSp = SPECIES_LIST[currentSpeciesIdx] || SPECIES_LIST[0];
    body.innerHTML = `
      <div class="msg">
        <b>⚙️ 위젯 노출 맞춤 설정 & 3D 파트너 변경</b><br>
        <small style="color:#b49c8d">웹서핑에 방해되지 않도록 크기·위치를 조절하거나 6종 동물 친구로 변신할 수 있습니다.</small>
        <div class="card-form">
          <button class="opt-btn" data-dact="switch-species">🐾 3D 파트너 변신: <b>현재 [${curSp.emoji} ${curSp.name}]</b></button>
          <button class="opt-btn" data-dact="tab-hide">🙈 1. 이번 탭에서만 즉시 숨기기</button>
          <button class="opt-btn" data-dact="snooze-1h">🌙 2. 1시간 동안 모든 사이트에서 숨기기 (집중 모드)</button>
          <button class="opt-btn" data-dact="snooze-24h">📅 3. 오늘 하루(24시간) 동안 숨기기</button>
          <button class="opt-btn" data-dact="site-exclude">🚫 4. 이 사이트(${curHost || '현재 사이트'})에서는 항상 숨기기</button>
          <button class="opt-btn" data-dact="toggle-mini">🔹 5. 초소형 미니 아이콘 모드 (46px): <b>${isMini ? '켜짐 → 기본 크기로' : '꺼짐 → 미니 모드로 축소'}</b></button>
          <button class="opt-btn" data-dact="toggle-pos">↔️ 6. 화면 위치 변경: <b>${isLeft ? '좌측 하단 → 우측 하단' : '우측 하단 → 좌측 하단'}</b></button>
          <select id="hwQuietSel">
            <option value="none"${qh === 'none' ? ' selected' : ''}>⏰ 시간대 자동 숨김: 사용 안 함</option>
            <option value="night"${qh === 'night' ? ' selected' : ''}>🌙 야간 방해 금지 (22:00 ~ 익일 08:00 숨김)</option>
            <option value="work"${qh === 'work' ? ' selected' : ''}>💼 업무 집중 시간 (09:00 ~ 18:00 숨김)</option>
          </select>
          <button class="opt-btn" data-dact="disable-all" style="border-color:#ef4444;color:#fca5a5;">🔕 7. 웹페이지 플로팅 펫 완전히 끄기 (툴바 팝업만 사용)</button>
        </div>
      </div>
    `;
    const qSel = body.querySelector('#hwQuietSel');
    if (qSel) qSel.addEventListener('change', () => saveDisplayPrefs({ quietHours: qSel.value }));

    body.querySelectorAll('[data-dact]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const dact = btn.dataset.dact;
        if (dact === 'switch-species') {
          currentSpeciesIdx = (currentSpeciesIdx + 1) % SPECIES_LIST.length;
          const sp = SPECIES_LIST[currentSpeciesIdx];
          localStorage.setItem('hwata_ext_species', sp.id);
          try { if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) chrome.storage.local.set({ hwata_ext_species: sp.id }); } catch {}
          mode = 'wave';
          setTimeout(() => (mode = 'idle'), 2000);
          updatePanelHeader();
          bubble.innerHTML = `${sp.emoji} <b>${sp.name}</b>(으)로 변신 완료! 🐾`;
          showDisplaySettings();
        } else if (dact === 'tab-hide') {
          host.style.display = 'none';
        } else if (dact === 'snooze-1h') {
          saveDisplayPrefs({ snoozeUntil: Date.now() + 60 * 60 * 1000 });
        } else if (dact === 'snooze-24h') {
          saveDisplayPrefs({ snoozeUntil: Date.now() + 24 * 60 * 60 * 1000 });
        } else if (dact === 'site-exclude') {
          const list = Array.isArray(displayPrefs.excludedHosts) ? displayPrefs.excludedHosts.slice() : [];
          if (curHost && !list.includes(curHost)) list.push(curHost);
          saveDisplayPrefs({ excludedHosts: list });
        } else if (dact === 'toggle-mini') {
          saveDisplayPrefs({ miniMode: !displayPrefs.miniMode });
          showDisplaySettings();
        } else if (dact === 'toggle-pos') {
          saveDisplayPrefs({ position: displayPrefs.position === 'bottom-left' ? 'bottom-right' : 'bottom-left' });
          showDisplaySettings();
        } else if (dact === 'disable-all') {
          saveDisplayPrefs({ enabled: false });
        }
      });
    });
  }

  shadow.getElementById('hwStage').addEventListener('click', (e) => {
    if (e.target.id === 'hwHideBtn') return;
    togglePanel();
  });
  bubble.addEventListener('click', togglePanel);

  try {
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg && msg.type === 'HWATA_JAW_RELAX_ALERT' && bubble) {
        bubble.classList.remove('auto-hide');
        bubble.innerHTML = '😬 <b>' + (msg.title || '어금니 이완 알림') + '</b><br>' + (msg.message || '어금니를 2~3mm 띄우고 턱의 긴장을 풀어주세요!');
        bubble.style.display = 'block';
        mode = 'wave';
        setTimeout(() => {
          bubble.classList.add('auto-hide');
          mode = 'idle';
        }, 10000);
      }
    });
  } catch {}

  shadow.getElementById('hwClosePanel').addEventListener('click', () => panel.classList.remove('open'));
  shadow.getElementById('hwHideBtn').addEventListener('click', (e) => {
    e.stopPropagation();
    panel.classList.add('open');
    showDisplaySettings();
  });

  shadow.querySelectorAll('.p-chip').forEach((c) => {
    c.addEventListener('click', () => {
      const act = c.dataset.act;
      if (act === 'relax') showJawRelax();
      else if (act === 'care') showBrushTimer();
      else if (act === 'species') {
        currentSpeciesIdx = (currentSpeciesIdx + 1) % SPECIES_LIST.length;
        const sp = SPECIES_LIST[currentSpeciesIdx];
        localStorage.setItem('hwata_ext_species', sp.id);
        try { if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) chrome.storage.local.set({ hwata_ext_species: sp.id }); } catch {}
        mode = 'wave';
        setTimeout(() => (mode = 'idle'), 2000);
        updatePanelHeader();
        bubble.innerHTML = `${sp.emoji} <b>${sp.name}</b>(으)로 변신 완료! 🐾`;
        body.innerHTML = `<div class="msg">${sp.emoji} <b>[${sp.name}] 3D 동물 변신 완료!</b><br>${sp.desc}<br><small style="color:#b49c8d">버튼을 다시 누르면 6종 동물 친구(강아지·코끼리·공룡·파이톤·앵무새·고양이)로 순서대로 변신합니다.</small></div>`;
      }
      else if (act === 'selfcheck') showSelfCheck();
      else if (act === 'scaling') showScaling();
      else if (act === 'quiz') showQuiz();
      else if (act === 'display') showDisplaySettings();
    });
  });
})();
