// 화타펫 (HwataPet / 하야니) 브라우저 우측 하단 3D 플로팅 반려 펫 (화타 스마일 PASS 전체 기능 잠금 해제 & 보철/임플란트 정회원 무료 AI API 로컬 프로토콜)
(() => {
  if (window.__hwata3DFloatingLoaded || window.top !== window.self) return;
  window.__hwata3DFloatingLoaded = true;

  const host = document.createElement('div');
  host.id = 'hwatapet-3d-root';
  host.style.cssText = 'position:fixed;right:18px;bottom:18px;z-index:2147483646;pointer-events:none;font-family:Pretendard,"Malgun Gothic",system-ui,sans-serif;';
  const shadow = host.attachShadow({ mode: 'open' });

  const getAsset = (name) => {
    try {
      return chrome.runtime.getURL('assets3d/hwata_3d_' + name + '.png');
    } catch {
      return '';
    }
  };

  shadow.innerHTML = `
    <style>
      * { box-sizing: border-box; word-break: keep-all; overflow-wrap: break-word; }
      .wrap { position: relative; display: flex; flex-direction: column; align-items: flex-end; pointer-events: none; }
      .panel {
        pointer-events: auto; width: 364px; max-height: 540px; margin-bottom: 8px;
        background: #1e1814; color: #f4e9df; border: 1px solid #5a463a; border-radius: 16px;
        box-shadow: 0 14px 36px rgba(0,0,0,0.45); display: none; flex-direction: column; overflow: hidden;
        font-size: 12.5px; line-height: 1.5;
      }
      .panel.open { display: flex; }
      .p-head {
        padding: 10px 12px; background: linear-gradient(180deg, #33261e, #1e1814);
        border-bottom: 1px solid #5a463a; display: flex; justify-content: space-between; align-items: center;
      }
      .p-title b { font-size: 13.5px; color: #fffaf3; }
      .p-title span { display: block; font-size: 10.5px; color: #f6ad93; font-weight: 700; }
      .p-close { background: none; border: 0; color: #b49c8d; font-size: 16px; cursor: pointer; padding: 2px 6px; }
      .p-chips {
        display: flex; flex-wrap: wrap; gap: 4px; padding: 6px 10px; border-bottom: 1px solid rgba(90,70,58,0.4);
      }
      .p-chip {
        flex: none; padding: 4px 8px; border-radius: 999px; border: 1px dashed #5a463a;
        background: #29211c; color: #f4e9df; font-size: 11px; font-weight: 600; cursor: pointer;
      }
      .p-chip:hover { border-color: #d97757; background: #362a23; }
      .p-body { padding: 10px 12px; overflow-y: auto; max-height: 360px; display: flex; flex-direction: column; gap: 8px; }
      .msg { padding: 9px 11px; border-radius: 10px; background: #29211c; border: 1px solid #5a463a; }
      .card-form { display: grid; gap: 5px; margin-top: 6px; }
      .card-form input, .card-form select {
        width: 100%; padding: 6px 7px; border-radius: 6px; border: 1px solid #5a463a;
        background: #1e1814; color: #f4e9df; font: inherit; font-size: 11.5px;
      }
      .act-btn {
        width: 100%; padding: 7px 10px; border-radius: 8px; border: 0;
        background: #d97757; color: #fffaf3; font-weight: 700; font-size: 12px; cursor: pointer;
      }
      .opt-btn {
        text-align: left; padding: 6px 8px; border-radius: 7px; border: 1px solid #5a463a;
        background: #1e1814; color: #f4e9df; font-size: 11.5px; cursor: pointer;
      }
      .opt-btn:hover { border-color: #d97757; }
      .pet-btn-wrap { pointer-events: auto; position: relative; display: flex; align-items: center; gap: 6px; }
      .speech-pill {
        background: rgba(30, 24, 20, 0.94); color: #f4e9df; border: 1px solid #5a463a;
        padding: 6px 11px; border-radius: 999px; font-size: 11.5px; font-weight: 600;
        box-shadow: 0 6px 18px rgba(0,0,0,0.32); cursor: pointer; max-width: 320px;
      }
      .speech-pill b { color: #f6ad93; }
      .pet-stage {
        width: 84px; height: 84px; cursor: pointer; position: relative;
        filter: drop-shadow(0 6px 14px rgba(0,0,0,0.35)); transition: transform 0.2s ease;
      }
      .pet-stage:hover { transform: scale(1.06); }
      canvas { width: 84px; height: 84px; display: block; }
      .min-btn {
        position: absolute; top: -2px; right: -2px; width: 20px; height: 20px;
        border-radius: 50%; border: 1px solid #5a463a; background: #29211c; color: #b49c8d;
        font-size: 11px; line-height: 1; cursor: pointer; display: flex; align-items: center; justify-content: center;
      }
      .code-box {
        background: #14100d; border: 1px solid #5a463a; border-radius: 6px; padding: 6px 8px;
        font-family: ui-monospace, monospace; font-size: 10.5px; color: #6ee7b7; word-break: break-all; margin-top: 4px;
      }
    </style>
    <div class="wrap">
      <div class="panel" id="hwataPanel">
        <div class="p-head">
          <div class="p-title">
            <b>🐶 하야니 (화타펫) 3D · 화이트스타일치과의원</b>
            <span id="hwScoreTxt">🔓 PASS 등록 시 하야니 전체 기능 잠금 해제 · 정회원 무료 AI API</span>
          </div>
          <button class="p-close" id="hwClosePanel" title="닫기">×</button>
        </div>
        <div class="p-chips">
          <button class="p-chip" data-act="pass">🔓 PASS 등록</button>
          <button class="p-chip" data-act="freeapi">⚡ 무료 AI API</button>
          <button class="p-chip" data-act="booking">♥ 진료 예약</button>
          <button class="p-chip" data-act="scaling">⏳ 건보 스케일링</button>
          <button class="p-chip" data-act="selfcheck">🔍 30초 자가체크</button>
          <button class="p-chip" data-act="care">🪥 2분 양치타이머</button>
          <button class="p-chip" data-act="quiz">✨ 치아퀴즈</button>
        </div>
        <div class="p-body" id="hwBody"></div>
      </div>
      <div class="pet-btn-wrap">
        <div class="speech-pill" id="hwBubble">멍! <b>화타 스마일 PASS 등록</b> & <b>정회원 무료 AI API</b> 프로토콜 🐾</div>
        <div class="pet-stage" id="hwStage" title="하야니 3D 클릭해서 PASS 등록 및 무료 AI API 열기">
          <canvas id="hwCanvas" width="168" height="168"></canvas>
          <button class="min-btn" id="hwHideBtn" title="이번 탭에서 숨기기">×</button>
        </div>
      </div>
    </div>
  `;

  document.documentElement.appendChild(host);

  const cv = shadow.getElementById('hwCanvas');
  const ctx = cv.getContext('2d');
  const panel = shadow.getElementById('hwataPanel');
  const body = shadow.getElementById('hwBody');
  const bubble = shadow.getElementById('hwBubble');
  const scoreTxt = shadow.getElementById('hwScoreTxt');

  let score = Number(localStorage.getItem('hwata_ext_score') || 0);
  let vipCode = localStorage.getItem('hwata_ext_vip') || '';
  let mode = 'idle';

  function ensurePass(force = false) {
    if ((!vipCode && score >= 10) || (!vipCode && force)) {
      vipCode = 'HWATA-PASS-' + (1000 + Math.floor(Math.random() * 9000));
      localStorage.setItem('hwata_ext_vip', vipCode);
    }
    return vipCode;
  }

  const poses = {};
  ['idle', 'blink', 'type1', 'type2', 'wave', 'brush'].forEach((k) => {
    const im = new Image();
    im.src = getAsset(k);
    poses[k] = im;
  });

  function updateScore(add = 0) {
    if (add > 0) {
      score += add;
      localStorage.setItem('hwata_ext_score', String(score));
    }
    scoreTxt.textContent = vipCode
      ? `🔓 PASS 활성화됨 (${vipCode}) · 하야니 모든 기능 잠금 해제 완료`
      : `🔒 PASS 미등록 · PASS에 등록해야 AI 펫(하야니) 모든 기능 이용 가능`;
  }
  updateScore(0);

  function loop() {
    const t = performance.now() / 1000;
    ctx.clearRect(0, 0, 168, 168);
    const blink = (t % 4.1) < 0.14;
    let k = 'idle';
    if (mode === 'wave') k = 'wave';
    else if (mode === 'brush') k = 'brush';
    else if (mode === 'type') k = Math.floor(t * 8) % 2 ? 'type1' : 'type2';
    else if (blink) k = 'blink';
    const im = poses[k] || poses.idle;
    if (im && im.complete && im.naturalWidth > 0) {
      const br = Math.sin(t * 2.9);
      const sx = 1 - br * 0.018;
      const sy = 1 + br * 0.03;
      const dy = mode === 'wave' ? -Math.abs(Math.sin(t * 7)) * 8 : 0;
      ctx.save();
      ctx.translate(84, 154 + dy);
      ctx.scale(sx, sy);
      ctx.drawImage(im, -74, -144, 148, 148);
      ctx.restore();
    }
    requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);

  setInterval(() => {
    mode = 'wave';
    setTimeout(() => (mode = 'idle'), 3000);
    bubble.innerHTML = '😬 집중할 때 무의식중에 꽉 깨문 <b>어금니를 2mm만 살짝 띄워</b> 주세요 멍!';
  }, 50 * 60 * 1000);

  window.addEventListener('message', (ev) => {
    if (ev.data && ev.data.__hwatapet) {
      mode = ev.data.kind === 'prompt' ? 'type' : 'wave';
      setTimeout(() => (mode = 'idle'), 2400);
    }
  });

  function showPassRegister() {
    body.innerHTML = `
      <div class="msg">
        <b>🔓 화타 스마일 PASS 등록 (하야니 전체 기능 잠금 해제)</b><br>
        <small style="color:#f6ad93">PASS에 등록하셔야 AI 펫 '하야니'의 모든 기능(6종 3D 동물 변신 · 6종 3D 코스튬 · 91종 모션 · 7종 페르소나 대화)을 이용하실 수 있습니다.</small>
        <div class="card-form">
          <input type="text" id="pName" placeholder="성함 (예: 홍길동)">
          <input type="tel" id="pPhone" placeholder="연락처 (010-0000-0000)">
          <button class="act-btn" id="pSubmit">🔓 PASS 등록하고 하야니 전체 기능 잠금 해제</button>
        </div>
      </div>
    `;
    body.querySelector('#pSubmit').addEventListener('click', async () => {
      const name = (body.querySelector('#pName').value || '').trim();
      const phone = (body.querySelector('#pPhone').value || '').trim();
      if (!name || !phone) {
        body.querySelector('#pPhone').focus();
        return;
      }
      const code = ensurePass(true);
      updateScore(0);
      fetch('https://whinish.com/api/ai-pet/verify-member', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mode: 'pass', name, phone }),
      }).catch(() => {});
      body.innerHTML = `<div class="msg">🎉 <b>[${code}] PASS 등록 완료!</b><br>이제 AI 펫 '하야니'의 6종 3D 동물 변신, 전체 코스튬, 모든 모션과 기능을 제한 없이 이용하실 수 있습니다!</div>`;
    });
  }

  function showFreeApiProtocol() {
    body.innerHTML = `
      <div class="msg">
        <b>⚡ 화이트스타일 정회원 전용 무료 AI API 로컬 프로토콜</b><br>
        <small style="color:#f6ad93">
          • <b>이용 조건:</b> <b>whitestyle.com</b> 또는 <b>whinish.com</b> 회원 등록 후, <b>강남역 화이트스타일치과의원에 내원하여 최소 보철 치료(심미보철·라미네이트·크라운·인레이) 또는 임플란트 1개 이상 진료</b>를 받으신 정회원 전용입니다.<br>
          • <b>제공 프로토콜:</b> 전 세계 모든 무료 AI API를 통합 라우팅하여 내 컴퓨터(Cursor, VS Code, Claude Code, Python, Node.js)로 끌어다 쓸 수 있는 OpenAI 호환 프로토콜을 제공합니다.
        </small>
        <div class="card-form">
          <input type="text" id="mId" placeholder="whitestyle.com / whinish.com 회원 ID">
          <input type="text" id="mName" placeholder="환자 성함">
          <input type="tel" id="mPhone" placeholder="환자 연락처 (010-0000-0000)">
          <select id="mTreat">
            <option value="">본원에서 받으신 보철/임플란트 진료 선택 (최소 1개 필수)</option>
            <option value="prosthodontic_laminate">최소삭제 라미네이트 / 심미보철 (1개 이상 완료)</option>
            <option value="prosthodontic_ceramic">올세라믹 / 지르코니아 크라운 보철 (1개 이상 완료)</option>
            <option value="prosthodontic_inlay">세라믹 인레이 / 온레이 보철 (1개 이상 완료)</option>
            <option value="implant_3dct">3D CT 디지털 임플란트 (1개 이상 완료)</option>
            <option value="none">아직 보철/임플란트 진료 전 (내원 예약 필요)</option>
          </select>
          <input type="text" id="mCode" placeholder="원내 발급 보철/임플란트 정회원 인증번호 (예: WS-202601)">
          <button class="act-btn" id="mSubmit">⚡ 정회원 인증 & 내 컴퓨터 무료 AI API 프로토콜 발급</button>
        </div>
      </div>
    `;
    body.querySelector('#mSubmit').addEventListener('click', async () => {
      const memberId = (body.querySelector('#mId').value || '').trim();
      const name = (body.querySelector('#mName').value || '').trim();
      const phone = (body.querySelector('#mPhone').value || '').trim();
      const treatmentType = body.querySelector('#mTreat').value;
      const clinicAuthCode = (body.querySelector('#mCode').value || '').trim();
      if (treatmentType === 'none' || !treatmentType) {
        body.innerHTML = `<div class="msg">⚠️ <b>정회원 등록 안내</b><br>정회원 등록 및 무료 AI API 로컬 프로토콜은 <b>강남역 화이트스타일치과의원에 내원하여 최소 보철 치료 또는 임플란트 1개 이상 진료</b>를 받으신 분에 한하여 가능합니다.<br><br><button class="act-btn" id="goBookBtn">🏥 보철·임플란트 진료 예약하러 가기</button></div>`;
        body.querySelector('#goBookBtn')?.addEventListener('click', () => showBooking('최소삭제 심미보철·라미네이트 (김준헌 병원장님 1:1 디자인)', '[정회원 등록 위한 보철/임플란트 진료 예약]'));
        return;
      }
      try {
        const res = await fetch('https://whinish.com/api/ai-pet/verify-member', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            mode: 'regular_member',
            memberId,
            name,
            phone,
            treatmentType,
            prosthodonticCount: 1,
            clinicAuthCode,
          }),
        });
        const data = await res.json();
        if (!data.ok) {
          body.innerHTML = `<div class="msg">⚠️ <b>인증 실패:</b> ${data.message}</div>`;
          return;
        }
        localStorage.setItem('hwata_vip_api_key', data.apiKey);
        ensurePass(true);
        updateScore(0);
        body.innerHTML = `
          <div class="msg">
            🎉 <b>정회원 인증 완료! 무료 AI API 프로토콜 발급</b>
            <div class="code-box">Base URL: https://whinish.com/api/v1<br>API Key: ${data.apiKey}<br>Model: hwata-omni-free</div>
            <small style="display:block;margin-top:6px;">내 컴퓨터 연동 스크립트 및 전체 프로토콜 가이드는 <a href="https://whinish.com/ai-pet/download.html#api-protocol" target="_blank" style="color:#f6ad93;font-weight:700;">[프로토콜 센터 열기]</a>에서 복사하세요.</small>
          </div>
        `;
      } catch {
        body.innerHTML = `<div class="msg">⚠️ 네트워크 연결을 확인한 뒤 다시 시도해 주세요.</div>`;
      }
    });
  }

  function showBooking(prefillTreat, prefillMemo) {
    mode = 'wave';
    setTimeout(() => (mode = 'idle'), 1500);
    const code = ensurePass(true);
    const d = new Date();
    d.setDate(d.getDate() + 1);
    if (d.getDay() === 0) d.setDate(d.getDate() + 1);
    const defDate = d.toISOString().slice(0, 10);
    const treats = [
      '최소삭제 심미보철·라미네이트 (정회원 자격 진료 · 1:1 맞춤 디자인)',
      '임플란트 (정회원 자격 진료 · 3D CT·3단계 저통마취)',
      '올세라믹·지르코니아·인레이 보철 (정회원 자격 진료)',
      '치아교정 (김준헌 병원장님 1:1 책임 진료)',
      '정기검진·건강보험 스케일링 (3인 원장단 협진)',
    ];
    const memoVal = prefillMemo || `[화타 스마일 PASS: ${code}] 진료 예약 신청`;
    body.innerHTML = `
      <div class="msg">
        <b>🏥 강남역 화이트스타일치과의원 · 3인 원장단 진료 예약</b><br>
        <small style="color:#f6ad93">🎫 <b>[화타 스마일 PASS: ${code}]</b> 보철 또는 임플란트 1개 이상 진료 시 <b>화이트스타일 정회원 등록 & 무료 AI API 로컬 프로토콜</b> 자격이 부여됩니다.</small>
        <div class="card-form">
          <select id="fTreat">${treats.map((t) => `<option value="${t}"${t === prefillTreat ? ' selected' : ''}>${t}</option>`).join('')}</select>
          <input type="date" id="fDate" value="${defDate}">
          <input type="text" id="fName" placeholder="예약자 성함">
          <input type="tel" id="fPhone" placeholder="연락처 (010-0000-0000)">
          <input type="text" id="fMemo" value="${memoVal}">
          <button class="act-btn" id="fSubmit">🐶 화이트스타일치과의원 진료 예약 접수</button>
        </div>
      </div>
    `;
    body.querySelector('#fSubmit').addEventListener('click', () => {
      const name = (body.querySelector('#fName').value || '예비환자').trim().replace(/님+$/, '');
      const phone = (body.querySelector('#fPhone').value || '').trim();
      const treat = body.querySelector('#fTreat').value;
      const date = body.querySelector('#fDate').value;
      const memo = body.querySelector('#fMemo').value;
      if (!phone) {
        body.querySelector('#fPhone').focus();
        return;
      }
      const leadPayload = {
        channel: '화타펫 브라우저 익스텐션',
        name,
        phone,
        treat,
        date,
        memo,
        code,
        timestamp: new Date().toISOString(),
      };
      try {
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
          chrome.storage.local.get(['hwata_leads'], (res) => {
            const list = res.hwata_leads || [];
            list.push(leadPayload);
            chrome.storage.local.set({ hwata_leads: list });
          });
        }
      } catch (e) {}
      fetch('https://whinish.com/api/lead-notify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          phone,
          typeLabel: '화타펫 브라우저 익스텐션 바로 예약',
          subject: `[화타펫 익스텐션 예약] ${treat}`,
          content: `희망일: ${date} / PASS: ${code} / 메모: ${memo}`,
        }),
      }).catch(() => {});
      fetch('http://127.0.0.1:47821/api/lead', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(leadPayload),
      }).catch(() => {});
      body.innerHTML = `<div class="msg">🎉 <b>${name}님 예약 접수 완료!</b><br>• 진료: ${treat}<br>• PASS 번호: <b>${code}</b><br>• 위치: 강남역 11·12번 출구 도보 1분 대승빌딩 (1577-7287)<br><a href="https://booking.naver.com/booking/13/bizes/265482" target="_blank" style="color:#f6ad93;font-weight:700;">[네이버 예약 바로가기]</a> · <a href="https://pf.kakao.com/_Vtxdwl" target="_blank" style="color:#f6ad93;font-weight:700;">[카톡 상담]</a></div>`;
    });
  }

  function showScaling() {
    body.innerHTML = `
      <div class="msg">
        <b>⏳ 올해 '건강보험 스케일링(연 1회)' 확인 & 1분 예약</b><br>
        "만 19세 이상 누구나 연 1회 건강보험 적용 스케일링을 받으실 수 있어요! 구강검진과 함께 보철·임플란트 상담도 받아보세요 멍!" 🐶🦷
        <div class="card-form">
          <button class="opt-btn" data-sc="점심시간">① 아직 안 받았어요 → 강남역 점심시간 검진·스케일링 예약</button>
          <button class="opt-btn" data-sc="퇴근길">② 아직 안 받았어요 → 강남역 퇴근길 검진·스케일링 예약</button>
          <button class="opt-btn" data-sc="done">③ 올해 이미 받았어요 (+3점 적립)</button>
        </div>
      </div>
    `;
    body.querySelectorAll('.opt-btn').forEach((b) => {
      b.addEventListener('click', () => {
        updateScore(3);
        if (b.dataset.sc === 'done') {
          body.innerHTML = `<div class="msg">🎉 <b>스케일링 완료 인증! (+3점 · 현재 ${score}/10점)</b></div>`;
        } else {
          showBooking('정기검진·건강보험 스케일링 (3인 원장단 협진)', `[올해 건강보험 스케일링(${b.dataset.sc}) 신청] 화타 스마일 PASS(${ensurePass(true)})`);
        }
      });
    });
  }

  function showSelfCheck() {
    body.innerHTML = `
      <div class="msg">
        <b>🔍 내 치아 고민 30초 자가 체크 → 맞춤 주치의 매칭</b>
        <div class="card-form">
          <button class="opt-btn" data-tr="정기검진·건강보험 스케일링 (3인 원장단 협진)" data-doc="김준헌 병원장님 총괄 · 박선혜 치주과 전문의 원장님 · 이봉진 대표원장님 협진">① 찬물에 이가 시려요</button>
          <button class="opt-btn" data-tr="임플란트 (정회원 자격 진료 · 3D CT·3단계 저통마취)" data-doc="김준헌 병원장님 · 이봉진 대표원장님 · 박선혜 치주과 전문의 원장님 3D CT·저통마취 협진">② 어금니 임플란트가 필요해요</button>
          <button class="opt-btn" data-tr="최소삭제 심미보철·라미네이트 (정회원 자격 진료 · 1:1 맞춤 디자인)" data-doc="김준헌 병원장님 · 이봉진 대표원장님 최소삭제 심미보철 맞춤 설계">③ 앞니 심미보철·라미네이트가 궁금해요</button>
          <button class="opt-btn" data-tr="치아교정 (김준헌 병원장님 1:1 책임 진료)" data-doc="서울대 치과교정학 박사 김준헌 병원장님 1:1 책임 교정">④ 치아교정 기간이 궁금해요</button>
        </div>
      </div>
    `;
    body.querySelectorAll('.opt-btn').forEach((b) => {
      b.addEventListener('click', () => {
        updateScore(3);
        const code = ensurePass(true);
        showBooking(b.dataset.tr, `[30초 자가체크 매칭: ${b.dataset.doc}] 화타 스마일 PASS(${code})`);
      });
    });
  }

  function showQuiz() {
    body.innerHTML = `
      <div class="msg">
        <b>✨ 하야니의 치아건강 & 멤버십 상식 퀴즈 (+3점)</b><br>
        화이트스타일치과의원의 무료 AI API 로컬 프로토콜을 내 컴퓨터에 끌어다 쓸 수 있는 <b>정회원 등록 조건</b>은?
        <div class="card-form">
          <button class="opt-btn">① 화이트스타일치과의원에서 최소 보철 치료 또는 임플란트 1개 이상 진료 후 정회원 등록</button>
          <button class="opt-btn">② 아무 조건 없이 비회원으로 사용</button>
        </div>
      </div>
    `;
    body.querySelectorAll('.opt-btn').forEach((b) => {
      b.addEventListener('click', () => {
        updateScore(3);
        body.innerHTML = `<div class="msg">🎉 <b>정답이야 멍! (+3점 · 현재 ${score}/10점)</b><br><b>화타 스마일 PASS</b>에 등록하시면 AI 펫 하야니의 모든 기능을 이용하실 수 있고, 화이트스타일치과의원에서 <b>최소 보철 치료 또는 임플란트 1개 이상 진료</b>를 받으신 정회원께는 내 컴퓨터에 끌어다 쓸 수 있는 <b>무료 AI API 프로토콜</b>이 제공됩니다!</div>`;
      });
    });
  }

  function togglePanel() {
    panel.classList.toggle('open');
    if (panel.classList.contains('open') && !body.innerHTML) {
      showFreeApiProtocol();
    }
  }

  shadow.getElementById('hwStage').addEventListener('click', (e) => {
    if (e.target.id === 'hwHideBtn') return;
    togglePanel();
  });
  bubble.addEventListener('click', togglePanel);
  shadow.getElementById('hwClosePanel').addEventListener('click', () => panel.classList.remove('open'));
  shadow.getElementById('hwHideBtn').addEventListener('click', (e) => {
    e.stopPropagation();
    host.style.display = 'none';
  });

  shadow.querySelectorAll('.p-chip').forEach((c) => {
    c.addEventListener('click', () => {
      const act = c.dataset.act;
      if (act === 'pass') showPassRegister();
      else if (act === 'freeapi') showFreeApiProtocol();
      else if (act === 'booking') showBooking();
      else if (act === 'scaling') showScaling();
      else if (act === 'selfcheck') showSelfCheck();
      else if (act === 'quiz') showQuiz();
      else if (act === 'care') {
        mode = 'brush';
        setTimeout(() => (mode = 'idle'), 4000);
        updateScore(3);
        body.innerHTML = `<div class="msg">🪥 <b>치카치카 2분 양치 스탬프 +3점 적립 완료! (현재 ${score}/10점)</b><br>PASS에 등록하시면 하야니의 모든 3D 동물 변신과 코스튬 기능을 이용하실 수 있어요!</div>`;
      }
    });
  });
})();
