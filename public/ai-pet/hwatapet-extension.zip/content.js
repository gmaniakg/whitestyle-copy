// 화타펫 (HwataPet) v3.1.0 — 브라우저 우측 하단 플로팅 3D 펫 아바타 & 친구 단톡방
(() => {
  if (window.__hwata3DFloatingLoaded || window.top !== window.self) return;
  window.__hwata3DFloatingLoaded = true;

  const API_BASE = 'https://whitestyle.com/api/ai-pet';

  function escapeHtml(str) {
    return String(str == null ? '' : str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function assetUrl(file) {
    try {
      return chrome.runtime.getURL('assets3d/' + file);
    } catch {
      return '';
    }
  }

  function proxyFetch(url, method = 'GET', body = undefined) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(
          { type: 'HWATA_API_REQUEST', url, method, body },
          (resp) => {
            if (chrome.runtime.lastError || !resp) {
              resolve({ ok: false, data: null });
              return;
            }
            resolve(resp);
          }
        );
      } catch {
        resolve({ ok: false, data: null });
      }
    });
  }

  const VALID_SPECIES = ['dog', 'cat', 'elephant', 'dino', 'parrot', 'python'];
  const VALID_EARS = [
    'perk', 'fold', 'round', 'pointy', 'small', 'fox', 'lynx',
    'mismatch', 'outtilt', 'intilt', 'darktip', 'whitetip', 'tnr',
  ];
  const VALID_COSTUMES = ['none', 'doctor', 'crown', 'angel', 'beret', 'coder', 'hygiene'];
  const BG_HEX = {
    cream: '#faf3e3',
    mint: '#dff3ee',
    peach: '#fce5dc',
    sky: '#e1f0fa',
    lavender: '#ece6fa',
    gold: '#f9e498',
  };

  function sanitizeAvatar(raw) {
    const o = raw && typeof raw === 'object' ? raw : {};
    return {
      species: VALID_SPECIES.includes(o.species) ? o.species : 'dog',
      ear: VALID_EARS.includes(o.ear) ? o.ear : 'perk',
      costume: VALID_COSTUMES.includes(o.costume) ? o.costume : 'none',
      bg: BG_HEX[o.bg] ? o.bg : 'cream',
    };
  }

  function buildAvatarLayersHtml(cfg) {
    const a = sanitizeAvatar(cfg);
    if (a.species === 'dog' && a.costume === 'none') {
      return (
        `<img src="${assetUrl('hwata_3d_idle.png')}" class="av-layer" alt="">` +
        `<img src="${assetUrl('hwata_3d_ear_' + a.ear + '.png')}" class="av-layer" alt="">`
      );
    }
    if (a.species === 'dog' && a.costume !== 'none') {
      return `<img src="${assetUrl('hwata_3d_costume_' + a.costume + '.png')}" class="av-layer" alt="">`;
    }
    return `<img src="${assetUrl('hwata_3d_species_' + a.species + '.png')}" class="av-layer" alt="">`;
  }

  const host = document.createElement('div');
  host.id = 'hwatapet-3d-root';
  host.style.cssText =
    'position:fixed;right:18px;bottom:18px;z-index:2147483646;pointer-events:none;font-family:Pretendard,"Malgun Gothic",system-ui,sans-serif;';
  const shadow = host.attachShadow({ mode: 'open' });

  shadow.innerHTML = `
    <style>
      * { box-sizing: border-box; word-break: keep-all; overflow-wrap: break-word; }
      .wrap { position: relative; display: flex; flex-direction: column; align-items: flex-end; pointer-events: none; }
      .panel {
        pointer-events: auto; width: 348px; max-height: 480px; margin-bottom: 10px;
        background: #1e1814; color: #f4e9df; border: 2px solid #5a463a; border-radius: 16px;
        box-shadow: 0 14px 36px rgba(0,0,0,0.45); display: none; flex-direction: column; overflow: hidden;
        font-size: 12.5px; line-height: 1.45;
      }
      .panel.open { display: flex; }
      .p-head {
        padding: 10px 12px; background: #2b211a; border-bottom: 1px solid #5a463a;
        display: flex; justify-content: space-between; align-items: center; gap: 6px;
      }
      .p-title b { font-size: 13px; color: #fffaf3; display: block; }
      .p-title span { font-size: 10.5px; color: #34d399; font-weight: 700; }
      .p-close { background: none; border: 0; color: #b49c8d; font-size: 18px; cursor: pointer; padding: 2px 6px; }
      .p-toolbar {
        padding: 7px 10px; background: #241c17; border-bottom: 1px solid #4a3b32;
        display: flex; gap: 6px; align-items: center;
      }
      .p-toolbar select {
        flex: 1; min-width: 0; padding: 5px 7px; border-radius: 7px;
        border: 1px solid #5a463a; background: #181412; color: #f4e9df; font-size: 11.5px; font-weight: 700;
      }
      .p-inv-btn {
        background: #34d399; color: #111827; border: 0; border-radius: 7px;
        padding: 5px 9px; font-size: 11px; font-weight: 800; cursor: pointer; white-space: nowrap;
      }
      .p-feed {
        flex: 1; min-height: 220px; max-height: 280px; overflow-y: auto;
        padding: 10px; display: flex; flex-direction: column; gap: 8px; background: #181412;
      }
      .c-row { display: flex; align-items: flex-start; gap: 7px; }
      .c-row.me { flex-direction: row-reverse; }
      .c-col { display: flex; flex-direction: column; gap: 2px; max-width: 78%; }
      .c-row.me .c-col { align-items: flex-end; }
      .c-sender { font-size: 10px; font-weight: 700; color: #b8a396; }
      .c-bubble {
        padding: 7px 10px; border-radius: 10px; font-size: 11.5px; line-height: 1.45;
        background: #2b211c; border: 1px solid #5a463a; color: #f4e9df;
      }
      .c-row.me .c-bubble { background: #17362b; border-color: #34d399; }
      .c-row.bot .c-bubble { background: #332614; border-color: #f59e0b; color: #fde68a; }
      .av-circle {
        position: relative; width: 32px; height: 32px; border-radius: 50%;
        border: 1.5px solid #5a463a; overflow: hidden; flex-shrink: 0;
      }
      .av-circle.bot { border-color: #f59e0b; }
      .av-layer { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: contain; pointer-events: none; }
      .p-send-bar {
        padding: 8px 10px; background: #241c17; border-top: 1px solid #4a3b32;
        display: flex; gap: 6px;
      }
      .p-send-bar input {
        flex: 1; padding: 6px 9px; border-radius: 7px; border: 1px solid #5a463a;
        background: #181412; color: #f4e9df; font-size: 12px;
      }
      .p-send-bar button {
        padding: 6px 12px; border-radius: 7px; border: 0;
        background: #d97757; color: #fff; font-size: 11.5px; font-weight: 800; cursor: pointer;
      }
      .p-send-bar input:disabled, .p-send-bar button:disabled { opacity: 0.45; cursor: not-allowed; }
      .auth-gate-card {
        margin: auto 4px; padding: 16px 14px; border-radius: 12px; background: #261d17;
        border: 1px solid #d97757; text-align: center; display: flex; flex-direction: column; gap: 10px;
      }
      .auth-gate-card b { font-size: 13px; color: #fffaf3; line-height: 1.4; }
      .auth-gate-card p { margin: 0; font-size: 11.5px; color: #d6c3b6; line-height: 1.5; }
      .auth-gate-actions { display: flex; gap: 6px; justify-content: center; flex-wrap: wrap; }
      .auth-gate-btn {
        display: inline-block; padding: 8px 12px; border-radius: 8px; text-decoration: none;
        font-size: 11.5px; font-weight: 800; background: #1b439c; color: #fff;
      }
      .auth-gate-btn.secondary { background: #34d399; color: #111827; }
      .p-foot {
        padding: 6px 10px; background: #17362b; color: #a7f3d0; font-size: 10.5px; font-weight: 700;
        display: flex; justify-content: space-between; align-items: center;
      }
      .p-foot a { color: #fde68a; text-decoration: underline; }
      .pet-btn-wrap { pointer-events: auto; position: relative; display: flex; align-items: center; gap: 8px; }
      .speech-pill {
        background: rgba(24, 20, 18, 0.95); color: #f4e9df; border: 1.5px solid #f59e0b;
        padding: 7px 12px; border-radius: 999px; font-size: 11.5px; font-weight: 700;
        box-shadow: 0 6px 18px rgba(0,0,0,0.35); cursor: pointer; max-width: 260px;
        white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
        transition: opacity 0.25s ease, transform 0.25s ease;
      }
      .speech-pill.hidden { opacity: 0; pointer-events: none; transform: translateY(4px); }
      .pet-stage {
        position: relative; width: 74px; height: 74px; border-radius: 50%;
        border: 2.5px solid #241812; box-shadow: 0 6px 18px rgba(0,0,0,0.38);
        cursor: pointer; overflow: hidden; transition: transform 0.16s ease;
      }
      .pet-stage:hover { transform: scale(1.06); }
      .min-btn {
        position: absolute; top: -4px; right: -4px; width: 20px; height: 20px;
        border-radius: 50%; border: 1px solid #5a463a; background: #29211c; color: #b49c8d;
        font-size: 11px; cursor: pointer; pointer-events: auto;
      }
    </style>
    <div class="wrap">
      <div class="panel" id="hwataPanel">
        <div class="p-head">
          <div class="p-title">
            <b>화타펫 친구 단톡방</b>
            <span>@화타 부르면 33년 치과 임상 즉답</span>
          </div>
          <button class="p-close" id="hwClosePanel" title="닫기">×</button>
        </div>
        <div class="p-toolbar">
          <select id="hwRoomSelect" aria-label="단톡방 선택">
            <option value="room_jaw_stretch">강남 직장인 턱관절 &amp; 이갈이 탈출방</option>
            <option value="room_ortho_talk">치아교정 1~2년차 현실 고민방</option>
            <option value="room_aesthetic_smile">최소삭제 라미네이트 &amp; 미백 솔직방</option>
          </select>
          <button type="button" class="p-inv-btn" id="hwInviteBtn">🔗 초대</button>
        </div>
        <div class="p-feed" id="hwChatFeed"></div>
        <div class="p-send-bar">
          <input type="text" id="hwChatInput" placeholder="메시지 입력 (@화타 즉답)" maxlength="300">
          <button type="button" id="hwSendBtn">전송</button>
        </div>
        <div class="p-foot">
          <span>🎁 친구 5명 초대 시 치아미백 1회 무료</span>
          <a href="https://whitestyle.com/ai-pet" target="_blank" rel="noopener">크게 보기</a>
        </div>
      </div>

      <div class="pet-btn-wrap">
        <div class="speech-pill" id="hwSpeechPill">💬 화타펫 단톡방 열기</div>
        <div style="position:relative;">
          <div class="pet-stage" id="hwPetStage" title="클릭해서 화타펫 친구 단톡방 열기"></div>
          <button type="button" class="min-btn" id="hwHidePillBtn" title="말풍선 숨기기">−</button>
        </div>
      </div>
    </div>
  `;

  document.documentElement.appendChild(host);

  const panel = shadow.getElementById('hwataPanel');
  const closeBtn = shadow.getElementById('hwClosePanel');
  const petStage = shadow.getElementById('hwPetStage');
  const speechPill = shadow.getElementById('hwSpeechPill');
  const hidePillBtn = shadow.getElementById('hwHidePillBtn');
  const roomSelect = shadow.getElementById('hwRoomSelect');
  const inviteBtn = shadow.getElementById('hwInviteBtn');
  const chatFeed = shadow.getElementById('hwChatFeed');
  const chatInput = shadow.getElementById('hwChatInput');
  const sendBtn = shadow.getElementById('hwSendBtn');

  let myAvatar = { species: 'dog', ear: 'perk', costume: 'none', bg: 'cream' };
  let nickname = '화타_' + Math.floor(Math.random() * 900 + 100);
  let chartNo = '';
  let isCracked = false;
  let currentRoomId = 'room_jaw_stretch';
  let joinedRooms = [];
  let guestId = 'ext_' + Date.now().toString(36);
  let hwataAuthToken = '';
  let hwataAuthUser = null;
  let hwataPollTimer = null;
  let lastSeenMsgId = '';
  let lastSig = '';
  let pillTimer = null;

  function renderPetStage() {
    if (!petStage) return;
    const a = sanitizeAvatar(myAvatar);
    petStage.style.backgroundColor = BG_HEX[a.bg] || BG_HEX.cream;
    petStage.innerHTML = buildAvatarLayersHtml(a);
  }

  function showSpeechPill(text) {
    if (!speechPill) return;
    speechPill.textContent = text;
    speechPill.classList.remove('hidden');
    if (pillTimer) clearTimeout(pillTimer);
    pillTimer = setTimeout(() => {
      if (!panel.classList.contains('open')) {
        speechPill.classList.add('hidden');
      }
    }, 6500);
  }

  function stopAuthenticatedPolling() {
    if (hwataPollTimer) {
      clearInterval(hwataPollTimer);
      hwataPollTimer = null;
    }
  }

  function renderLoginGate() {
    stopAuthenticatedPolling();
    if (chatInput) {
      chatInput.disabled = true;
      chatInput.placeholder = 'whitestyle.com 로그인 후 채팅 가능';
    }
    if (sendBtn) sendBtn.disabled = true;
    if (roomSelect) roomSelect.disabled = true;
    if (inviteBtn) inviteBtn.disabled = true;
    if (!chatFeed) return;
    chatFeed.innerHTML = `
      <div class="auth-gate-card">
        <b>whitestyle.com 회원 로그인 후<br>실시간 화타펫 단톡방 이용 가능</b>
        <p>로그인하시면 33년 임상 @화타 즉답, 단톡방 실시간 대화 및 1초 차트 크랙 기능이 바로 열립니다.</p>
        <div class="auth-gate-actions">
          <a class="auth-gate-btn" href="https://whitestyle.com/login?callbackUrl=%2Fai-pet%23community" target="_blank" rel="noopener">로그인하기</a>
          <a class="auth-gate-btn secondary" href="https://whitestyle.com/register?callbackUrl=%2Fai-pet%23community" target="_blank" rel="noopener">회원가입</a>
        </div>
      </div>
    `;
  }

  function startAuthenticatedPolling() {
    if (!hwataAuthToken) {
      renderLoginGate();
      return;
    }
    if (chatInput) {
      chatInput.disabled = false;
      chatInput.placeholder = '메시지 입력 (@화타 즉답)';
    }
    if (sendBtn) sendBtn.disabled = false;
    if (roomSelect) roomSelect.disabled = false;
    if (inviteBtn) inviteBtn.disabled = false;
    lastSig = '';
    if (!hwataPollTimer) {
      hwataPollTimer = setInterval(() => {
        if (hwataAuthToken) loadMessages(false);
      }, 4000);
    }
    if (panel.classList.contains('open')) {
      loadRooms();
      loadMessages(true);
    }
  }

  async function syncSessionFromWhitestyleHost() {
    const h = window.location.hostname;
    if (h !== 'whitestyle.com' && h !== 'www.whitestyle.com') return;
    try {
      const res = await fetch('/api/ai-pet/session', { credentials: 'include', cache: 'no-store' });
      if (!res.ok) return;
      const data = await res.json();
      if (data?.ok && data.authenticated && data.token) {
        hwataAuthToken = String(data.token);
        hwataAuthUser = data.user || null;
        if (hwataAuthUser?.name && nickname.startsWith('화타_')) {
          nickname = String(hwataAuthUser.name).slice(0, 20);
        }
        try {
          chrome.storage.local.set({
            hwata_auth_token: hwataAuthToken,
            hwata_auth_user: hwataAuthUser,
            hwata_user_nickname: nickname,
          });
        } catch {}
        startAuthenticatedPolling();
      } else if (data?.ok && !data.authenticated) {
        hwataAuthToken = '';
        hwataAuthUser = null;
        try {
          chrome.storage.local.remove(['hwata_auth_token', 'hwata_auth_user']);
        } catch {}
        renderLoginGate();
      }
    } catch {}
  }

  function loadStorageState() {
    try {
      chrome.storage.local.get(
        [
          'hwata_avatar_v1',
          'hwata_user_nickname',
          'hwata_chart_no',
          'hwata_cracked',
          'hwata_current_room',
          'hwata_joined_rooms',
          'hwata_guest_id',
          'hwata_auth_token',
          'hwata_auth_user',
        ],
        (res) => {
          if (res?.hwata_avatar_v1) {
            myAvatar = sanitizeAvatar(
              typeof res.hwata_avatar_v1 === 'string' ? JSON.parse(res.hwata_avatar_v1) : res.hwata_avatar_v1
            );
          }
          if (res?.hwata_user_nickname) nickname = String(res.hwata_user_nickname);
          if (res?.hwata_chart_no) chartNo = String(res.hwata_chart_no);
          if (res?.hwata_cracked === true || res?.hwata_cracked === 'true') isCracked = true;
          if (res?.hwata_current_room) currentRoomId = String(res.hwata_current_room);
          if (Array.isArray(res?.hwata_joined_rooms)) joinedRooms = res.hwata_joined_rooms;
          if (res?.hwata_guest_id) guestId = String(res.hwata_guest_id);
          if (res?.hwata_auth_user) {
            try {
              hwataAuthUser = typeof res.hwata_auth_user === 'string' ? JSON.parse(res.hwata_auth_user) : res.hwata_auth_user;
            } catch {
              hwataAuthUser = null;
            }
          }
          if (hwataAuthUser?.name && nickname.startsWith('화타_')) {
            nickname = String(hwataAuthUser.name).slice(0, 20);
          }
          if (typeof res?.hwata_auth_token === 'string' && res.hwata_auth_token) {
            hwataAuthToken = res.hwata_auth_token;
          }
          renderPetStage();
          if (hwataAuthToken) {
            startAuthenticatedPolling();
          } else {
            renderLoginGate();
          }
        }
      );
    } catch {
      renderPetStage();
      renderLoginGate();
    }
  }

  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local') return;
      if (changes.hwata_avatar_v1) {
        const nv = changes.hwata_avatar_v1.newValue;
        myAvatar = sanitizeAvatar(typeof nv === 'string' ? JSON.parse(nv) : nv);
        renderPetStage();
      }
      if (changes.hwata_user_nickname?.newValue) {
        nickname = String(changes.hwata_user_nickname.newValue);
      }
      if (changes.hwata_chart_no?.newValue !== undefined) {
        chartNo = String(changes.hwata_chart_no.newValue || '');
      }
      if (changes.hwata_cracked?.newValue !== undefined) {
        isCracked = changes.hwata_cracked.newValue === true || changes.hwata_cracked.newValue === 'true';
      }
      if (changes.hwata_auth_user) {
        const nu = changes.hwata_auth_user.newValue;
        try {
          hwataAuthUser = typeof nu === 'string' ? JSON.parse(nu) : nu || null;
        } catch {
          hwataAuthUser = null;
        }
        if (hwataAuthUser?.name && nickname.startsWith('화타_')) {
          nickname = String(hwataAuthUser.name).slice(0, 20);
        }
      }
      if (changes.hwata_auth_token) {
        hwataAuthToken = typeof changes.hwata_auth_token.newValue === 'string' ? changes.hwata_auth_token.newValue : '';
        if (hwataAuthToken) {
          startAuthenticatedPolling();
        } else {
          renderLoginGate();
        }
      }
      if (changes.hwata_current_room?.newValue) {
        currentRoomId = String(changes.hwata_current_room.newValue);
        lastSig = '';
        if (hwataAuthToken && panel.classList.contains('open')) loadMessages(true);
      }
    });
  } catch {}

  async function loadRooms() {
    if (!hwataAuthToken) return;
    const ids = Array.from(new Set([currentRoomId, ...joinedRooms])).filter(Boolean);
    const resp = await proxyFetch(`${API_BASE}/room?action=list&roomIds=${encodeURIComponent(ids.join(','))}`);
    if (resp.status === 401) {
      hwataAuthToken = '';
      renderLoginGate();
      return;
    }
    if (resp.ok && resp.data?.ok && Array.isArray(resp.data.rooms) && roomSelect) {
      roomSelect.innerHTML = '';
      resp.data.rooms.forEach((r) => {
        const opt = document.createElement('option');
        opt.value = r.roomId;
        opt.textContent = (r.isPublic === false ? '🔒 ' : '') + r.roomName;
        if (r.roomId === currentRoomId) opt.selected = true;
        roomSelect.appendChild(opt);
      });
    }
  }

  async function loadMessages(forceScroll = false) {
    if (!hwataAuthToken) return;
    const resp = await proxyFetch(`${API_BASE}/room?action=messages&roomId=${encodeURIComponent(currentRoomId)}`);
    if (resp.status === 401) {
      hwataAuthToken = '';
      renderLoginGate();
      return;
    }
    if (!resp.ok || !resp.data?.ok || !Array.isArray(resp.data.messages)) return;

    const msgs = resp.data.messages;
    const last = msgs.length ? msgs[msgs.length - 1] : null;
    if (last && last.id !== lastSeenMsgId) {
      if (lastSeenMsgId && !panel.classList.contains('open') && last.sender !== nickname) {
        showSpeechPill(`💬 ${last.sender}: ${last.text}`);
      }
      lastSeenMsgId = last.id;
    }

    const sig = `${currentRoomId}:${msgs.length}:${last ? last.id : 'empty'}`;
    if (sig === lastSig && !forceScroll) return;
    lastSig = sig;

    chatFeed.innerHTML = '';
    msgs.forEach((m) => {
      const isBot = Boolean(m.isBot);
      const isMe = !isBot && m.sender === nickname;
      const row = document.createElement('div');
      row.className = `c-row ${isBot ? 'bot' : isMe ? 'me' : 'other'}`;

      const av = sanitizeAvatar(
        m.avatar || { species: 'dog', ear: 'perk', costume: isBot ? 'doctor' : 'none', bg: isBot ? 'gold' : 'cream' }
      );
      const avDiv = document.createElement('div');
      avDiv.className = `av-circle${isBot ? ' bot' : ''}`;
      avDiv.style.backgroundColor = BG_HEX[av.bg] || BG_HEX.cream;
      avDiv.innerHTML = buildAvatarLayersHtml(av);
      row.appendChild(avDiv);

      const col = document.createElement('div');
      col.className = 'c-col';

      const sDiv = document.createElement('div');
      sDiv.className = 'c-sender';
      sDiv.textContent = (m.sender || '익명') + (m.isCracked && !isBot ? ' 👑' : '');

      const bDiv = document.createElement('div');
      bDiv.className = 'c-bubble';
      bDiv.innerHTML = escapeHtml(m.text).replace(/\n/g, '<br>');

      col.appendChild(sDiv);
      col.appendChild(bDiv);
      row.appendChild(col);
      chatFeed.appendChild(row);
    });
    chatFeed.scrollTop = chatFeed.scrollHeight;
  }

  async function sendMessage() {
    if (!hwataAuthToken) {
      renderLoginGate();
      return;
    }
    const text = chatInput.value.trim();
    if (!text) return;
    chatInput.value = '';
    sendBtn.disabled = true;
    try {
      const resp = await proxyFetch(`${API_BASE}/room`, 'POST', {
        action: 'send',
        roomId: currentRoomId,
        sender: nickname,
        text,
        chartNo: chartNo || null,
        isCracked,
        avatar: myAvatar,
      });
      if (resp.status === 401) {
        hwataAuthToken = '';
        renderLoginGate();
        return;
      }
      if (resp.ok && resp.data?.ok) {
        lastSig = '';
        await loadMessages(true);
      }
    } finally {
      if (hwataAuthToken) {
        sendBtn.disabled = false;
        chatInput.focus();
      }
    }
  }

  function togglePanel(forceOpen) {
    const next = typeof forceOpen === 'boolean' ? forceOpen : !panel.classList.contains('open');
    panel.classList.toggle('open', next);
    if (next) {
      speechPill.classList.add('hidden');
      if (hwataAuthToken) {
        loadRooms();
        loadMessages(true);
      } else {
        renderLoginGate();
      }
    }
  }

  petStage.addEventListener('click', () => togglePanel());
  speechPill.addEventListener('click', () => togglePanel(true));
  closeBtn.addEventListener('click', () => togglePanel(false));
  hidePillBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    speechPill.classList.add('hidden');
  });

  roomSelect.addEventListener('change', () => {
    currentRoomId = roomSelect.value;
    try {
      chrome.storage.local.set({ hwata_current_room: currentRoomId });
    } catch {}
    lastSig = '';
    loadMessages(true);
  });

  inviteBtn.addEventListener('click', () => {
    const refCode = chartNo ? `HWATA-${chartNo.toUpperCase()}` : `HWATA-${guestId.slice(-6).toUpperCase()}`;
    const url = `https://whitestyle.com/ai-pet?room=${encodeURIComponent(currentRoomId)}&ref=${encodeURIComponent(refCode)}#community`;
    navigator.clipboard
      ?.writeText(url)
      .then(() => showSpeechPill('🔗 초대 링크 복사 완료! (5명 치아미백)'))
      .catch(() => prompt('단톡방 초대 링크:', url));
  });

  sendBtn.addEventListener('click', sendMessage);
  chatInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      sendMessage();
    }
  });

  syncSessionFromWhitestyleHost();
  loadStorageState();
})();
