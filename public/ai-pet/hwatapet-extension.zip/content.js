// 화타펫 (HwataPet / 하야니) 브라우저 우측 하단 3D 플로팅 반려 펫 (화타 스마일 PASS 전체 기능 잠금 해제 & 교정·보철·미백 등 비급여 치료 정회원 무료 AI API 로컬 프로토콜)
(() => {
  if (window.__hwata3DFloatingLoaded || window.top !== window.self) return;
  window.__hwata3DFloatingLoaded = true;

  const host = document.createElement('div');
  host.id = 'hwatapet-3d-root';
  host.style.cssText = 'position:fixed;right:18px;bottom:18px;z-index:2147483646;pointer-events:none;font-family:Pretendard,"Malgun Gothic",system-ui,sans-serif;';
  const shadow = host.attachShadow({ mode: 'open' });

  const getAsset = (name) => {
    try {
      return chrome.runtime.getURL('assets3d/hwata_3d_' + name + '.png');
    } catch {
      return '';
    }
  };

  shadow.innerHTML = `
    <style>
      * { box-sizing: border-box; word-break: keep-all; overflow-wrap: break-word; }
      .wrap { position: relative; display: flex; flex-direction: column; align-items: flex-end; pointer-events: none; }
      .panel {
        pointer-events: auto; width: 364px; max-height: 540px; margin-bottom: 8px;
        background: #1e1814; color: #f4e9df; border: 1px solid #5a463a; border-radius: 16px;
        box-shadow: 0 14px 36px rgba(0,0,0,0.45); display: none; flex-direction: column; overflow: hidden;
        font-size: 12.5px; line-height: 1.5;
      }
      .panel.open { display: flex; }
      .p-head {
        padding: 10px 12px; background: linear-gradient(180deg, #33261e, #1e1814);
        border-bottom: 1px solid #5a463a; display: flex; justify-content: space-between; align-items: center;
      }
      .p-title b { font-size: 13.5px; color: #fffaf3; }
      .p-title span { display: block; font-size: 10.5px; color: #f6ad93; font-weight: 700; }
      .p-close { background: none; border: 0; color: #b49c8d; font-size: 16px; cursor: pointer; padding: 2px 6px; }
      .p-chips {
        display: flex; flex-wrap: wrap; gap: 4px; padding: 6px 10px; border-bottom: 1px solid rgba(90,70,58,0.4);
      }
      .p-chip {
        flex: none; padding: 4px 8px; border-radius: 999px; border: 1px dashed #5a463a;
        background: #29211c; color: #f4e9df; font-size: 11px; font-weight: 600; cursor: pointer;
      }
      .p-chip:hover { border-color: #d97757; background: #362a23; }
      .p-body { padding: 10px 12px; overflow-y: auto; max-height: 360px; display: flex; flex-direction: column; gap: 8px; }
      .msg { padding: 9px 11px; border-radius: 10px; background: #29211c; border: 1px solid #5a463a; }
      .card-form { display: grid; gap: 5px; margin-top: 6px; }
      .card-form input, .card-form select {
        width: 100%; padding: 6px 7px; border-radius: 6px; border: 1px solid #5a463a;
        background: #1e1814; color: #f4e9df; font: inherit; font-size: 11.5px;
      }
      .act-btn {
        width: 100%; padding: 7px 10px; border-radius: 8px; border: 0;
        background: #d97757; color: #fffaf3; font-weight: 700; font-size: 12px; cursor: pointer;
      }
      .opt-btn {
        text-align: left; padding: 6px 8px; border-radius: 7px; border: 1px solid #5a463a;
        background: #1e1814; color: #f4e9df; font-size: 11.5px; cursor: pointer;
      }
      .opt-btn:hover { border-color: #d97757; }
      .pet-btn-wrap { pointer-events: auto; position: relative; display: flex; align-items: center; gap: 6px; }
      .speech-pill {
        background: rgba(30, 24, 20, 0.94); color: #f4e9df; border: 1px solid #5a463a;
        padding: 6px 11px; border-radius: 999px; font-size: 11.5px; font-weight: 600;
        box-shadow: 0 6px 18px rgba(0,0,0,0.32); cursor: pointer; max-width: 320px;
        transition: opacity 0.35s ease, transform 0.35s ease;
      }
      .speech-pill.auto-hide { opacity: 0; pointer-events: none; transform: translateY(4px); }
      .pet-btn-wrap:hover .speech-pill.auto-hide { opacity: 1; pointer-events: auto; transform: translateY(0); }
      .speech-pill b { color: #f6ad93; }
      .pet-stage {
        width: 84px; height: 84px; cursor: pointer; position: relative;
        filter: drop-shadow(0 6px 14px rgba(0,0,0,0.35)); transition: transform 0.2s ease, width 0.2s ease, height 0.2s ease;
      }
      .pet-stage.mini { width: 46px; height: 46px; opacity: 0.82; }
      .pet-stage.mini canvas { width: 46px; height: 46px; }
      .pet-stage.mini:hover { opacity: 1; }
      .pet-stage:hover { transform: scale(1.06); }
      canvas { width: 84px; height: 84px; display: block; transition: width 0.2s ease, height 0.2s ease; }
      .min-btn {
        position: absolute; top: -2px; right: -2px; width: 20px; height: 20px;
        border-radius: 50%; border: 1px solid #5a463a; background: #29211c; color: #b49c8d;
        font-size: 11px; line-height: 1; cursor: pointer; display: flex; align-items: center; justify-content: center;
      }
      .code-box {
        background: #14100d; border: 1px solid #5a463a; border-radius: 6px; padding: 6px 8px;
        font-family: ui-monospace, monospace; font-size: 10.5px; color: #6ee7b7; word-break: break-all; margin-top: 4px;
      }
    </style>
    <div class="wrap">
      <div class="panel" id="hwataPanel">
        <div class="p-head">
          <div class="p-title">
            <b id="hwPanelTitle">🐶 하야니 (화타펫) 3D · 화이트스타일치과의원</b>
            <span id="hwScoreTxt">🔓 PASS 등록 시 하야니 전체 기능 잠금 해제 · 정회원 무료 AI API</span>
          </div>
          <button class="p-close" id="hwClosePanel" title="닫기">×</button>
        </div>
        <div class="p-chips">
          <button class="p-chip" data-act="pass">🔓 PASS 등록</button>
          <button class="p-chip" data-act="species">🐾 6종 동물 변신</button>
          <button class="p-chip" data-act="display">⚙️ 설정·파트너</button>
          <button class="p-chip" data-act="freeapi">⚡ 무료 AI API</button>
          <button class="p-chip" data-act="booking">♥ 진료 예약</button>
          <button class="p-chip" data-act="scaling">⏳ 건보 스케일링</button>
          <button class="p-chip" data-act="selfcheck">🔍 30초 자가체크</button>
          <button class="p-chip" data-act="care">🪥 2분 양치타이머</button>
          <button class="p-chip" data-act="quiz">✨ 치아퀴즈</button>
        </div>
        <div class="p-body" id="hwBody"></div>
      </div>
      <div class="pet-btn-wrap">
        <div class="speech-pill" id="hwBubble">멍! <b>화타 스마일 PASS 등록</b> & <b>정회원 무료 AI API</b> 프로토콜 🐾</div>
        <div class="pet-stage" id="hwStage" title="하야니 3D 클릭해서 PASS 등록 및 무료 AI API 열기">
          <canvas id="hwCanvas" width="168" height="168"></canvas>
          <button class="min-btn" id="hwHideBtn" title="이번 탭에서 숨기기">×</button>
        </div>
      </div>
    </div>
  `;

  document.documentElement.appendChild(host);

  const cv = shadow.getElementById('hwCanvas');
  const ctx = cv.getContext('2d');
  const panel = shadow.getElementById('hwataPanel');
  const body = shadow.getElementById('hwBody');
  const bubble = shadow.getElementById('hwBubble');
  const scoreTxt = shadow.getElementById('hwScoreTxt');

  let score = Number(localStorage.getItem('hwata_ext_score') || 0);
  let vipCode = localStorage.getItem('hwata_ext_vip') || '';
  let mode = 'idle';

  function ensurePass(force = false) {
    if ((!vipCode && score >= 10) || (!vipCode && force)) {
      vipCode = 'HWATA-PASS-' + (1000 + Math.floor(Math.random() * 9000));
      localStorage.setItem('hwata_ext_vip', vipCode);
    }
    return vipCode;
  }

  const poses = {};
  ['idle', 'blink', 'type1', 'type2', 'wave', 'brush'].forEach((k) => {
    const im = new Image();
    im.src = getAsset(k);
    poses[k] = im;
  });

  const SPECIES_LIST = [
    { id: 'dog', name: '강아지 하야니', emoji: '🐶', desc: '1994년 개원 33년 전통 강남역 화이트스타일치과의원 공식 마스코트 강아지 하야니' },
    { id: 'elephant', name: '코끼리 코코', emoji: '🐘', desc: '든든한 어금니 건강 수호신 코끼리 코코' },
    { id: 'dino', name: '공룡 디노', emoji: '🦖', desc: '튼튼한 건치 에너자이저 아기 공룡 디노' },
    { id: 'python', name: '파이톤 파이', emoji: '🐍', desc: '유연한 턱관절 이완 멘토 꼬마 파이톤 파이' },
    { id: 'parrot', name: '앵무새 코코아', emoji: '🦜', desc: '상쾌한 구강 케어 알리미 앵무새 코코아' },
    { id: 'cat', name: '고양이 치즈', emoji: '🐱', desc: '깔끔한 그루밍과 양치 습관 요정 고양이 치즈' },
  ];
  const speciesImgs = {};
  SPECIES_LIST.forEach((sp) => {
    if (sp.id !== 'dog') {
      const im = new Image();
      im.src = getAsset('species_' + sp.id);
      speciesImgs[sp.id] = im;
    }
  });
  let currentSpeciesIdx = Math.max(0, SPECIES_LIST.findIndex((s) => s.id === (localStorage.getItem('hwata_ext_species') || 'dog')));

  function updateScore(add = 0) {
    if (add > 0) {
      score += add;
      localStorage.setItem('hwata_ext_score', String(score));
    }
    scoreTxt.textContent = vipCode
      ? `🔓 PASS 활성화됨 (${vipCode}) · 하야니 모든 기능 잠금 해제 완료`
      : `🔒 PASS 미등록 · PASS에 등록해야 AI 펫(하야니) 모든 기능 이용 가능`;
  }
  updateScore(0);

  function loop() {
    const t = performance.now() / 1000;
    ctx.clearRect(0, 0, 168, 168);
    const blink = (t % 4.1) < 0.14;
    let k = 'idle';
    if (mode === 'wave') k = 'wave';
    else if (mode === 'brush') k = 'brush';
    else if (mode === 'type') k = Math.floor(t * 8) % 2 ? 'type1' : 'type2';
    else if (blink) k = 'blink';
    let im = poses[k] || poses.idle;
    const curSp = SPECIES_LIST[currentSpeciesIdx] || SPECIES_LIST[0];
    if (curSp.id !== 'dog' && speciesImgs[curSp.id] && speciesImgs[curSp.id].complete && speciesImgs[curSp.id].naturalWidth > 0) {
      im = speciesImgs[curSp.id];
    }
    if (im && im.complete && im.naturalWidth > 0) {
      const br = Math.sin(t * 2.9);
      const sx = 1 - br * 0.018;
      const sy = 1 + br * 0.03;
      const dy = mode === 'wave' ? -Math.abs(Math.sin(t * 7)) * 8 : 0;
      ctx.save();
      ctx.translate(84, 154 + dy);
      ctx.scale(sx, sy);
      ctx.drawImage(im, -74, -144, 148, 148);
      ctx.restore();
    }
    requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);

  setInterval(() => {
    mode = 'wave';
    setTimeout(() => (mode = 'idle'), 3000);
    bubble.innerHTML = '😬 집중할 때 무의식중에 꽉 깨문 <b>어금니를 2mm만 살짝 띄워</b> 주세요 멍!';
  }, 50 * 60 * 1000);

  window.addEventListener('message', (ev) => {
    if (ev.data && ev.data.__hwatapet) {
      mode = ev.data.kind === 'prompt' ? 'type' : 'wave';
      setTimeout(() => (mode = 'idle'), 2400);
    }
  });

  function showPassRegister() {
    body.innerHTML = `
      <div class="msg">
        <b>🔓 화타 스마일 PASS 등록 (하야니 전체 기능 잠금 해제)</b><br>
        <small style="color:#f6ad93">PASS에 등록하셔야 AI 펫 '하야니'의 모든 기능(6종 3D 동물 변신 · 6종 3D 코스튬 · 91종 모션 · 7종 페르소나 대화)을 이용하실 수 있습니다.</small>
        <div class="card-form">
          <input type="text" id="pName" placeholder="성함 (예: 홍길동)">
          <input type="tel" id="pPhone" placeholder="연락처 (010-0000-0000)">
          <button class="act-btn" id="pSubmit">🔓 PASS 등록하고 하야니 전체 기능 잠금 해제</button>
        </div>
      </div>
    `;
    body.querySelector('#pSubmit').addEventListener('click', async () => {
      const name = (body.querySelector('#pName').value || '').trim();
      const phone = (body.querySelector('#pPhone').value || '').trim();
      if (!name || !phone) {
        body.querySelector('#pPhone').focus();
        return;
      }
      const code = ensurePass(true);
      updateScore(0);
      fetch('https://whinish.com/api/ai-pet/verify-member', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mode: 'pass', name, phone }),
      }).catch(() => {});
      body.innerHTML = `<div class="msg">🎉 <b>[${code}] PASS 등록 완료!</b><br>이제 AI 펫 '하야니'의 6종 3D 동물 변신, 전체 코스튬, 모든 모션과 기능을 제한 없이 이용하실 수 있습니다!</div>`;
    });
  }

  function showFreeApiProtocol() {
    body.innerHTML = `
      <div class="msg">
        <b>⚡ 화이트스타일 정회원 전용 무료 AI API 로컬 프로토콜</b><br>
        <small style="color:#f6ad93">
          • <b>이용 조건:</b> <b>whitestyle.com</b> 또는 <b>whinish.com</b> 회원 등록 후, <b>강남역 화이트스타일치과의원에 내원하여 교정 보철 미백 등의 비급여 치료</b>를 받으신 분 전용입니다.<br>
          • <b>제공 프로토콜:</b> 전 세계 모든 무료 AI API를 통합 라우팅하여 내 컴퓨터(Cursor, VS Code, Claude Code, Python, Node.js)로 끌어다 쓸 수 있는 OpenAI 호환 프로토콜을 제공합니다.
        </small>
        <div class="card-form">
          <input type="text" id="mId" placeholder="whitestyle.com / whinish.com 회원 ID">
          <input type="text" id="mName" placeholder="환자 성함">
          <input type="tel" id="mPhone" placeholder="환자 연락처 (010-0000-0000)">
          <select id="mTreat">
            <option value="">본원에서 받으신 교정·보철·미백 등 비급여 치료 선택</option>
            <option value="ortho_noninsured">치아교정 (클리피씨 / 인비절라인 / 설측 / 부분교정 등 비급여 치료)</option>
            <option value="prosthodontic_laminate">최소삭제 라미네이트 / 심미보철 (비급여 보철 치료)</option>
            <option value="prosthodontic_ceramic">올세라믹 / 지르코니아 크라운 보철 (비급여 보철 치료)</option>
            <option value="prosthodontic_inlay">세라믹 인레이 / 온레이 보철 (비급여 보철 치료)</option>
            <option value="implant_3dct">3D CT 디지털 임플란트 (비급여 치료)</option>
            <option value="whitening_noninsured">전문가 치아미백 / 심미 미백 프로그램 (비급여 치료)</option>
            <option value="none">아직 비급여 치료 전 (내원 예약 필요)</option>
          </select>
          <input type="text" id="mCode" placeholder="원내 발급 교정·보철·미백 등 비급여 치료 정회원 인증번호 (예: WS-202601)">
          <button class="act-btn" id="mSubmit">⚡ 정회원 인증 & 내 컴퓨터 무료 AI API 프로토콜 발급</button>
        </div>
      </div>
    `;
    body.querySelector('#mSubmit').addEventListener('click', async () => {
      const memberId = (body.querySelector('#mId').value || '').trim();
      const name = (body.querySelector('#mName').value || '').trim();
      const phone = (body.querySelector('#mPhone').value || '').trim();
      const treatmentType = body.querySelector('#mTreat').value;
      const clinicAuthCode = (body.querySelector('#mCode').value || '').trim();
      if (treatmentType === 'none' || !treatmentType) {
        body.innerHTML = `<div class="msg">⚠️ <b>정회원 등록 안내</b><br>정회원 등록 및 무료 AI API 로컬 프로토콜은 <b>강남역 화이트스타일치과의원에 내원하여 교정 보철 미백 등의 비급여 치료</b>를 받으신 분에 한하여 가능합니다.<br><br><button class="act-btn" id="goBookBtn">🏥 교정·보철·미백 등 비급여 진료 예약하러 가기</button></div>`;
        body.querySelector('#goBookBtn')?.addEventListener('click', () => showBooking('최소삭제 심미보철·라미네이트 (김준헌 병원장님 1:1 디자인)', '[정회원 등록 위한 교정·보철·미백 등 비급여 진료 예약]'));
        return;
      }
      try {
        const res = await fetch('https://whinish.com/api/ai-pet/verify-member', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            mode: 'regular_member',
            memberId,
            name,
            phone,
            treatmentType,
            prosthodonticCount: 1,
            clinicAuthCode,
          }),
        });
        const data = await res.json();
        if (!data.ok) {
          body.innerHTML = `<div class="msg">⚠️ <b>인증 실패:</b> ${data.message}</div>`;
          return;
        }
        localStorage.setItem('hwata_vip_api_key', data.apiKey);
        ensurePass(true);
        updateScore(0);
        body.innerHTML = `
          <div class="msg">
            🎉 <b>정회원 인증 완료! 무료 AI API 프로토콜 발급</b>
            <div class="code-box">Base URL: https://whinish.com/api/v1<br>API Key: ${data.apiKey}<br>Model: hwata-omni-free</div>
            <small style="display:block;margin-top:6px;">내 컴퓨터 연동 스크립트 및 전체 프로토콜 가이드는 <a href="https://whinish.com/ai-pet/download.html#api-protocol" target="_blank" style="color:#f6ad93;font-weight:700;">[프로토콜 센터 열기]</a>에서 복사하세요.</small>
          </div>
        `;
      } catch {
        body.innerHTML = `<div class="msg">⚠️ 네트워크 연결을 확인한 뒤 다시 시도해 주세요.</div>`;
      }
    });
  }

  function showBooking(prefillTreat, prefillMemo) {
    mode = 'wave';
    setTimeout(() => (mode = 'idle'), 1500);
    const code = ensurePass(true);
    const d = new Date();
    d.setDate(d.getDate() + 1);
    if (d.getDay() === 0) d.setDate(d.getDate() + 1);
    const defDate = d.toISOString().slice(0, 10);
    const treats = [
      '최소삭제 심미보철·라미네이트 (정회원 자격 진료 · 1:1 맞춤 디자인)',
      '임플란트 (정회원 자격 진료 · 3D CT·3단계 저통마취)',
      '올세라믹·지르코니아·인레이 보철 (정회원 자격 진료)',
      '치아교정 (김준헌 병원장님 1:1 책임 진료)',
      '정기검진·건강보험 스케일링 (3인 원장단 협진)',
    ];
    const memoVal = prefillMemo || `[화타 스마일 PASS: ${code}] 진료 예약 신청`;
    body.innerHTML = `
      <div class="msg">
        <b>🏥 강남역 화이트스타일치과의원 · 3인 원장단 진료 예약</b><br>
        <small style="color:#f6ad93">🎫 <b>[화타 스마일 PASS: ${code}]</b> 교정 보철 미백 등의 비급여 치료 시 <b>화이트스타일 정회원 등록 & 무료 AI API 로컬 프로토콜</b> 자격이 부여됩니다.</small>
        <div class="card-form">
          <select id="fTreat">${treats.map((t) => `<option value="${t}"${t === prefillTreat ? ' selected' : ''}>${t}</option>`).join('')}</select>
          <input type="date" id="fDate" value="${defDate}">
          <input type="text" id="fName" placeholder="예약자 성함">
          <input type="tel" id="fPhone" placeholder="연락처 (010-0000-0000)">
          <input type="text" id="fMemo" value="${memoVal}">
          <button class="act-btn" id="fSubmit">🐶 화이트스타일치과의원 진료 예약 접수</button>
        </div>
      </div>
    `;
    body.querySelector('#fSubmit').addEventListener('click', () => {
      const name = (body.querySelector('#fName').value || '예비환자').trim().replace(/님+$/, '');
      const phone = (body.querySelector('#fPhone').value || '').trim();
      const treat = body.querySelector('#fTreat').value;
      const date = body.querySelector('#fDate').value;
      const memo = body.querySelector('#fMemo').value;
      if (!phone) {
        body.querySelector('#fPhone').focus();
        return;
      }
      const leadPayload = {
        channel: '화타펫 브라우저 익스텐션',
        name,
        phone,
        treat,
        date,
        memo,
        code,
        timestamp: new Date().toISOString(),
      };
      try {
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
          chrome.storage.local.get(['hwata_leads'], (res) => {
            const list = res.hwata_leads || [];
            list.push(leadPayload);
            chrome.storage.local.set({ hwata_leads: list });
          });
        }
      } catch (e) {}
      fetch('https://whinish.com/api/lead-notify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          phone,
          typeLabel: '화타펫 브라우저 익스텐션 바로 예약',
          subject: `[화타펫 익스텐션 예약] ${treat}`,
          content: `희망일: ${date} / PASS: ${code} / 메모: ${memo}`,
        }),
      }).catch(() => {});
      fetch('http://127.0.0.1:47821/api/lead', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(leadPayload),
      }).catch(() => {});
      body.innerHTML = `<div class="msg">🎉 <b>${name}님 예약 접수 완료!</b><br>• 진료: ${treat}<br>• PASS 번호: <b>${code}</b><br>• 위치: 강남역 11·12번 출구 도보 1분 대승빌딩 (1577-7287)<br><a href="https://booking.naver.com/booking/13/bizes/265482" target="_blank" style="color:#f6ad93;font-weight:700;">[네이버 예약 바로가기]</a> · <a href="https://pf.kakao.com/_Vtxdwl" target="_blank" style="color:#f6ad93;font-weight:700;">[카톡 상담]</a></div>`;
    });
  }

  function showScaling() {
    body.innerHTML = `
      <div class="msg">
        <b>⏳ 올해 '건강보험 스케일링(연 1회)' 확인 & 1분 예약</b><br>
        "만 19세 이상 누구나 연 1회 건강보험 적용 스케일링을 받으실 수 있어요! 구강검진과 함께 보철·임플란트 상담도 받아보세요 멍!" 🐶🦷
        <div class="card-form">
          <button class="opt-btn" data-sc="점심시간">① 아직 안 받았어요 → 강남역 점심시간 검진·스케일링 예약</button>
          <button class="opt-btn" data-sc="퇴근길">② 아직 안 받았어요 → 강남역 퇴근길 검진·스케일링 예약</button>
          <button class="opt-btn" data-sc="done">③ 올해 이미 받았어요 (+3점 적립)</button>
        </div>
      </div>
    `;
    body.querySelectorAll('.opt-btn').forEach((b) => {
      b.addEventListener('click', () => {
        updateScore(3);
        if (b.dataset.sc === 'done') {
          body.innerHTML = `<div class="msg">🎉 <b>스케일링 완료 인증! (+3점 · 현재 ${score}/10점)</b></div>`;
        } else {
          showBooking('정기검진·건강보험 스케일링 (3인 원장단 협진)', `[올해 건강보험 스케일링(${b.dataset.sc}) 신청] 화타 스마일 PASS(${ensurePass(true)})`);
        }
      });
    });
  }

  function showSelfCheck() {
    body.innerHTML = `
      <div class="msg">
        <b>🔍 내 치아 고민 30초 자가 체크 → 맞춤 주치의 매칭</b>
        <div class="card-form">
          <button class="opt-btn" data-tr="정기검진·건강보험 스케일링 (3인 원장단 협진)" data-doc="김준헌 병원장님 총괄 · 박선혜 치주과 전문의 원장님 · 이봉진 대표원장님 협진">① 찬물에 이가 시려요</button>
          <button class="opt-btn" data-tr="임플란트 (정회원 자격 진료 · 3D CT·3단계 저통마취)" data-doc="김준헌 병원장님 · 이봉진 대표원장님 · 박선혜 치주과 전문의 원장님 3D CT·저통마취 협진">② 어금니 임플란트가 필요해요</button>
          <button class="opt-btn" data-tr="최소삭제 심미보철·라미네이트 (정회원 자격 진료 · 1:1 맞춤 디자인)" data-doc="김준헌 병원장님 · 이봉진 대표원장님 최소삭제 심미보철 맞춤 설계">③ 앞니 심미보철·라미네이트가 궁금해요</button>
          <button class="opt-btn" data-tr="치아교정 (김준헌 병원장님 1:1 책임 진료)" data-doc="서울대졸, 단국대 외래교수, 교정학 박사 김준헌 병원장님 1:1 책임 교정">④ 치아교정 기간이 궁금해요</button>
        </div>
      </div>
    `;
    body.querySelectorAll('.opt-btn').forEach((b) => {
      b.addEventListener('click', () => {
        updateScore(3);
        const code = ensurePass(true);
        showBooking(b.dataset.tr, `[30초 자가체크 매칭: ${b.dataset.doc}] 화타 스마일 PASS(${code})`);
      });
    });
  }

  function showQuiz() {
    body.innerHTML = `
      <div class="msg">
        <b>✨ 하야니의 치아건강 & 멤버십 상식 퀴즈 (+3점)</b><br>
        화이트스타일치과의원의 무료 AI API 로컬 프로토콜을 내 컴퓨터에 끌어다 쓸 수 있는 <b>정회원 등록 조건</b>은?
        <div class="card-form">
          <button class="opt-btn">① 화이트스타일치과의원에서 교정 보철 미백 등의 비급여 치료를 받으신 분 정회원 등록</button>
          <button class="opt-btn">② 아무 조건 없이 비회원으로 사용</button>
        </div>
      </div>
    `;
    body.querySelectorAll('.opt-btn').forEach((b) => {
      b.addEventListener('click', () => {
        updateScore(3);
        body.innerHTML = `<div class="msg">🎉 <b>정답이야 멍! (+3점 · 현재 ${score}/10점)</b><br><b>화타 스마일 PASS</b>에 등록하시면 AI 펫 하야니의 모든 기능을 이용하실 수 있고, 화이트스타일치과의원에서 <b>교정 보철 미백 등의 비급여 치료</b>를 받으신 분께는 내 컴퓨터에 끌어다 쓸 수 있는 <b>무료 AI API 프로토콜</b>이 제공됩니다!</div>`;
      });
    });
  }

  function togglePanel() {
    panel.classList.toggle('open');
    if (panel.classList.contains('open') && !body.innerHTML) {
      showFreeApiProtocol();
    }
  }

  // ---------- ⚙️ 화면 가림 방지 & 맞춤 노출 제어 시스템 (시간대별 / 사이트별 / 미니모드 / 위치 이동) ----------
  const curHost = (location.hostname || '').replace(/^www\./, '').toLowerCase();
  let displayPrefs = {
    enabled: true,
    miniMode: false,
    position: 'bottom-right', // 'bottom-right' | 'bottom-left'
    snoozeUntil: 0,
    excludedHosts: [],
    quietHours: 'none', // 'none' | 'night' (22~08) | 'work' (09~18)
  };

  function isWithinQuietHours(qh) {
    if (!qh || qh === 'none') return false;
    const hr = new Date().getHours();
    if (qh === 'night') return hr >= 22 || hr < 8;
    if (qh === 'work') return hr >= 9 && hr < 18;
    return false;
  }

  function applyDisplayPrefs(prefs) {
    displayPrefs = Object.assign({}, displayPrefs, prefs || {});
    const stg = shadow.getElementById('hwStage');
    const wrapEl = shadow.querySelector('.wrap');
    if (stg) stg.classList.toggle('mini', !!displayPrefs.miniMode);
    if (displayPrefs.position === 'bottom-left') {
      host.style.right = 'auto';
      host.style.left = '18px';
      if (wrapEl) wrapEl.style.alignItems = 'flex-start';
    } else {
      host.style.left = 'auto';
      host.style.right = '18px';
      if (wrapEl) wrapEl.style.alignItems = 'flex-end';
    }
    const isExcluded = Array.isArray(displayPrefs.excludedHosts) && displayPrefs.excludedHosts.includes(curHost);
    const isSnoozed = Number(displayPrefs.snoozeUntil || 0) > Date.now();
    const isQuiet = isWithinQuietHours(displayPrefs.quietHours);
    if (!displayPrefs.enabled || isExcluded || isSnoozed || isQuiet) {
      host.style.display = 'none';
    } else {
      host.style.display = '';
    }
  }

  function saveDisplayPrefs(patch) {
    const next = Object.assign({}, displayPrefs, patch || {});
    applyDisplayPrefs(next);
    try {
      localStorage.setItem('hwata_display_prefs', JSON.stringify(next));
    } catch {}
    try {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.set({ hwata_display_prefs: next });
      }
    } catch {}
  }

  // Load saved prefs on startup
  try {
    const rawLocal = localStorage.getItem('hwata_display_prefs');
    if (rawLocal) applyDisplayPrefs(JSON.parse(rawLocal));
  } catch {}
  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.get(['hwata_display_prefs', 'hwata_ext_species'], (res) => {
        if (res && res.hwata_display_prefs) applyDisplayPrefs(res.hwata_display_prefs);
        if (res && res.hwata_ext_species) {
          const idx = SPECIES_LIST.findIndex((s) => s.id === res.hwata_ext_species);
          if (idx >= 0) {
            currentSpeciesIdx = idx;
            const sp = SPECIES_LIST[currentSpeciesIdx];
            const titleEl = shadow.getElementById('hwPanelTitle');
            if (titleEl) titleEl.textContent = `${sp.emoji} ${sp.name} (화타펫) 3D · 화이트스타일치과의원`;
          }
        }
      });
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area === 'local' && changes.hwata_display_prefs && changes.hwata_display_prefs.newValue) {
          applyDisplayPrefs(changes.hwata_display_prefs.newValue);
        }
        if (area === 'local' && changes.hwata_ext_species && changes.hwata_ext_species.newValue) {
          const idx = SPECIES_LIST.findIndex((s) => s.id === changes.hwata_ext_species.newValue);
          if (idx >= 0) {
            currentSpeciesIdx = idx;
            const sp = SPECIES_LIST[currentSpeciesIdx];
            const titleEl = shadow.getElementById('hwPanelTitle');
            if (titleEl) titleEl.textContent = `${sp.emoji} ${sp.name} (화타펫) 3D · 화이트스타일치과의원`;
          }
        }
      });
    }
  } catch {}

  // Auto-fade speech bubble after 5 seconds so it never permanently blocks webpage content
  setTimeout(() => {
    if (bubble) bubble.classList.add('auto-hide');
  }, 5000);

  function showDisplaySettings() {
    const isMini = !!displayPrefs.miniMode;
    const isLeft = displayPrefs.position === 'bottom-left';
    const qh = displayPrefs.quietHours || 'none';
    const curSp = SPECIES_LIST[currentSpeciesIdx] || SPECIES_LIST[0];
    body.innerHTML = `
      <div class="msg">
        <b>⚙️ 위젯 노출 맞춤 설정 & 3D 파트너 변경</b><br>
        <small style="color:#f6ad93">웹서핑에 방해되지 않도록 크기·위치를 조절하거나, 서브메뉴에서 6종 동물 파트너로 변신할 수 있습니다.</small>
        <div class="card-form" style="margin-top:8px;">
          <button class="opt-btn" data-dact="switch-species">🐾 3D 파트너 변신: <b>현재 [${curSp.emoji} ${curSp.name}] (클릭 시 다음 동물로 변신)</b></button>
          <button class="opt-btn" data-dact="tab-hide">🙈 1. 이번 탭에서만 즉시 숨기기</button>
          <button class="opt-btn" data-dact="snooze-1h">🌙 2. 1시간 동안 모든 사이트에서 숨기기 (집중 모드)</button>
          <button class="opt-btn" data-dact="snooze-24h">📅 3. 오늘 하루(24시간) 동안 숨기기</button>
          <button class="opt-btn" data-dact="site-exclude">🚫 4. 이 사이트(${curHost || '현재 사이트'})에서는 항상 숨기기</button>
          <button class="opt-btn" data-dact="toggle-mini">🔹 5. 초소형 미니 아이콘 모드 (46px): <b>${isMini ? '켜짐 → 기본 크기로' : '꺼짐 → 미니 모드로 축소'}</b></button>
          <button class="opt-btn" data-dact="toggle-pos">↔️ 6. 화면 위치 변경: <b>${isLeft ? '좌측 하단 → 우측 하단으로' : '우측 하단 → 좌측 하단으로'}</b></button>
          <select id="hwQuietSel">
            <option value="none"${qh === 'none' ? ' selected' : ''}>⏰ 시간대 자동 숨김: 사용 안 함 (항상 표시)</option>
            <option value="night"${qh === 'night' ? ' selected' : ''}>🌙 야간 방해 금지 (22:00 ~ 익일 08:00 자동 숨김)</option>
            <option value="work"${qh === 'work' ? ' selected' : ''}>💼 업무 집중 시간 (09:00 ~ 18:00 자동 숨김)</option>
          </select>
          <button class="opt-btn" data-dact="disable-all" style="border-color:#ef4444;color:#fca5a5;">🔕 7. 웹페이지 플로팅 펫 완전히 끄기 (상단 툴바 팝업만 사용)</button>
        </div>
      </div>
    `;
    const qSel = body.querySelector('#hwQuietSel');
    if (qSel) {
      qSel.addEventListener('change', () => {
        saveDisplayPrefs({ quietHours: qSel.value });
      });
    }
    body.querySelectorAll('[data-dact]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const dact = btn.dataset.dact;
        if (dact === 'switch-species') {
          currentSpeciesIdx = (currentSpeciesIdx + 1) % SPECIES_LIST.length;
          const sp = SPECIES_LIST[currentSpeciesIdx];
          localStorage.setItem('hwata_ext_species', sp.id);
          try { if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) chrome.storage.local.set({ hwata_ext_species: sp.id }); } catch {}
          mode = 'wave';
          setTimeout(() => (mode = 'idle'), 2000);
          const titleEl = shadow.getElementById('hwPanelTitle');
          if (titleEl) titleEl.textContent = `${sp.emoji} ${sp.name} (화타펫) 3D · 화이트스타일치과의원`;
          bubble.innerHTML = `${sp.emoji} <b>${sp.name}</b>(으)로 변신 완료! 🐾`;
          showDisplaySettings();
        } else if (dact === 'tab-hide') {
          host.style.display = 'none';
        } else if (dact === 'snooze-1h') {
          saveDisplayPrefs({ snoozeUntil: Date.now() + 60 * 60 * 1000 });
        } else if (dact === 'snooze-24h') {
          saveDisplayPrefs({ snoozeUntil: Date.now() + 24 * 60 * 60 * 1000 });
        } else if (dact === 'site-exclude') {
          const list = Array.isArray(displayPrefs.excludedHosts) ? displayPrefs.excludedHosts.slice() : [];
          if (curHost && !list.includes(curHost)) list.push(curHost);
          saveDisplayPrefs({ excludedHosts: list });
        } else if (dact === 'toggle-mini') {
          saveDisplayPrefs({ miniMode: !displayPrefs.miniMode });
          showDisplaySettings();
        } else if (dact === 'toggle-pos') {
          saveDisplayPrefs({ position: displayPrefs.position === 'bottom-left' ? 'bottom-right' : 'bottom-left' });
          showDisplaySettings();
        } else if (dact === 'disable-all') {
          saveDisplayPrefs({ enabled: false });
        }
      });
    });
  }

  shadow.getElementById('hwStage').addEventListener('click', (e) => {
    if (e.target.id === 'hwHideBtn') return;
    togglePanel();
  });
  bubble.addEventListener('click', togglePanel);
  try {
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg && msg.type === 'HWATA_JAW_RELAX_ALERT' && bubble) {
        bubble.classList.remove('auto-hide');
        bubble.innerHTML = '😬 <b>' + (msg.title || '어금니 이완 알림') + '</b><br>' + (msg.message || '어금니를 2mm 띄우고 턱의 긴장을 풀어주세요!');
        bubble.style.display = 'block';
        setTimeout(() => bubble.classList.add('auto-hide'), 10000);
      }
    });
  } catch {}
  shadow.getElementById('hwClosePanel').addEventListener('click', () => panel.classList.remove('open'));
  shadow.getElementById('hwHideBtn').addEventListener('click', (e) => {
    e.stopPropagation();
    panel.classList.add('open');
    showDisplaySettings();
  });

  shadow.querySelectorAll('.p-chip').forEach((c) => {
    c.addEventListener('click', () => {
      const act = c.dataset.act;
      if (act === 'pass') showPassRegister();
      else if (act === 'display') showDisplaySettings();
      else if (act === 'species') {
        currentSpeciesIdx = (currentSpeciesIdx + 1) % SPECIES_LIST.length;
        const sp = SPECIES_LIST[currentSpeciesIdx];
        localStorage.setItem('hwata_ext_species', sp.id);
        try { if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) chrome.storage.local.set({ hwata_ext_species: sp.id }); } catch {}
        mode = 'wave';
        setTimeout(() => (mode = 'idle'), 2000);
        const titleEl = shadow.getElementById('hwPanelTitle');
        if (titleEl) titleEl.textContent = `${sp.emoji} ${sp.name} (화타펫) 3D · 화이트스타일치과의원`;
        bubble.innerHTML = `${sp.emoji} <b>${sp.name}</b>(으)로 변신 완료! 🐾`;
        body.innerHTML = `<div class="msg">${sp.emoji} <b>[${sp.name}] 3D 동물 변신 완료!</b><br>${sp.desc}<br><small style="color:#f6ad93">버튼을 다시 누르면 6종 동물(강아지·코끼리·공룡·파이톤·앵무새·고양이)로 순서대로 변신합니다.</small></div>`;
      }
      else if (act === 'freeapi') showFreeApiProtocol();
      else if (act === 'booking') showBooking();
      else if (act === 'scaling') showScaling();
      else if (act === 'selfcheck') showSelfCheck();
      else if (act === 'quiz') showQuiz();
      else if (act === 'care') {
        mode = 'brush';
        setTimeout(() => (mode = 'idle'), 4000);
        updateScore(3);
        body.innerHTML = `<div class="msg">🪥 <b>치카치카 2분 양치 스탬프 +3점 적립 완료! (현재 ${score}/10점)</b><br>PASS에 등록하시면 하야니의 모든 3D 동물 변신과 코스튬 기능을 이용하실 수 있어요!</div>`;
      }
    });
  });
})();
