// 화타펫 (HwataPet / 하야니) 백그라운드 서비스 워커
// 50분 집중 후 어금니 이완 스트레칭 알람 및 양치 타이머 백그라운드 스케줄러

chrome.runtime.onInstalled.addListener(() => {
  // 50분 주기 어금니 이완 스트레칭 알람 생성
  chrome.alarms.create('hwataJawRelax50', {
    delayInMinutes: 50,
    periodInMinutes: 50,
  });
});

// 알람 트리거 시 활성 탭으로 이완 안내 메시지 브로드캐스트
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'hwataJawRelax50') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs && tabs[0] && tabs[0].id) {
        chrome.tabs.sendMessage(tabs[0].id, {
          type: 'HWATA_JAW_RELAX_ALERT',
          title: '화타의 50분 어금니 이완 알림 멍!',
          message: '어금니를 꽉 깨물고 계시지 않나요? 윗니와 아랫니 사이를 2~3mm 살짝 띄우고 턱의 긴장을 풀어주세요!',
        }).catch(() => {
          // 탭이 아직 준비되지 않았거나 비활성 상태인 경우 조용히 무시
        });
      }
    });
  }
});
