// 화타펫 (HwataPet) 백그라운드 서비스 워커 v3.2.0
// - https://whitestyle.com/api/ai-pet/* 화이트리스트 프록시 + Bearer 토큰 자동 첨부

const ALLOWED_PREFIXES = [
  'https://whitestyle.com/api/ai-pet/',
  'https://www.whitestyle.com/api/ai-pet/',
];

function getStoredToken() {
  return new Promise((resolve) => {
    try {
      chrome.storage.local.get(['hwata_auth_token'], (res) => {
        resolve(typeof res?.hwata_auth_token === 'string' ? res.hwata_auth_token : '');
      });
    } catch {
      resolve('');
    }
  });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.type !== 'HWATA_API_REQUEST') return false;

  const url = String(msg.url || '');
  if (!ALLOWED_PREFIXES.some((p) => url.startsWith(p))) {
    sendResponse({ ok: false, status: 403, error: 'Blocked URL outside allowed whitestyle.com/api/ai-pet/ scope' });
    return false;
  }

  getStoredToken().then((token) => {
    const method = String(msg.method || 'GET').toUpperCase();
    const headers = { 'Content-Type': 'application/json' };
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const options = { method, headers };
    if (method !== 'GET' && method !== 'HEAD' && msg.body !== undefined) {
      options.body = typeof msg.body === 'string' ? msg.body : JSON.stringify(msg.body);
    }

    fetch(url, options)
      .then(async (res) => {
        let data = null;
        try {
          data = await res.json();
        } catch {
          data = null;
        }
        if (res.status === 401) {
          try {
            chrome.storage.local.remove(['hwata_auth_token', 'hwata_auth_user']);
          } catch {}
        }
        sendResponse({ ok: res.ok, status: res.status, data });
      })
      .catch((err) => {
        sendResponse({ ok: false, status: 0, error: err instanceof Error ? err.message : String(err) });
      });
  });

  return true;
});
